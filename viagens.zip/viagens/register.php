<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';

if (isLoggedIn()) {
    redirect('/viagens/user/packages.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($name === '' || $email === '' || $password === '' || $confirmPassword === '') {
        setFlash('error', 'Preencha todos os campos obrigatórios.');
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        setFlash('error', 'Informe um email válido.');
    } elseif (strlen($password) < 6) {
        setFlash('error', 'A senha deve ter pelo menos 6 caracteres.');
    } elseif ($password !== $confirmPassword) {
        setFlash('error', 'A confirmação de senha não confere.');
    } else {
        $checkStmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $checkStmt->execute([$email]);
        if ($checkStmt->fetch()) {
            setFlash('error', 'Esse email já está cadastrado.');
        } else {
            $insertStmt = $pdo->prepare('INSERT INTO users (name, email, password_hash, is_admin) VALUES (?, ?, ?, 0)');
            $insertStmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
            setFlash('success', 'Cadastro concluído! Faça login para continuar.');
            redirect('/viagens/login.php');
        }
    }
}

renderHeader($pdo, 'Cadastro');
?>
<main class="auth-wrapper">
  <section class="auth-card">
    <h1>Criar conta</h1>
    <p>Cadastre-se para reservar pacotes incríveis.</p>
    <?php renderAlerts(); ?>
    <form method="post" class="form-grid">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
      <label>Nome completo
        <input type="text" name="name" placeholder="Seu nome" required>
      </label>
      <label>Email
        <input type="email" name="email" placeholder="voce@email.com" required>
      </label>
      <label>Senha
        <input type="password" name="password" required>
      </label>
      <label>Confirmar senha
        <input type="password" name="confirm_password" required>
      </label>
      <button type="submit" class="btn btn-primary">Cadastrar</button>
    </form>
    <p class="auth-link">Já possui conta? <a href="/viagens/login.php">Entrar</a></p>
  </section>
</main>
<?php renderFooter(); ?>
