<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';

requireLogin();

$userId = (int)$_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    requireCsrfToken();
    
    $name = trim((string)($_POST['name'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));

    if ($name === '' || $email === '') {
        setFlash('error', 'Preencha nome e email.');
        redirect('/viagens/user/settings.php');
    }

    $checkStmt = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1');
    $checkStmt->execute([$email, $userId]);
    if ($checkStmt->fetch()) {
        setFlash('error', 'Este email já está em uso por outra conta.');
        redirect('/viagens/user/settings.php');
    }

    $updateStmt = $pdo->prepare('UPDATE users SET name = ?, email = ? WHERE id = ?');
    $updateStmt->execute([$name, $email, $userId]);

    $_SESSION['user_name'] = $name;
    $_SESSION['user_email'] = $email;
    setFlash('success', 'Perfil atualizado com sucesso.');
    redirect('/viagens/user/settings.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_password'])) {
    requireCsrfToken();
    
    $currentPassword = (string)($_POST['current_password'] ?? '');
    $newPassword = (string)($_POST['new_password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');

    if ($currentPassword === '' || $newPassword === '' || $confirmPassword === '') {
        setFlash('error', 'Preencha todos os campos de senha.');
        redirect('/viagens/user/settings.php');
    }

    if ($newPassword !== $confirmPassword) {
        setFlash('error', 'A nova senha e a confirmação não conferem.');
        redirect('/viagens/user/settings.php');
    }

    if (strlen($newPassword) < 6) {
        setFlash('error', 'A nova senha deve ter pelo menos 6 caracteres.');
        redirect('/viagens/user/settings.php');
    }

    $userStmt = $pdo->prepare('SELECT password_hash FROM users WHERE id = ? LIMIT 1');
    $userStmt->execute([$userId]);
    $user = $userStmt->fetch();
    if (!$user || !password_verify($currentPassword, (string)$user['password_hash'])) {
        setFlash('error', 'Senha atual inválida.');
        redirect('/viagens/user/settings.php');
    }

    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $updatePassStmt = $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
    $updatePassStmt->execute([$newHash, $userId]);

    setFlash('success', 'Senha atualizada com sucesso.');
    redirect('/viagens/user/settings.php');
}

$meStmt = $pdo->prepare('SELECT name, email, created_at FROM users WHERE id = ? LIMIT 1');
$meStmt->execute([$userId]);
$me = $meStmt->fetch();

renderHeader($pdo, 'Configurações');
renderNav('settings');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Configurações da conta</h1>
    <p>Atualize suas informações de perfil e segurança.</p>
  </section>

  <section class="card">
    <div class="card-content">
      <h2>Dados do perfil</h2>
      <p><strong>Conta criada em:</strong> <?= isset($me['created_at']) ? date('d/m/Y', strtotime((string)$me['created_at'])) : '-' ?></p>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="update_profile" value="1">
        <label>Nome
          <input type="text" name="name" value="<?= esc((string)($me['name'] ?? '')) ?>" required>
        </label>
        <label>Email (Gmail)
          <input type="email" name="email" value="<?= esc((string)($me['email'] ?? '')) ?>" required>
        </label>
        <button type="submit" class="btn btn-primary">Salvar perfil</button>
      </form>
    </div>
  </section>

  <section class="card admin-form-card">
    <div class="card-content">
      <h2>Senha e segurança</h2>
      <form method="post" class="form-grid">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="update_password" value="1">
        <label>Senha atual
          <input type="password" name="current_password" required>
        </label>
        <label>Nova senha
          <input type="password" name="new_password" minlength="6" required>
        </label>
        <label>Confirmar nova senha
          <input type="password" name="confirm_password" minlength="6" required>
        </label>
        <button type="submit" class="btn btn-primary">Atualizar senha</button>
      </form>
    </div>
  </section>
</main>
<?php renderFooter(); ?>
