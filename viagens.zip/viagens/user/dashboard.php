<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';

requireLogin();

$statusFilter = strtolower(trim((string)($_GET['status'] ?? '')));
$allowedStatusFilters = ['confirmada' => 'Confirmada', 'cancelada' => 'Cancelada'];
$statusLabel = $allowedStatusFilters[$statusFilter] ?? null;
$statusQuery = $statusLabel !== null ? '?status=' . urlencode($statusFilter) : '';
$reservationsAnchorUrl = '/viagens/user/dashboard.php' . $statusQuery . '#reservas-realizadas';

$reservationsSql = 'SELECT r.id, r.status, r.reserved_at, p.destination, p.travel_date, p.departure_location, p.price
    FROM reservations r
    INNER JOIN packages p ON p.id = r.package_id
    WHERE r.user_id = ?';
$reservationParams = [$_SESSION['user_id']];

if ($statusLabel !== null) {
    $reservationsSql .= ' AND r.status = ?';
    $reservationParams[] = $statusLabel;
}

$reservationsSql .= ' ORDER BY r.reserved_at DESC';
$stmt = $pdo->prepare($reservationsSql);
$stmt->execute($reservationParams);
$reservations = $stmt->fetchAll();

renderHeader($pdo, 'Meu Painel');
renderNav('dashboard');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Olá, <?= esc($_SESSION['user_name']) ?></h1>
    <p>Email: <?= esc($_SESSION['user_email']) ?></p>
  </section>
  <section class="table-wrapper" id="reservas-realizadas">
    <div class="section-title">
      <h2>Minhas viagens reservadas<?= $statusLabel !== null ? ' - ' . esc($statusLabel) : '' ?></h2>
      <a class="btn btn-primary" href="/viagens/user/packages.php">Ver pacotes</a>
    </div>
    <nav class="category-filters" aria-label="Filtrar reservas por status">
      <a class="category-chip<?= $statusLabel === null ? ' is-active' : '' ?>" href="/viagens/user/dashboard.php#reservas-realizadas">Todas</a>
      <a class="category-chip<?= $statusFilter === 'confirmada' ? ' is-active' : '' ?>" href="/viagens/user/dashboard.php?status=confirmada#reservas-realizadas">Confirmada</a>
      <a class="category-chip<?= $statusFilter === 'cancelada' ? ' is-active' : '' ?>" href="/viagens/user/dashboard.php?status=cancelada#reservas-realizadas">Cancelada</a>
    </nav>
    <table>
      <thead>
        <tr>
          <th>Destino</th>
          <th>Data da viagem</th>
          <th>Local de saída</th>
          <th>Preço</th>
          <th>Status</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$reservations): ?>
        <tr><td colspan="6">Você ainda não possui reservas.</td></tr>
      <?php else: ?>
        <?php foreach ($reservations as $reservation): ?>
          <tr>
            <td><?= esc($reservation['destination']) ?></td>
            <td><?= date('d/m/Y', strtotime($reservation['travel_date'])) ?></td>
            <td><?= esc($reservation['departure_location']) ?></td>
            <td>R$ <?= number_format((float)$reservation['price'], 2, ',', '.') ?></td>
            <td><span class="badge"><?= esc($reservation['status']) ?></span></td>
            <td>
              <div class="admin-package-row-actions">
                <a class="btn btn-secondary btn-sm" href="/viagens/user/reservation_details.php?id=<?= (int)$reservation['id'] ?>">Detalhes</a>
                <?php if (strcasecmp((string)$reservation['status'], 'Cancelada') !== 0): ?>
                  <form method="post" action="/viagens/user/reservation_cancel.php" class="inline-form" onsubmit="return confirm('Deseja cancelar esta reserva?');">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="reservation_id" value="<?= (int)$reservation['id'] ?>">
                    <input type="hidden" name="redirect_to" value="<?= esc($reservationsAnchorUrl) ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Cancelar</button>
                  </form>
                <?php endif; ?>
                <form method="post" action="/viagens/user/reservation_delete.php" class="inline-form" onsubmit="return confirm('Deseja excluir esta reserva do painel?');">
                  <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                  <input type="hidden" name="reservation_id" value="<?= (int)$reservation['id'] ?>">
                  <input type="hidden" name="redirect_to" value="<?= esc($reservationsAnchorUrl) ?>">
                  <button type="submit" class="btn btn-secondary btn-sm">Excluir</button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </section>
</main>
<?php renderFooter(); ?>
