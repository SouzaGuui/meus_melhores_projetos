<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/cart.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/user/cart.php');
}

requireCsrfToken();

$packageId = (int)($_POST['package_id'] ?? 0);
$quantity = (int)($_POST['quantity'] ?? 1);
$travelDate = isset($_POST['travel_date']) ? (string)$_POST['travel_date'] : null;
$notes = isset($_POST['notes']) ? (string)$_POST['notes'] : null;

if ($packageId <= 0) {
    setFlash('error', 'Pacote invalido.');
    redirect('/viagens/user/cart.php');
}

updateCartItem($pdo, $packageId, $quantity, $travelDate, $notes);
setFlash('success', 'Carrinho atualizado.');
redirect('/viagens/user/cart.php');
