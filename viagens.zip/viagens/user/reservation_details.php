<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';

requireLogin();
$reservationId = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare(
    'SELECT r.id, r.status, r.reserved_at, p.destination, p.description, p.travel_date, p.departure_location, p.price, p.image_url
    FROM reservations r
    INNER JOIN packages p ON p.id = r.package_id
    WHERE r.id = ? AND r.user_id = ?
    LIMIT 1'
);
$stmt->execute([$reservationId, $_SESSION['user_id']]);
$reservation = $stmt->fetch();

if (!$reservation) {
    setFlash('error', 'Reserva não encontrada.');
    redirect('/viagens/user/dashboard.php');
}

renderHeader($pdo, 'Detalhes da Reserva');
renderNav('dashboard');
?>
<main class="container">
  <section class="detail-card">
    <img class="lazy" data-src="<?= esc($reservation['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($reservation['destination']) ?>">
    <div>
      <h1><?= esc($reservation['destination']) ?></h1>
      <p><?= esc($reservation['description']) ?></p>
      <ul class="meta-list">
        <li><strong>Data:</strong> <?= date('d/m/Y', strtotime($reservation['travel_date'])) ?></li>
        <li><strong>Saída:</strong> <?= esc($reservation['departure_location']) ?></li>
        <li><strong>Preço:</strong> R$ <?= number_format((float)$reservation['price'], 2, ',', '.') ?></li>
        <li><strong>Status:</strong> <?= esc($reservation['status']) ?></li>
      </ul>
      <div class="detail-actions">
        <a class="btn btn-primary" href="/viagens/user/dashboard.php">Voltar ao painel</a>
        <?php if (strcasecmp((string)$reservation['status'], 'Cancelada') !== 0): ?>
          <form method="post" action="/viagens/user/reservation_cancel.php" class="inline-form" onsubmit="return confirm('Deseja cancelar esta reserva?');">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="reservation_id" value="<?= (int)$reservation['id'] ?>">
            <input type="hidden" name="redirect_to" value="/viagens/user/dashboard.php">
            <button type="submit" class="btn btn-danger">Cancelar reserva</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </section>
</main>
<?php renderFooter(); ?>
