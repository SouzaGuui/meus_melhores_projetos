<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/cart.php';

$loggedIn = isLoggedIn();
$items = getCartItems($pdo);
$total = 0.0;
foreach ($items as $item) {
    $total += (float)$item['subtotal'];
}

renderHeader($pdo, 'Meu carrinho');
if ($loggedIn) {
    renderNav('cart');
}
?>
<?php if (!$loggedIn): ?>
<?php renderPublicNav(false, 'carrinho'); ?>
<?php endif; ?>

<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Meu carrinho</h1>
    <p>
      <?php if ($loggedIn): ?>
        Revise os pacotes selecionados, ajuste a quantidade, escolha a data desejada para cada item
        e finalize a reserva diretamente por aqui.
      <?php else: ?>
        Você pode montar o seu carrinho mesmo sem fazer login — os itens ficam salvos na sua sessão.
        Para finalizar a reserva,
        <a href="/viagens/login.php?redirect=/viagens/user/cart.php">faça login</a>
        ou <a href="/viagens/cadastro.php">crie uma conta gratuitamente</a>.
      <?php endif; ?>
    </p>
  </section>

  <?php if (!$items): ?>
    <section class="table-wrapper">
      <p>
        O seu carrinho está vazio no momento.
        Conheça os <a href="/viagens/pacotes.php">pacotes disponíveis</a>
        e adicione os destinos que mais lhe interessarem.
      </p>
    </section>
  <?php else: ?>
    <section class="table-wrapper">
      <table class="cart-table">
        <thead>
          <tr>
            <th></th>
            <th>Pacote</th>
            <th>Data escolhida</th>
            <th>Qtd</th>
            <th>Valor unitário</th>
            <th>Subtotal</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($items as $item): ?>
            <tr>
              <td><img class="cart-thumb lazy" data-src="<?= esc($item['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($item['destination']) ?>"></td>
              <td>
                <strong><?= esc($item['destination']) ?></strong><br>
                <small>Saída: <?= esc($item['departure_location']) ?></small>
              </td>
              <td>
                <form method="post" action="/viagens/user/cart_update.php" class="inline-form cart-inline-form">
                  <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                  <input type="hidden" name="package_id" value="<?= (int)$item['package_id'] ?>">
                  <input type="hidden" name="quantity" value="<?= (int)$item['quantity'] ?>">
                  <input type="date" name="travel_date" value="<?= esc((string)($item['travel_date'] ?? $item['package_travel_date'])) ?>" class="cart-date-input">
                  <button type="submit" class="btn btn-secondary btn-sm">Salvar</button>
                </form>
                <small class="cart-hint">Data sugerida: <?= date('d/m/Y', strtotime($item['package_travel_date'])) ?></small>
              </td>
              <td>
                <form method="post" action="/viagens/user/cart_update.php" class="inline-form cart-inline-form">
                  <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                  <input type="hidden" name="package_id" value="<?= (int)$item['package_id'] ?>">
                  <input type="hidden" name="travel_date" value="<?= esc((string)($item['travel_date'] ?? $item['package_travel_date'])) ?>">
                  <input type="number" name="quantity" min="1" max="20" value="<?= (int)$item['quantity'] ?>" class="cart-qty-input">
                  <button type="submit" class="btn btn-secondary btn-sm">Ok</button>
                </form>
              </td>
              <td>R$ <?= number_format((float)$item['unit_price'], 2, ',', '.') ?></td>
              <td>R$ <?= number_format((float)$item['subtotal'], 2, ',', '.') ?></td>
              <td>
                <form method="post" action="/viagens/user/cart_remove.php" class="inline-form">
                  <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                  <input type="hidden" name="package_id" value="<?= (int)$item['package_id'] ?>">
                  <button type="submit" class="btn btn-danger btn-sm" title="Remover do carrinho">
                    <i class="fa-solid fa-trash"></i>
                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
        <tfoot>
          <tr>
            <td colspan="5" style="text-align:right;"><strong>Total</strong></td>
            <td colspan="2"><strong>R$ <?= number_format($total, 2, ',', '.') ?></strong></td>
          </tr>
        </tfoot>
      </table>
    </section>

    <div class="cart-actions">
      <?php if ($loggedIn): ?>
        <form method="post" action="/viagens/user/cart_checkout.php" class="inline-form">
          <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-circle-check"></i> Finalizar reserva</button>
        </form>
      <?php else: ?>
        <a class="btn btn-primary" href="/viagens/login.php?redirect=/viagens/user/cart.php"><i class="fa-solid fa-right-to-bracket"></i> Entrar para finalizar</a>
      <?php endif; ?>
      <a class="btn btn-secondary" href="/viagens/pacotes.php"><i class="fa-solid fa-arrow-left"></i> Continuar navegando</a>
    </div>
  <?php endif; ?>
</main>
<?php renderFooter(); ?>
