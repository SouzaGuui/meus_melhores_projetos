<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/cart.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/user/cart.php');
}

requireCsrfToken();

$packageId = (int)($_POST['package_id'] ?? 0);
if ($packageId <= 0) {
    setFlash('error', 'Pacote invalido.');
    redirect('/viagens/user/cart.php');
}

removeFromCart($pdo, $packageId);
setFlash('success', 'Pacote removido do carrinho.');
redirect('/viagens/user/cart.php');
