<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/favorites.php';

requireLogin();

$stmt = $pdo->prepare(
    'SELECT p.id, p.destination, p.description, p.price, p.travel_date, p.departure_location, p.image_url,
            f.created_at AS favorited_at
     FROM favorites f
     INNER JOIN packages p ON p.id = f.package_id
     WHERE f.user_id = ?
     ORDER BY f.created_at DESC'
);
$stmt->execute([(int)$_SESSION['user_id']]);
$favorites = $stmt->fetchAll();

renderHeader($pdo, 'Meus favoritos');
renderNav('favorites');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Meus favoritos</h1>
    <p>
      Aqui ficam os pacotes que você salvou para consultar mais tarde.
      No momento, você possui <strong><?= count($favorites) ?></strong> pacote(s) favoritado(s).
    </p>
  </section>

  <?php if (!$favorites): ?>
    <section class="table-wrapper">
      <p>
        Você ainda não favoritou nenhum pacote. Explore a
        <a href="/viagens/pacotes.php">nossa vitrine de destinos</a> e clique no ícone de coração
        para salvar os pacotes que mais lhe interessarem.
      </p>
    </section>
  <?php else: ?>
    <section class="card-grid card-grid-3">
      <?php foreach ($favorites as $package): ?>
        <article class="card">
          <img class="lazy" data-src="<?= esc($package['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($package['destination']) ?>">
          <div class="card-content">
            <h3><?= esc($package['destination']) ?></h3>
            <p><?= esc($package['description']) ?></p>
            <ul class="meta-list meta-list-compact">
              <li><i class="fa-regular fa-calendar"></i><?= date('d/m/Y', strtotime($package['travel_date'])) ?></li>
              <li><i class="fa-solid fa-location-dot"></i><?= esc($package['departure_location']) ?></li>
            </ul>
            <div class="card-footer">
              <span class="price">R$ <?= number_format((float)$package['price'], 2, ',', '.') ?></span>
              <div class="action-group">
                <a class="btn btn-secondary btn-sm btn-text-action" href="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?>">Detalhes</a>
                <form method="post" action="/viagens/user/favorite_toggle.php" class="inline-form">
                  <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                  <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
                  <input type="hidden" name="redirect_to" value="/viagens/user/favorites.php">
                  <button type="submit" class="btn btn-secondary btn-sm btn-text-action" title="Remover dos favoritos">
                    <i class="fa-solid fa-heart-crack"></i> Remover
                  </button>
                </form>
              </div>
            </div>
          </div>
        </article>
      <?php endforeach; ?>
    </section>
  <?php endif; ?>
</main>
<?php renderFooter(); ?>
