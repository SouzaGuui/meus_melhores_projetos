<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/favorites.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/pacotes.php');
}

requireCsrfToken();

$packageId = (int)($_POST['package_id'] ?? 0);
$redirectTo = isset($_POST['redirect_to']) ? (string)$_POST['redirect_to'] : '/viagens/pacotes.php';
if (strpos($redirectTo, '/viagens/') !== 0) {
    $redirectTo = '/viagens/pacotes.php';
}

if ($packageId <= 0) {
    setFlash('error', 'Pacote invalido.');
    redirect($redirectTo);
}

$stmt = $pdo->prepare('SELECT id, destination FROM packages WHERE id = ? LIMIT 1');
$stmt->execute([$packageId]);
$package = $stmt->fetch();
if (!$package) {
    setFlash('error', 'Pacote nao encontrado.');
    redirect($redirectTo);
}

$nowFavorited = toggleFavorite($pdo, $packageId);
if ($nowFavorited) {
    setFlash('success', 'Pacote "' . $package['destination'] . '" adicionado aos favoritos.');
} else {
    setFlash('success', 'Pacote "' . $package['destination'] . '" removido dos favoritos.');
}

redirect($redirectTo);
