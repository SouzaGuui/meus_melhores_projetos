<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';
require_once __DIR__ . '/../includes/favorites.php';
require_once __DIR__ . '/../includes/categories.php';

requireLogin();
$categorySlug = isset($_GET['categoria']) ? (string)$_GET['categoria'] : '';
$currentCategory = getCategory($categorySlug);
[$categoryWhere, $categoryParams] = buildCategoryFilter($categorySlug);

$sql = 'SELECT id, destination, description, location_info, culture_info, price, travel_date, departure_location, image_url
        FROM packages';
if ($categoryWhere !== '') {
    $sql .= ' WHERE ' . $categoryWhere;
}
$sql .= ' ORDER BY travel_date ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($categoryParams);
$packages = $stmt->fetchAll();
$totalPackages = count($packages);
$favoriteIds = getFavoritePackageIds($pdo);
$allCategories = getCategories();

renderHeader($pdo, 'Pacotes');
renderNav('packages');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Pacotes de viagem</h1>
    <?php if ($currentCategory): ?>
      <p>
        Mostrando <strong><?= (int)$totalPackages ?></strong> pacote(s) na categoria
        <strong><?= esc($currentCategory['label']) ?></strong>.
        <?= esc($currentCategory['headline']) ?>.
      </p>
    <?php else: ?>
      <p>
        Escolha o seu próximo destino, favorite os pacotes que mais lhe chamarem a atenção,
        adicione-os ao carrinho ou confirme o agendamento em poucos cliques.
      </p>
    <?php endif; ?>
  </section>

  <nav class="category-filters" aria-label="Filtro por categoria">
    <span class="category-filters-label"><i class="fa-solid fa-filter" aria-hidden="true"></i> Filtrar por:</span>
    <a class="category-chip<?= $categorySlug === '' ? ' is-active' : '' ?>" href="/viagens/user/packages.php">
      <i class="fa-solid fa-list" aria-hidden="true"></i> Todos
    </a>
    <?php foreach ($allCategories as $slug => $cat): ?>
      <a class="category-chip<?= $slug === $categorySlug ? ' is-active' : '' ?>"
         href="/viagens/user/packages.php?categoria=<?= esc($slug) ?>">
        <i class="<?= esc($cat['icon']) ?>" aria-hidden="true"></i> <?= esc($cat['label']) ?>
      </a>
    <?php endforeach; ?>
  </nav>

  <?php if (!$packages): ?>
    <section class="table-wrapper">
      <p>
        Nenhum pacote encontrado para esta categoria no momento.
        <a href="/viagens/user/packages.php">Ver todos os destinos disponíveis</a>.
      </p>
    </section>
  <?php endif; ?>

  <section class="card-grid card-grid-3">
    <?php foreach ($packages as $package): ?>
      <?php $isFav = in_array((int)$package['id'], $favoriteIds, true); ?>
      <article class="card">
        <img class="lazy" data-src="<?= esc($package['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($package['destination']) ?>">
        <div class="card-content">
          <h3><?= esc($package['destination']) ?></h3>
          <p><?= esc($package['description']) ?></p>
          <ul class="meta-list meta-list-compact">
            <li><i class="fa-solid fa-location-dot"></i><span><strong>Onde fica:</strong> <?= esc($package['location_info']) ?></span></li>
            <li><i class="fa-solid fa-masks-theater"></i><span><strong>Cultura local:</strong> <?= esc($package['culture_info']) ?></span></li>
          </ul>
          <div class="card-footer">
            <span class="price">R$ <?= number_format((float)$package['price'], 2, ',', '.') ?></span>
            <div class="action-group">
              <form method="post" action="/viagens/user/favorite_toggle.php" class="inline-form">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
                <input type="hidden" name="redirect_to" value="/viagens/user/packages.php">
                <button type="submit" class="btn btn-fav btn-sm btn-icon-action<?= $isFav ? ' is-active' : '' ?>" title="<?= $isFav ? 'Remover dos favoritos' : 'Favoritar pacote' ?>">
                  <i class="<?= $isFav ? 'fa-solid' : 'fa-regular' ?> fa-heart"></i>
                </button>
              </form>
              <form method="post" action="/viagens/user/cart_add.php" class="inline-form">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
                <input type="hidden" name="redirect_to" value="/viagens/user/packages.php">
                <button type="submit" class="btn btn-secondary btn-sm btn-icon-action" title="Adicionar ao carrinho">
                  <i class="fa-solid fa-cart-plus"></i>
                </button>
              </form>
              <a class="btn btn-secondary btn-sm btn-text-action" href="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?>&from_panel=1">Detalhes</a>
              <a class="btn btn-primary btn-sm btn-text-action" href="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?>&from_panel=1#agendar">Agendar</a>
            </div>
          </div>
        </div>
      </article>
    <?php endforeach; ?>
  </section>
</main>
<?php renderFooter(); ?>
