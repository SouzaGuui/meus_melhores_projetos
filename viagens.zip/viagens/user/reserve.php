<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/user/packages.php');
}

requireCsrfToken();

$packageId = (int)($_POST['package_id'] ?? 0);
if ($packageId <= 0) {
    setFlash('error', 'Pacote invalido para reserva.');
    redirect('/viagens/user/packages.php');
}

$packageStmt = $pdo->prepare('SELECT id, travel_date FROM packages WHERE id = ? LIMIT 1');
$packageStmt->execute([$packageId]);
$package = $packageStmt->fetch();
if (!$package) {
    setFlash('error', 'Pacote nao encontrado.');
    redirect('/viagens/user/packages.php');
}

// Agendamento: usuario pode escolher uma data; se invalida/vazia usa a data padrao do pacote.
$scheduledDate = null;
if (!empty($_POST['scheduled_date'])) {
    $timestamp = strtotime((string)$_POST['scheduled_date']);
    if ($timestamp !== false) {
        $scheduledDate = date('Y-m-d', $timestamp);
    }
}
if ($scheduledDate === null) {
    $scheduledDate = $package['travel_date'];
}

$checkStmt = $pdo->prepare('SELECT id FROM reservations WHERE user_id = ? AND package_id = ? LIMIT 1');
$checkStmt->execute([$_SESSION['user_id'], $packageId]);
if ($checkStmt->fetch()) {
    setFlash('error', 'Voce ja reservou este pacote.');
    redirect('/viagens/user/dashboard.php');
}

$reserveStmt = $pdo->prepare(
    'INSERT INTO reservations (user_id, package_id, status, scheduled_date, reserved_at)
     VALUES (?, ?, "Confirmada", ?, NOW())'
);
$reserveStmt->execute([$_SESSION['user_id'], $packageId, $scheduledDate]);

setFlash('success', 'Reserva realizada com sucesso para ' . date('d/m/Y', strtotime($scheduledDate)) . '.');
redirect('/viagens/user/dashboard.php');
