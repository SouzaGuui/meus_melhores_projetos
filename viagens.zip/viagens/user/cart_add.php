<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/cart.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/pacotes.php');
}

requireCsrfToken();

$packageId = (int)($_POST['package_id'] ?? 0);
$quantity = max(1, (int)($_POST['quantity'] ?? 1));
$travelDate = isset($_POST['travel_date']) ? (string)$_POST['travel_date'] : null;
$notes = isset($_POST['notes']) ? (string)$_POST['notes'] : null;
$redirectTo = isset($_POST['redirect_to']) ? (string)$_POST['redirect_to'] : '/viagens/user/cart.php';
if (strpos($redirectTo, '/viagens/') !== 0) {
    $redirectTo = '/viagens/user/cart.php';
}

if (!isLoggedIn()) {
    redirect('/viagens/login.php?redirect=' . urlencode($redirectTo));
}

if ($packageId <= 0) {
    setFlash('error', 'Pacote invalido.');
    redirect($redirectTo);
}

if (!addToCart($pdo, $packageId, $quantity, $travelDate, $notes)) {
    setFlash('error', 'Nao foi possivel adicionar o pacote ao carrinho.');
    redirect($redirectTo);
}

setFlash('success', 'Pacote adicionado ao carrinho.');
redirect($redirectTo);
