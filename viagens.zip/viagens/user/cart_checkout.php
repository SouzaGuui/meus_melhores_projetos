<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/cart.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/user/cart.php');
}

requireCsrfToken();

$items = getCartItems($pdo);
if (!$items) {
    setFlash('error', 'Seu carrinho esta vazio.');
    redirect('/viagens/user/cart.php');
}

$userId = (int)$_SESSION['user_id'];

$reserveStmt = $pdo->prepare(
    'INSERT INTO reservations (user_id, package_id, status, scheduled_date, reserved_at)
     VALUES (?, ?, "Confirmada", ?, NOW())'
);
$existsStmt = $pdo->prepare(
    'SELECT id FROM reservations WHERE user_id = ? AND package_id = ? LIMIT 1'
);

$created = 0;
$skipped = 0;

$pdo->beginTransaction();
try {
    foreach ($items as $item) {
        $packageId = (int)$item['package_id'];

        $existsStmt->execute([$userId, $packageId]);
        if ($existsStmt->fetch()) {
            $skipped++;
            continue;
        }

        $scheduledDate = $item['travel_date'] ?: $item['package_travel_date'];
        $reserveStmt->execute([$userId, $packageId, $scheduledDate]);
        $created++;
    }

    clearCart($pdo);
    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    setFlash('error', 'Nao foi possivel finalizar a reserva. Tente novamente.');
    redirect('/viagens/user/cart.php');
}

if ($created === 0 && $skipped > 0) {
    setFlash('error', 'Voce ja tinha reserva para todos os pacotes do carrinho.');
} elseif ($skipped > 0) {
    setFlash('success', $created . ' reserva(s) criada(s). ' . $skipped . ' pacote(s) ja estavam reservados.');
} else {
    setFlash('success', $created . ' reserva(s) realizada(s) com sucesso.');
}

redirect('/viagens/user/dashboard.php');
