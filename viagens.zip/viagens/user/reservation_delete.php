<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireLogin();

$fallbackRedirect = '/viagens/user/dashboard.php#reservas-realizadas';
$redirectTo = (string)($_POST['redirect_to'] ?? $fallbackRedirect);
if (!str_starts_with($redirectTo, '/viagens/')) {
    $redirectTo = $fallbackRedirect;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect($fallbackRedirect);
}

requireCsrfToken();

$reservationId = (int)($_POST['reservation_id'] ?? 0);
if ($reservationId <= 0) {
    setFlash('error', 'Reserva invalida.');
    redirect($redirectTo);
}

$stmt = $pdo->prepare('DELETE FROM reservations WHERE id = ? AND user_id = ?');
$stmt->execute([$reservationId, $_SESSION['user_id']]);

setFlash('success', 'Reserva excluida com sucesso.');
redirect($redirectTo);
