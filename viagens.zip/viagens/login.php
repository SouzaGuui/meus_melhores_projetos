<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/cart.php';

/**
 * Valida o parametro ?redirect= para evitar open redirect.
 * Aceita apenas caminhos internos comecando com /viagens/.
 */
function sanitizeLoginRedirect(?string $target): ?string
{
    if ($target === null) {
        return null;
    }
    $target = trim($target);
    if ($target === '' || strpos($target, '/viagens/') !== 0) {
        return null;
    }
    return $target;
}

$redirectTarget = sanitizeLoginRedirect($_GET['redirect'] ?? $_POST['redirect'] ?? null);

if (isLoggedIn()) {
    redirect($redirectTarget ?? '/viagens/user/packages.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        setFlash('error', 'Preencha todos os campos obrigatórios.');
    } else {
        $stmt = $pdo->prepare('SELECT id, name, email, password_hash, is_admin FROM users WHERE email = ? LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = (int)$user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['is_admin'] = (int)$user['is_admin'] === 1;

            // Carrinho anonimo (sessao) migra para o banco apos login.
            mergeSessionCartIntoDb($pdo, (int)$user['id']);

            setFlash('success', 'Login realizado com sucesso.');
            if ($redirectTarget !== null) {
                redirect($redirectTarget);
            }
            redirect($_SESSION['is_admin'] ? '/viagens/admin/dashboard.php' : '/viagens/user/dashboard.php');
        } else {
            setFlash('error', 'Credenciais inválidas. Verifique email e senha.');
        }
    }
}

renderHeader($pdo, 'Entrar');
?>
<main class="auth-wrapper">
  <section class="auth-card">
    <h1>Destino Certo Turismo</h1>
    <p>Entre para consultar pacotes e reservas.</p>
    <?php renderAlerts(); ?>
    <form method="post" class="form-grid">
      <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
      <label>Email
        <input type="email" name="email" placeholder="voce@email.com" required>
      </label>
      <label>Senha
        <input type="password" name="password" placeholder="********" required>
      </label>
      <button type="submit" class="btn btn-primary">Entrar</button>
    </form>
    <p class="auth-link">Ainda não tem conta? <a href="/viagens/register.php">Cadastre-se</a></p>
  </section>
</main>
<?php renderFooter(); ?>
