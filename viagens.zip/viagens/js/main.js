// Dark Mode Toggle
document.addEventListener('DOMContentLoaded', function() {
  const darkModeToggle = document.getElementById('darkModeToggle');
  if (darkModeToggle) {
    const body = document.body;
    const icon = darkModeToggle.querySelector('i');

    // Check for saved preference or system preference
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
      body.setAttribute('data-theme', 'dark');
      icon.classList.remove('fa-moon');
      icon.classList.add('fa-sun');
    }

    darkModeToggle.addEventListener('click', function() {
      const currentTheme = body.getAttribute('data-theme');
      if (currentTheme === 'dark') {
        body.removeAttribute('data-theme');
        localStorage.setItem('theme', 'light');
        icon.classList.remove('fa-sun');
        icon.classList.add('fa-moon');
      } else {
        body.setAttribute('data-theme', 'dark');
        localStorage.setItem('theme', 'dark');
        icon.classList.remove('fa-moon');
        icon.classList.add('fa-sun');
      }
    });
  }

  // Back to Top Button
  const backToTop = document.getElementById('backToTop');
  if (backToTop) {
    window.addEventListener('scroll', function() {
      if (window.scrollY > 300) {
        backToTop.classList.add('visible');
      } else {
        backToTop.classList.remove('visible');
      }
    });

    backToTop.addEventListener('click', function() {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
    });
  }
});

// Toast Notifications
function showToast(message, type = 'success') {
  const container = document.getElementById('toastContainer');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;

  const icons = {
    success: 'fa-circle-check',
    error: 'fa-circle-exclamation',
    warning: 'fa-triangle-exclamation'
  };

  toast.innerHTML = `
    <i class="fa-solid ${icons[type] || icons.success} toast-icon"></i>
    <span class="toast-message">${message}</span>
    <button class="toast-close"><i class="fa-solid fa-xmark"></i></button>
  `;

  container.appendChild(toast);

  const closeBtn = toast.querySelector('.toast-close');
  closeBtn.addEventListener('click', function() {
    removeToast(toast);
  });

  setTimeout(() => {
    removeToast(toast);
  }, 5000);
}

function removeToast(toast) {
  toast.style.animation = 'slideOut 0.3s ease';
  setTimeout(() => {
    toast.remove();
  }, 300);
}

// Loading Screen
function showLoading(message = 'Carregando...') {
  const loadingScreen = document.getElementById('loadingScreen');
  if (loadingScreen) {
    const loadingText = loadingScreen.querySelector('.loading-text');
    if (loadingText) {
      loadingText.textContent = message;
    }
    loadingScreen.classList.add('active');
  }
}

function hideLoading() {
  const loadingScreen = document.getElementById('loadingScreen');
  if (loadingScreen) {
    loadingScreen.classList.remove('active');
  }
}

// Lazy Loading Images
document.addEventListener('DOMContentLoaded', function() {
  const lazyImages = document.querySelectorAll('img.lazy');

  if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          img.src = img.dataset.src;
          img.classList.remove('lazy');
          img.classList.add('loaded');
          observer.unobserve(img);
        }
      });
    });

    lazyImages.forEach(img => imageObserver.observe(img));
  } else {
    // Fallback for browsers that don't support IntersectionObserver
    lazyImages.forEach(img => {
      img.src = img.dataset.src;
      img.classList.remove('lazy');
      img.classList.add('loaded');
    });
  }
});

document.querySelectorAll('.alert').forEach((alertEl) => {
  setTimeout(() => {
    alertEl.style.transition = 'opacity .4s ease';
    alertEl.style.opacity = '0';
  }, 4500);
});

document.querySelectorAll('.logout-link').forEach((logoutLink) => {
  logoutLink.addEventListener('click', (event) => {
    const shouldLogout = window.confirm('Voce tem certeza que deseja sair?');
    if (!shouldLogout) {
      event.preventDefault();
    }
  });
});

const accountTrigger = document.querySelector('.nav-account-trigger');
const accountDrawer = document.getElementById('account-drawer');
const accountClosers = document.querySelectorAll('[data-account-close]');

if (accountTrigger && accountDrawer) {
  const closeDrawer = () => {
    document.body.classList.remove('account-drawer-open');
    accountDrawer.setAttribute('aria-hidden', 'true');
    accountTrigger.setAttribute('aria-expanded', 'false');
  };

  const openDrawer = () => {
    document.body.classList.add('account-drawer-open');
    accountDrawer.setAttribute('aria-hidden', 'false');
    accountTrigger.setAttribute('aria-expanded', 'true');
  };

  accountTrigger.addEventListener('click', () => {
    if (document.body.classList.contains('account-drawer-open')) {
      closeDrawer();
      return;
    }
    openDrawer();
  });

  accountClosers.forEach((closer) => {
    closer.addEventListener('click', closeDrawer);
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
      closeDrawer();
    }
  });
}
