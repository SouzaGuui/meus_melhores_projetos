<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';

logout();
header('Location: /viagens/index.php');
exit;
