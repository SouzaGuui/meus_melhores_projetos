<?php
declare(strict_types=1);

require_once __DIR__ . '/functions.php';

function renderHeader(PDO $pdo, string $title): void
{
    // Security headers
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');

    $primary = siteSetting($pdo, 'primary_color', '#0f4c81');
    $accent = siteSetting($pdo, 'accent_color', '#f6a623');
    $success = siteSetting($pdo, 'success_color', '#1ea672');
    $siteTitle = siteSetting($pdo, 'site_title', 'Destino Certo Turismo');
    $csrfToken = generateCsrfToken();

    echo '<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">';
    echo '<title>' . esc($title) . ' - ' . esc($siteTitle) . '</title>';
    
    // SEO Meta Tags
    echo '<meta name="description" content="Descubra pacotes de viagens incríveis com a Destino Certo Turismo. Reserve sua próxima aventura com segurança e conforto.">';
    echo '<meta name="keywords" content="viagens, turismo, pacotes de viagem, reservas, destinos turísticos">';
    echo '<meta name="author" content="Destino Certo Turismo">';
    echo '<meta name="robots" content="index, follow">';
    
    // Open Graph
    echo '<meta property="og:title" content="' . esc($title) . ' - ' . esc($siteTitle) . '">';
    echo '<meta property="og:description" content="Descubra pacotes de viagens incríveis com a Destino Certo Turismo.">';
    echo '<meta property="og:type" content="website">';
    echo '<meta property="og:url" content="https://destinocertoturismo.com">';
    
    // Favicon
    echo '<link rel="icon" type="image/x-icon" href="/viagens/favicon.ico">';
    echo '<link rel="apple-touch-icon" sizes="180x180" href="/viagens/apple-touch-icon.png">';
    
    echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>';
    echo '<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">';
    echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">';
    echo '<link rel="stylesheet" href="/viagens/css/style.css">';
    echo '<style>:root{--primary:' . esc($primary) . ';--accent:' . esc($accent) . ';--success:' . esc($success) . ';}</style>';
    
    // CSRF token for JavaScript
    echo '<script>window.csrfToken = "' . esc($csrfToken) . '";</script>';
    
    echo '</head><body>';
}

function renderFooter(): void
{
    echo '<button class="dark-mode-toggle" id="darkModeToggle" title="Alternar modo escuro"><i class="fa-solid fa-moon"></i></button>';
    echo '<button class="back-to-top" id="backToTop" title="Voltar ao topo"><i class="fa-solid fa-arrow-up"></i></button>';
    echo '<a href="https://wa.me/5511999999999?text=Olá! Gostaria de saber mais sobre os pacotes de viagem." class="whatsapp-button" target="_blank" rel="noopener" title="Contato via WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>';
    echo '<div class="toast-container" id="toastContainer"></div>';
    echo '<div class="loading-screen" id="loadingScreen"><div class="loading-spinner"></div><div class="loading-text">Carregando...</div></div>';
    echo '<script src="/viagens/js/main.js"></script></body></html>';
}

function renderAlerts(): void
{
    $success = getFlash('success');
    $error = getFlash('error');
    if ($success) {
        echo '<div class="alert alert-success"><i class="fa-solid fa-circle-check"></i>' . esc($success) . '</div>';
    }
    if ($error) {
        echo '<div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation"></i>' . esc($error) . '</div>';
    }
}
