<?php
declare(strict_types=1);

/**
 * Mapa de categorias da home. Como a tabela packages nao possui um campo
 * "categoria", filtramos pelos textos existentes (destination, description,
 * location_info, culture_info, attractions_info, travel_info) usando LIKE.
 *
 * Cada categoria tem uma lista de palavras-chave que, se encontradas em
 * qualquer um desses campos, incluem o pacote naquela categoria.
 */

function getCategories(): array
{
    return [
        'praias' => [
            'label'    => 'Praias',
            'headline' => 'Mar, litoral e piscinas naturais',
            'image'    => 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
            'icon'     => 'fa-solid fa-umbrella-beach',
            'keywords' => ['praia', 'litoral', 'ilha', 'mar ', 'baía', 'baia', 'dunas', 'piscinas naturais', 'jangada'],
        ],
        'aventura' => [
            'label'    => 'Aventura',
            'headline' => 'Trilhas, cachoeiras e ecoturismo',
            'image'    => 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=1200&q=80',
            'icon'     => 'fa-solid fa-person-hiking',
            'keywords' => ['cataratas', 'trilha', 'ecoturismo', 'cachoeira', 'gruta', 'mergulho', 'buggy', 'flutuação', 'flutuacao', 'rapel', 'aventura'],
        ],
        'cultura' => [
            'label'    => 'Cultura',
            'headline' => 'História, patrimônio e tradição',
            'image'    => 'https://images.unsplash.com/photo-1521292270410-a8c4d716d518?auto=format&fit=crop&w=1200&q=80',
            'icon'     => 'fa-solid fa-landmark',
            'keywords' => ['histórico', 'historico', 'história', 'historia', 'barroco', 'colonial', 'museu', 'patrimônio', 'patrimonio', 'samba', 'carnaval', 'pelourinho', 'igreja'],
        ],
        'relaxamento' => [
            'label'    => 'Relaxamento',
            'headline' => 'Destinos tranquilos e charmosos',
            'image'    => 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1200&q=80',
            'icon'     => 'fa-solid fa-spa',
            'keywords' => ['charme', 'tranquilo', 'charmosa', 'gastronomia', 'chocolate', 'rústica', 'rustica', 'acoriana', 'açoriana', 'café da manhã', 'cafe da manha', 'relaxante', 'descanso'],
        ],
    ];
}

function getCategory(string $slug): ?array
{
    $slug = strtolower(trim($slug));
    $all = getCategories();
    return $all[$slug] ?? null;
}

/**
 * Monta a clausula WHERE e os parametros para filtrar pacotes pela categoria.
 * Retorna array [where_sql, params]. Se a categoria nao existir, retorna filtro vazio.
 */
function buildCategoryFilter(?string $slug): array
{
    if ($slug === null || $slug === '') {
        return ['', []];
    }
    $category = getCategory($slug);
    if ($category === null) {
        return ['', []];
    }

    $columns = ['destination', 'description', 'location_info', 'culture_info', 'attractions_info', 'travel_info'];
    $conditions = [];
    $params = [];
    foreach ($category['keywords'] as $keyword) {
        foreach ($columns as $col) {
            $conditions[] = "LOWER($col) LIKE ?";
            $params[] = '%' . strtolower($keyword) . '%';
        }
    }
    if (!$conditions) {
        return ['', []];
    }
    return ['(' . implode(' OR ', $conditions) . ')', $params];
}
