<?php
declare(strict_types=1);

/**
 * Helpers para favoritos. Todas as funcoes assumem que auth.php ja foi carregado
 * (sessao iniciada) e trabalham apenas com usuario logado.
 */

/**
 * Retorna lista de IDs de pacotes favoritados pelo usuario logado.
 * Se nao houver login, retorna array vazio.
 */
function getFavoritePackageIds(PDO $pdo): array
{
    if (empty($_SESSION['user_id'])) {
        return [];
    }
    $stmt = $pdo->prepare('SELECT package_id FROM favorites WHERE user_id = ?');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $ids = [];
    foreach ($stmt->fetchAll() as $row) {
        $ids[] = (int)$row['package_id'];
    }
    return $ids;
}

function isPackageFavorited(PDO $pdo, int $packageId): bool
{
    if (empty($_SESSION['user_id']) || $packageId <= 0) {
        return false;
    }
    $stmt = $pdo->prepare('SELECT id FROM favorites WHERE user_id = ? AND package_id = ? LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id'], $packageId]);
    return (bool)$stmt->fetch();
}

/**
 * Adiciona ou remove um pacote dos favoritos do usuario logado.
 * Retorna true se, apos a operacao, o pacote esta favoritado; false caso contrario.
 */
function toggleFavorite(PDO $pdo, int $packageId): bool
{
    if (empty($_SESSION['user_id']) || $packageId <= 0) {
        return false;
    }
    $userId = (int)$_SESSION['user_id'];

    if (isPackageFavorited($pdo, $packageId)) {
        $del = $pdo->prepare('DELETE FROM favorites WHERE user_id = ? AND package_id = ?');
        $del->execute([$userId, $packageId]);
        return false;
    }

    $ins = $pdo->prepare('INSERT INTO favorites (user_id, package_id) VALUES (?, ?)');
    $ins->execute([$userId, $packageId]);
    return true;
}

function countFavorites(PDO $pdo): int
{
    if (empty($_SESSION['user_id'])) {
        return 0;
    }
    $stmt = $pdo->prepare('SELECT COUNT(*) AS total FROM favorites WHERE user_id = ?');
    $stmt->execute([(int)$_SESSION['user_id']]);
    $row = $stmt->fetch();
    return (int)($row['total'] ?? 0);
}
