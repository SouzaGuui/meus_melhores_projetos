<?php
declare(strict_types=1);

function renderNav(string $active = ''): void
{
    $isAdmin = !empty($_SESSION['is_admin']);
    $accountUrl = $isAdmin ? '/viagens/admin/dashboard.php' : '/viagens/user/dashboard.php';
    echo '<header class="home-header panel-header"><div class="container nav-inner">';
    echo '<a class="brand-large" href="/viagens/index.php">';
    echo '<i class="fa-solid fa-plane-departure"></i><span class="brand-text"><strong>Destino Certo Turismo</strong><small>Seu próximo destino começa aqui</small></span>';
    echo '</a>';

    echo '<nav class="home-nav-links panel-nav-links" aria-label="Menu do painel">';
    echo '<a class="nav-link" href="/viagens/index.php"><i class="fa-solid fa-house"></i><span>Página inicial</span></a>';
    echo '<a class="nav-link' . ($active === 'dashboard' ? ' active' : '') . '" href="/viagens/user/dashboard.php"><i class="fa-solid fa-table-columns"></i><span>Meu Painel</span></a>';
    echo '<a class="nav-link' . ($active === 'packages' ? ' active' : '') . '" href="/viagens/user/packages.php"><i class="fa-solid fa-map-location-dot"></i><span>Pacotes</span></a>';
    if ($isAdmin) {
        echo '<a class="nav-link' . ($active === 'admin' ? ' active' : '') . '" href="/viagens/admin/dashboard.php"><i class="fa-solid fa-shield-halved"></i><span>Admin</span></a>';
        echo '<a class="nav-link' . ($active === 'admin_packages' ? ' active' : '') . '" href="/viagens/admin/packages.php"><i class="fa-solid fa-suitcase-rolling"></i><span>Pacotes (admin)</span></a>';
    }
    echo '</nav>';

    echo '<div class="home-nav-actions">';
    echo '<button class="btn btn-primary nav-account-trigger" type="button" aria-label="Minha conta" aria-controls="account-drawer" aria-expanded="false">';
    echo '<i class="fa-solid fa-user"></i></button>';
    echo '<a class="btn btn-accent logout-link" href="/viagens/logout.php"><i class="fa-solid fa-right-from-bracket"></i> Sair</a>';
    echo '</div></div>';
    echo '<div class="account-drawer-overlay" data-account-close></div>';
    echo '<aside id="account-drawer" class="account-drawer" aria-hidden="true" aria-label="Menu da conta">';
    echo '<div class="account-drawer-header"><strong>Minha conta</strong>';
    echo '<button type="button" class="account-drawer-close" data-account-close aria-label="Fechar menu"><i class="fa-solid fa-xmark"></i></button>';
    echo '</div>';
    echo '<nav class="account-drawer-links">';
    echo '<a class="account-drawer-link' . ($active === 'dashboard' ? ' active' : '') . '" href="' . $accountUrl . '"><i class="fa-solid fa-user"></i><span>Painel</span></a>';
    echo '<a class="account-drawer-link' . ($active === 'favorites' ? ' active' : '') . '" href="/viagens/user/favorites.php"><i class="fa-solid fa-heart"></i><span>Favoritos</span></a>';
    echo '<a class="account-drawer-link' . ($active === 'cart' ? ' active' : '') . '" href="/viagens/user/cart.php"><i class="fa-solid fa-cart-shopping"></i><span>Carrinho</span></a>';
    if ($isAdmin) {
        echo '<a class="account-drawer-link' . ($active === 'admin' ? ' active' : '') . '" href="/viagens/admin/dashboard.php"><i class="fa-solid fa-shield-halved"></i><span>Admin</span></a>';
        echo '<a class="account-drawer-link' . ($active === 'admin_packages' ? ' active' : '') . '" href="/viagens/admin/packages.php"><i class="fa-solid fa-suitcase-rolling"></i><span>Pacotes (admin)</span></a>';
    }
    echo '<a class="account-drawer-link' . ($active === 'settings' ? ' active' : '') . '" href="/viagens/user/settings.php"><i class="fa-solid fa-gear"></i><span>Configurações</span></a>';
    echo '</nav></aside></header>';
}

function renderPublicNav(bool $loggedIn, string $active = 'inicio'): void
{
    $isAdmin = !empty($_SESSION['is_admin']);
    $accountUrl = $isAdmin ? '/viagens/admin/dashboard.php' : '/viagens/user/dashboard.php';

    $links = [
        ['id' => 'inicio', 'href' => '/viagens/index.php', 'icon' => 'fa-solid fa-house', 'label' => 'Início'],
        ['id' => 'pacotes', 'href' => '/viagens/pacotes.php', 'icon' => 'fa-solid fa-map-location-dot', 'label' => 'Pacotes'],
        ['id' => 'categorias', 'href' => '/viagens/index.php#categorias', 'icon' => 'fa-solid fa-layer-group', 'label' => 'Categorias'],
        ['id' => 'sobre', 'href' => '/viagens/index.php#sobre', 'icon' => 'fa-solid fa-circle-info', 'label' => 'Sobre'],
        ['id' => 'contato', 'href' => '/viagens/index.php#contato', 'icon' => 'fa-solid fa-headset', 'label' => 'Contato'],
    ];

    echo '<header class="home-header"><div class="container nav-inner">';
    echo '<a class="brand-large" href="/viagens/index.php">';
    echo '<i class="fa-solid fa-plane-departure"></i><span class="brand-text"><strong>Destino Certo Turismo</strong><small>Seu próximo destino começa aqui</small></span>';
    echo '</a>';

    echo '<nav class="home-nav-links" aria-label="Menu principal">';
    foreach ($links as $link) {
        $activeClass = $active === $link['id'] ? ' active' : '';
        echo '<a class="nav-link' . $activeClass . '" href="' . $link['href'] . '"><i class="' . $link['icon'] . '"></i><span>' . $link['label'] . '</span></a>';
    }

    echo '</nav>';

    echo '<div class="home-nav-actions">';
    if ($loggedIn) {
        echo '<button class="btn btn-primary nav-account-trigger" type="button" aria-label="Minha conta" aria-controls="account-drawer" aria-expanded="false">';
        echo '<i class="fa-solid fa-user"></i></button>';
        if ($isAdmin) {
            echo '<a class="btn btn-secondary nav-icon-link" href="/viagens/admin/dashboard.php" aria-label="Voltar ao painel"><i class="fa-solid fa-eye"></i></a>';
        }
        echo '<a class="btn btn-accent logout-link" href="/viagens/logout.php"><i class="fa-solid fa-right-from-bracket"></i> Sair</a>';
    } else {
        echo '<a class="btn btn-primary" href="/viagens/login.php"><i class="fa-solid fa-right-to-bracket"></i> Entrar</a>';
        echo '<a class="btn btn-accent" href="/viagens/cadastro.php"><i class="fa-solid fa-user-plus"></i> Cadastrar</a>';
    }
    echo '</div></div>';

    if ($loggedIn) {
        echo '<div class="account-drawer-overlay" data-account-close></div>';
        echo '<aside id="account-drawer" class="account-drawer" aria-hidden="true" aria-label="Menu da conta">';
        echo '<div class="account-drawer-header"><strong>Minha conta</strong>';
        echo '<button type="button" class="account-drawer-close" data-account-close aria-label="Fechar menu"><i class="fa-solid fa-xmark"></i></button>';
        echo '</div>';
        echo '<nav class="account-drawer-links">';
        echo '<a class="account-drawer-link' . ($active === 'dashboard' ? ' active' : '') . '" href="' . $accountUrl . '"><i class="fa-solid fa-user"></i><span>Painel</span></a>';
        echo '<a class="account-drawer-link' . ($active === 'favoritos' ? ' active' : '') . '" href="/viagens/user/favorites.php"><i class="fa-solid fa-heart"></i><span>Favoritos</span></a>';
        echo '<a class="account-drawer-link' . ($active === 'carrinho' ? ' active' : '') . '" href="/viagens/user/cart.php"><i class="fa-solid fa-cart-shopping"></i><span>Carrinho</span></a>';
        echo '<a class="account-drawer-link' . ($active === 'settings' ? ' active' : '') . '" href="/viagens/user/settings.php"><i class="fa-solid fa-gear"></i><span>Configurações</span></a>';
        echo '</nav></aside>';
    }

    echo '</header>';
}
