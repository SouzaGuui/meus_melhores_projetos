<?php
declare(strict_types=1);

/**
 * Helpers de carrinho. Suporta dois modos:
 * - Usuario logado: persistido na tabela `cart`.
 * - Usuario anonimo: mantido em $_SESSION['cart'] como
 *     [ package_id => ['quantity' => int, 'travel_date' => ?string, 'notes' => ?string] ]
 *
 * Assume que auth.php (sessao) ja foi carregado antes.
 */

function ensureSessionCart(): void
{
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
}

function fetchPackageForCart(PDO $pdo, int $packageId): ?array
{
    if ($packageId <= 0) {
        return null;
    }
    $stmt = $pdo->prepare(
        'SELECT id, destination, description, price, travel_date, departure_location, image_url
         FROM packages WHERE id = ? LIMIT 1'
    );
    $stmt->execute([$packageId]);
    $row = $stmt->fetch();
    return $row ?: null;
}

/**
 * Recebe string de data em formato livre (ex: YYYY-MM-DD) e devolve YYYY-MM-DD valida
 * ou null se vazia/invalida.
 */
function normalizeTravelDate(?string $value): ?string
{
    if ($value === null) {
        return null;
    }
    $value = trim($value);
    if ($value === '') {
        return null;
    }
    $ts = strtotime($value);
    if ($ts === false) {
        return null;
    }
    return date('Y-m-d', $ts);
}

function addToCart(PDO $pdo, int $packageId, int $quantity = 1, ?string $travelDate = null, ?string $notes = null): bool
{
    if ($packageId <= 0) {
        return false;
    }
    $quantity = max(1, $quantity);
    $travelDate = normalizeTravelDate($travelDate);
    $package = fetchPackageForCart($pdo, $packageId);
    if (!$package) {
        return false;
    }

    if (isset($_SESSION['user_id'])) {
        $userId = (int)$_SESSION['user_id'];
        // UPSERT: soma a quantidade caso ja exista.
        $stmt = $pdo->prepare(
            'INSERT INTO cart (user_id, package_id, quantity, unit_price, travel_date, notes)
             VALUES (?, ?, ?, ?, ?, ?)
             ON DUPLICATE KEY UPDATE
               quantity = quantity + VALUES(quantity),
               travel_date = COALESCE(VALUES(travel_date), travel_date),
               notes = COALESCE(VALUES(notes), notes),
               updated_at = CURRENT_TIMESTAMP'
        );
        $stmt->execute([
            $userId,
            $packageId,
            $quantity,
            (float)$package['price'],
            $travelDate,
            $notes,
        ]);
        return true;
    }

    ensureSessionCart();
    $key = (string)$packageId;
    if (isset($_SESSION['cart'][$key])) {
        $_SESSION['cart'][$key]['quantity'] += $quantity;
        if ($travelDate !== null) {
            $_SESSION['cart'][$key]['travel_date'] = $travelDate;
        }
        if ($notes !== null) {
            $_SESSION['cart'][$key]['notes'] = $notes;
        }
    } else {
        $_SESSION['cart'][$key] = [
            'quantity' => $quantity,
            'travel_date' => $travelDate,
            'notes' => $notes,
        ];
    }
    return true;
}

function updateCartItem(PDO $pdo, int $packageId, int $quantity, ?string $travelDate = null, ?string $notes = null): bool
{
    if ($packageId <= 0) {
        return false;
    }
    if ($quantity <= 0) {
        return removeFromCart($pdo, $packageId);
    }
    $travelDate = normalizeTravelDate($travelDate);

    if (isset($_SESSION['user_id'])) {
        $userId = (int)$_SESSION['user_id'];
        $stmt = $pdo->prepare(
            'UPDATE cart SET quantity = ?, travel_date = ?, notes = ?, updated_at = CURRENT_TIMESTAMP
             WHERE user_id = ? AND package_id = ?'
        );
        $stmt->execute([$quantity, $travelDate, $notes, $userId, $packageId]);
        return true;
    }

    ensureSessionCart();
    $key = (string)$packageId;
    if (!isset($_SESSION['cart'][$key])) {
        return false;
    }
    $_SESSION['cart'][$key]['quantity'] = $quantity;
    $_SESSION['cart'][$key]['travel_date'] = $travelDate;
    $_SESSION['cart'][$key]['notes'] = $notes;
    return true;
}

function removeFromCart(PDO $pdo, int $packageId): bool
{
    if ($packageId <= 0) {
        return false;
    }
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare('DELETE FROM cart WHERE user_id = ? AND package_id = ?');
        $stmt->execute([(int)$_SESSION['user_id'], $packageId]);
        return true;
    }
    ensureSessionCart();
    unset($_SESSION['cart'][(string)$packageId]);
    return true;
}

function clearCart(PDO $pdo): void
{
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare('DELETE FROM cart WHERE user_id = ?');
        $stmt->execute([(int)$_SESSION['user_id']]);
    }
    $_SESSION['cart'] = [];
}

/**
 * Retorna lista normalizada de itens do carrinho com dados do pacote:
 * [ ['package_id', 'quantity', 'unit_price', 'travel_date' (DATE escolhida),
 *    'notes', 'destination', 'description', 'image_url', 'departure_location',
 *    'package_travel_date' (data oficial do pacote), 'subtotal'] ]
 */
function getCartItems(PDO $pdo): array
{
    if (isset($_SESSION['user_id'])) {
        $stmt = $pdo->prepare(
            'SELECT c.package_id, c.quantity, c.unit_price, c.travel_date, c.notes,
                    p.destination, p.description, p.image_url, p.departure_location,
                    p.travel_date AS package_travel_date
             FROM cart c
             INNER JOIN packages p ON p.id = c.package_id
             WHERE c.user_id = ?
             ORDER BY c.added_at DESC'
        );
        $stmt->execute([(int)$_SESSION['user_id']]);
        $items = $stmt->fetchAll();
        foreach ($items as &$item) {
            $item['subtotal'] = (float)$item['unit_price'] * (int)$item['quantity'];
        }
        return $items;
    }

    ensureSessionCart();
    if (!$_SESSION['cart']) {
        return [];
    }
    $ids = array_map('intval', array_keys($_SESSION['cart']));
    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare(
        'SELECT id, destination, description, price, travel_date, departure_location, image_url
         FROM packages WHERE id IN (' . $placeholders . ')'
    );
    $stmt->execute($ids);
    $rows = $stmt->fetchAll();

    $byId = [];
    foreach ($rows as $row) {
        $byId[(int)$row['id']] = $row;
    }

    $items = [];
    foreach ($_SESSION['cart'] as $idKey => $entry) {
        $pid = (int)$idKey;
        if (!isset($byId[$pid])) {
            // pacote removido; limpa do carrinho
            unset($_SESSION['cart'][$idKey]);
            continue;
        }
        $p = $byId[$pid];
        $unitPrice = (float)$p['price'];
        $qty = max(1, (int)($entry['quantity'] ?? 1));
        $items[] = [
            'package_id' => $pid,
            'quantity' => $qty,
            'unit_price' => $unitPrice,
            'travel_date' => $entry['travel_date'] ?? null,
            'notes' => $entry['notes'] ?? null,
            'destination' => $p['destination'],
            'description' => $p['description'],
            'image_url' => $p['image_url'],
            'departure_location' => $p['departure_location'],
            'package_travel_date' => $p['travel_date'],
            'subtotal' => $unitPrice * $qty,
        ];
    }
    return $items;
}

function countCartItems(PDO $pdo): int
{
    $total = 0;
    foreach (getCartItems($pdo) as $item) {
        $total += (int)$item['quantity'];
    }
    return $total;
}

function getCartTotal(PDO $pdo): float
{
    $total = 0.0;
    foreach (getCartItems($pdo) as $item) {
        $total += (float)$item['subtotal'];
    }
    return $total;
}

/**
 * Migra itens de $_SESSION['cart'] para a tabela cart apos login.
 * Remove a sessao em caso de sucesso para evitar duplicar na proxima requisicao.
 */
function mergeSessionCartIntoDb(PDO $pdo, int $userId): void
{
    if ($userId <= 0 || empty($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
        return;
    }

    $stmt = $pdo->prepare(
        'INSERT INTO cart (user_id, package_id, quantity, unit_price, travel_date, notes)
         VALUES (?, ?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
           quantity = quantity + VALUES(quantity),
           travel_date = COALESCE(VALUES(travel_date), travel_date),
           notes = COALESCE(VALUES(notes), notes),
           updated_at = CURRENT_TIMESTAMP'
    );

    foreach ($_SESSION['cart'] as $idKey => $entry) {
        $packageId = (int)$idKey;
        $package = fetchPackageForCart($pdo, $packageId);
        if (!$package) {
            continue;
        }
        $stmt->execute([
            $userId,
            $packageId,
            max(1, (int)($entry['quantity'] ?? 1)),
            (float)$package['price'],
            normalizeTravelDate($entry['travel_date'] ?? null),
            $entry['notes'] ?? null,
        ]);
    }
    $_SESSION['cart'] = [];
}
