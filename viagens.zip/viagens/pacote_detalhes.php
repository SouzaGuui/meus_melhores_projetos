<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/nav.php';
require_once __DIR__ . '/includes/favorites.php';

$packageId = (int)($_GET['id'] ?? 0);
$loggedIn = isLoggedIn();
$isFav = $loggedIn && isPackageFavorited($pdo, $packageId);
$fromPanel = $loggedIn && (($_GET['from_panel'] ?? '0') === '1');

$stmt = $pdo->prepare(
    'SELECT id, destination, description, location_info, culture_info, attractions_info, travel_info, travel_date, departure_location, price, image_url
    FROM packages
    WHERE id = ?
    LIMIT 1'
);
$stmt->execute([$packageId]);
$package = $stmt->fetch();

if (!$package) {
    setFlash('error', 'Pacote não encontrado.');
    redirect($fromPanel ? '/viagens/user/packages.php' : '/viagens/pacotes.php');
}

renderHeader($pdo, 'Detalhes do Pacote');
?>
<?php if ($fromPanel): ?>
  <?php renderNav('packages'); ?>
<?php else: ?>
  <?php renderPublicNav($loggedIn, 'pacotes'); ?>
<?php endif; ?>

<main class="container">
  <?php renderAlerts(); ?>
  <section class="detail-card travel-detail-card">
    <img class="lazy" data-src="<?= esc($package['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($package['destination']) ?>">
    <div>
      <h1><?= esc($package['destination']) ?></h1>
      <p><?= esc($package['description']) ?></p>
      <ul class="meta-list">
        <li><strong>Data prevista da viagem:</strong> <?= date('d/m/Y', strtotime($package['travel_date'])) ?></li>
        <li><strong>Local de saída:</strong> <?= esc($package['departure_location']) ?></li>
        <li><strong>Valor por pessoa:</strong> R$ <?= number_format((float)$package['price'], 2, ',', '.') ?></li>
      </ul>

      <div class="detail-actions">
        <?php if ($loggedIn): ?>
          <form method="post" action="/viagens/user/favorite_toggle.php" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
            <input type="hidden" name="redirect_to" value="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?><?= $fromPanel ? '&from_panel=1' : '' ?>">
            <button type="submit" class="btn btn-fav<?= $isFav ? ' is-active' : '' ?>" title="<?= $isFav ? 'Remover dos favoritos' : 'Favoritar pacote' ?>">
              <i class="<?= $isFav ? 'fa-solid' : 'fa-regular' ?> fa-heart"></i>
              <?= $isFav ? 'Favoritado' : 'Favoritar' ?>
            </button>
          </form>
        <?php else: ?>
          <a class="btn btn-fav" href="/viagens/login.php?redirect=/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?><?= $fromPanel ? '&from_panel=1' : '' ?>" title="Faça login para favoritar">
            <i class="fa-regular fa-heart"></i> Favoritar
          </a>
        <?php endif; ?>

        <?php if ($loggedIn): ?>
          <form method="post" action="/viagens/user/cart_add.php" class="inline-form">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
            <input type="hidden" name="redirect_to" value="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?><?= $fromPanel ? '&from_panel=1' : '' ?>">
            <button type="submit" class="btn btn-secondary">
              <i class="fa-solid fa-cart-plus"></i> Adicionar ao carrinho
            </button>
          </form>
        <?php else: ?>
          <a class="btn btn-secondary" href="/viagens/login.php?redirect=/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?><?= $fromPanel ? '&from_panel=1' : '' ?>">
            <i class="fa-solid fa-cart-plus"></i> Faça login para usar o carrinho
          </a>
        <?php endif; ?>
      </div>

      <section class="schedule-box" id="agendar">
        <h3><i class="fa-solid fa-calendar-check"></i> Agendamento da viagem</h3>
        <p>
          Escolha a data em que você pretende viajar. A sugestão inicial corresponde à data oficial do pacote
          (<?= date('d/m/Y', strtotime($package['travel_date'])) ?>), mas você pode ajustá-la conforme a sua disponibilidade.
          A reserva será gerada automaticamente após a confirmação.
        </p>
        <?php if ($loggedIn): ?>
          <form method="post" action="/viagens/user/reserve.php" class="form-grid schedule-form">
            <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
            <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
            <label>Data escolhida
              <input type="date" name="scheduled_date" value="<?= esc($package['travel_date']) ?>" required>
            </label>
            <button type="submit" class="btn btn-primary"><i class="fa-solid fa-circle-check"></i> Confirmar agendamento</button>
          </form>
        <?php else: ?>
          <a class="btn btn-primary" href="/viagens/login.php?redirect=/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?><?= $fromPanel ? '&from_panel=1' : '' ?>">
            <i class="fa-solid fa-right-to-bracket"></i> Faça login para agendar
          </a>
        <?php endif; ?>
      </section>
    </div>
  </section>

  <section class="table-wrapper info-grid">
    <article>
      <h3>Localização</h3>
      <p><?= esc($package['location_info']) ?></p>
    </article>
    <article>
      <h3>Cultura local</h3>
      <p><?= esc($package['culture_info']) ?></p>
    </article>
    <article>
      <h3>Pontos turísticos</h3>
      <p><?= esc($package['attractions_info']) ?></p>
    </article>
    <article>
      <h3>Informações da viagem</h3>
      <p><?= esc($package['travel_info']) ?></p>
    </article>
  </section>
</main>

<?php renderFooter(); ?>
