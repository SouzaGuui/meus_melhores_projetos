-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 29/05/2026 às 19:25
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `destino_certo`
--
CREATE DATABASE IF NOT EXISTS `destino_certo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `destino_certo`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `cart`
--

CREATE TABLE `cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `travel_date` date DEFAULT NULL,
  `notes` varchar(255) DEFAULT NULL,
  `added_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

-- --------------------------------------------------------

--
-- Estrutura para tabela `favorites`
--

CREATE TABLE `favorites` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `destination` varchar(120) NOT NULL,
  `description` text NOT NULL,
  `location_info` text NOT NULL,
  `culture_info` text NOT NULL,
  `attractions_info` text NOT NULL,
  `travel_info` text NOT NULL,
  `travel_date` date NOT NULL,
  `departure_location` varchar(120) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `packages`
--

INSERT INTO `packages` (`id`, `destination`, `description`, `location_info`, `culture_info`, `attractions_info`, `travel_info`, `travel_date`, `departure_location`, `price`, `image_url`) VALUES
(1, 'Jericoacoara', 'Dunas, lagoas e por do sol inesquecivel no Ceara.', 'Litoral oeste do Ceara, em area de protecao ambiental.', 'Vila com atmosfera rustica, gastronomia nordestina e artesanato local.', 'Pedra Furada, Lagoa do Paraiso, Duna do Por do Sol e Mangue Seco.', 'Pacote de 5 dias com hospedagem, traslado e passeio de buggy.', '2026-07-15', 'Sao Paulo - SP', 2890.00, 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80'),
(2, 'Gramado', 'Clima europeu, gastronomia e charme da Serra Gaucha.', 'Serra Gaucha, Rio Grande do Sul, com facil acesso por Porto Alegre.', 'Influencia italiana e alema, com eventos sazonais e chocolates artesanais.', 'Rua Coberta, Lago Negro, Mini Mundo e Snowland.', 'Pacote de 4 dias com cafe da manha, city tour e transfer.', '2026-08-10', 'Campinas - SP', 2390.00, 'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=80'),
(3, 'Salvador', 'Historia, cultura, praias e culinaria baiana.', 'Capital da Bahia com forte heranca historica e litoranea.', 'Musica, danca, religiosidade afro-brasileira e culinaria marcante.', 'Pelourinho, Elevador Lacerda, Farol da Barra e Itapua.', 'Pacote de 5 dias com voo, hotel e passeio historico guiado.', '2026-09-05', 'Belo Horizonte - MG', 1990.00, 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6a/Pelourinho%2C_Salvador%2C_Bahia%2C_Brazil.jpg/1280px-Pelourinho%2C_Salvador%2C_Bahia%2C_Brazil.jpg'),
(4, 'Fernando de Noronha', 'Praias cristalinas e mergulho em um paraiso natural.', 'Arquipelago pernambucano com controle de visitantes.', 'Turismo sustentavel com foco em preservacao e experiencia natural.', 'Baia do Sancho, Praia do Leao, Projeto Tamar e trilhas ecológicas.', 'Pacote de 6 dias com taxas inclusas, hospedagem e passeio de barco.', '2026-10-03', 'Recife - PE', 5490.00, 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80'),
(5, 'Rio de Janeiro', 'Cidade maravilhosa com praias e pontos iconicos.', 'Sudeste do Brasil, com aeroporto internacional e ampla rede hoteleira.', 'Samba, carnaval, arte urbana e culinaria diversificada.', 'Cristo Redentor, Pao de Acucar, Copacabana e Santa Teresa.', 'Pacote de 4 dias com hotel, transfer e tour panoramico.', '2026-06-20', 'Brasilia - DF', 2190.00, 'https://images.unsplash.com/photo-1483729558449-99ef09a8c325?auto=format&fit=crop&w=1200&q=80'),
(6, 'Foz do Iguacu', 'Natureza exuberante e uma das maiores quedas d agua do mundo.', 'Extremo oeste do Parana, fronteira com Argentina e Paraguai.', 'Mistura de culturas latino-americanas e gastronomia internacional.', 'Cataratas do Iguacu, Parque das Aves e Usina de Itaipu.', 'Pacote de 3 dias com ingresso para parque e traslado regular.', '2026-07-02', 'Curitiba - PR', 1790.00, 'https://images.unsplash.com/photo-1472396961693-142e6e269027?auto=format&fit=crop&w=1200&q=80'),
(7, 'Maceio', 'Mar azul turquesa e piscinas naturais inesqueciveis.', 'Capital de Alagoas com litoral de aguas mornas e claras.', 'Artesanato regional, culinaria de frutos do mar e ritmo local.', 'Pajucara, Maragogi, Praia do Frances e Sao Miguel dos Milagres.', 'Pacote de 5 dias com passeio de jangada e hospedagem central.', '2026-11-14', 'Goiania - GO', 2590.00, 'https://images.unsplash.com/photo-1501785888041-af3ef285b470?auto=format&fit=crop&w=1200&q=80'),
(8, 'Bonito', 'Ecoturismo com rios transparentes e cavernas fascinantes.', 'Interior de Mato Grosso do Sul, referencia em turismo de natureza.', 'Comunidade voltada ao ecoturismo com praticas sustentaveis.', 'Gruta do Lago Azul, Rio Sucuri, Abismo Anhumas e flutuacao.', 'Pacote de 4 dias com passeios guiados e seguro aventura.', '2026-09-18', 'Campo Grande - MS', 2690.00, 'https://images.unsplash.com/photo-1448375240586-882707db888b?auto=format&fit=crop&w=1200&q=80'),
(9, 'Porto de Galinhas', 'Piscinas naturais e clima tropical o ano todo.', 'Litoral sul de Pernambuco, no municipio de Ipojuca.', 'Ambiente descontraido, gastronomia costeira e artesanato local.', 'Praia de Muro Alto, Vila de Porto, piscinas naturais e buggy.', 'Pacote de 5 dias com traslado, passeio de jangada e hotel.', '2026-12-05', 'Recife - PE', 2490.00, 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=80'),
(10, 'Chapada Diamantina', 'Cachoeiras, grutas e trilhas no coracao da Bahia.', 'Regiao central da Bahia, com base em Lencois e Vale do Capao.', 'Comunidades tradicionais, musica regional e culinaria sertaneja.', 'Poco Azul, Cachoeira da Fumaca, Morro do Pai Inacio e Gruta da Lapa Doce.', 'Pacote de 5 dias com trilhas guiadas, hospedagem e traslados.', '2026-08-22', 'Salvador - BA', 2390.00, 'https://images.unsplash.com/photo-1516815231560-8f41ec531527?auto=format&fit=crop&w=1200&q=80'),
(11, 'Ouro Preto', 'Cidade historica com arquitetura colonial e igrejas barrocas.', 'Serra do Espinhaco, em Minas Gerais, tombada como Patrimonio da Humanidade.', 'Heranca barroca mineira, culinaria tipica e producao artesanal em pedra-sabao.', 'Igreja Sao Francisco de Assis, Mina do Chico Rei, Museu da Inconfidencia e Praca Tiradentes.', 'Pacote de 3 dias com city tour historico, hospedagem e cafe da manha.', '2026-05-12', 'Belo Horizonte - MG', 1490.00, 'https://images.unsplash.com/photo-1580137189272-c9379f8864fd?auto=format&fit=crop&w=1200&q=80'),
(12, 'Florianopolis', 'Mais de 40 praias, lagoas e gastronomia acoriana.', 'Ilha de Santa Catarina, sul do Brasil, com ponte para o continente.', 'Cultura acoriana, festas tradicionais e gastronomia de frutos do mar.', 'Lagoa da Conceicao, Praia do Campeche, Santo Antonio de Lisboa e Jurere.', 'Pacote de 5 dias com hospedagem, city tour e passeio de escuna.', '2026-11-02', 'Porto Alegre - RS', 2290.00, 'https://images.unsplash.com/photo-1540541338287-41700207dee6?auto=format&fit=crop&w=1200&q=80');

-- --------------------------------------------------------

--
-- Estrutura para tabela `reservations`
--

CREATE TABLE `reservations` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `package_id` int(11) NOT NULL,
  `status` varchar(60) NOT NULL DEFAULT 'Confirmada',
  `scheduled_date` date DEFAULT NULL,
  `reserved_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `site_settings`
--

CREATE TABLE `site_settings` (
  `id` int(11) NOT NULL,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `site_settings`
--

INSERT INTO `site_settings` (`id`, `setting_key`, `setting_value`) VALUES
(1, 'site_title', 'Destino Certo Turismo'),
(2, 'hero_subtitle', 'Planeje sua proxima viagem com seguranca e conforto.'),
(3, 'about_title', 'Sobre a Destino Certo Turismo'),
(4, 'about_history', 'Fundada em 2012, a Destino Certo Turismo nasceu com o proposito de conectar pessoas a destinos inesqueciveis com atendimento humanizado e planejamento personalizado.'),
(5, 'about_mission', 'Proporcionar experiencias unicas de viagem com seguranca, praticidade e excelencia em cada etapa.'),
(6, 'about_values', 'Seguranca, qualidade, confianca, transparencia e compromisso com a satisfacao do cliente.'),
(7, 'footer_about', 'Especialistas em roteiros nacionais e internacionais, oferecendo suporte completo do planejamento ao embarque.'),
(8, 'contact_email', 'contato@destinocertoturismo.com'),
(9, 'contact_phone', '(11) 4002-8922'),
(10, 'primary_color', '#0f4c81'),
(11, 'accent_color', '#f6a623'),
(12, 'success_color', '#1ea672');

-- --------------------------------------------------------

--
-- Estrutura para tabela `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(160) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `is_admin`, `created_at`) VALUES
(1, 'Administrador', 'admin@destinocerto.com', '$2y$10$b0UZ4fA7jtyQ5y4MIbUxEeEZjcGge4bAsmOgx12xDE2aGhnpX66rS', 1, '2026-05-29 14:15:54');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_cart_user_package` (`user_id`,`package_id`),
  ADD KEY `idx_cart_user` (`user_id`),
  ADD KEY `idx_cart_package` (`package_id`);

--
-- Índices de tabela `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_favorite_user_package` (`user_id`,`package_id`),
  ADD KEY `idx_favorite_user` (`user_id`),
  ADD KEY `idx_favorite_package` (`package_id`);

--
-- Índices de tabela `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_reservation_user` (`user_id`),
  ADD KEY `fk_reservation_package` (`package_id`);

--
-- Índices de tabela `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `setting_key` (`setting_key`);

--
-- Índices de tabela `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `packages`
--
ALTER TABLE `packages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `cart`
--
ALTER TABLE `cart`
  ADD CONSTRAINT `fk_cart_package` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_cart_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `favorites`
--
ALTER TABLE `favorites`
  ADD CONSTRAINT `fk_favorite_package` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_favorite_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Restrições para tabelas `reservations`
--
ALTER TABLE `reservations`
  ADD CONSTRAINT `fk_reservation_package` FOREIGN KEY (`package_id`) REFERENCES `packages` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_reservation_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
