<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';

requireAdmin();

$packageId = (int)($_GET['id'] ?? 0);
$isEdit = $packageId > 0;

$package = [
    'destination' => '',
    'description' => '',
    'location_info' => '',
    'culture_info' => '',
    'attractions_info' => '',
    'travel_info' => '',
    'travel_date' => '',
    'departure_location' => '',
    'price' => '',
    'image_url' => '',
];

if ($isEdit) {
    $stmt = $pdo->prepare('SELECT * FROM packages WHERE id = ? LIMIT 1');
    $stmt->execute([$packageId]);
    $found = $stmt->fetch();
    if (!$found) {
        setFlash('error', 'Pacote nao encontrado.');
        redirect('/viagens/admin/packages.php');
    }
    $package = $found;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    requireCsrfToken();
    
    $data = [
        'destination' => trim($_POST['destination'] ?? ''),
        'description' => trim($_POST['description'] ?? ''),
        'location_info' => trim($_POST['location_info'] ?? ''),
        'culture_info' => trim($_POST['culture_info'] ?? ''),
        'attractions_info' => trim($_POST['attractions_info'] ?? ''),
        'travel_info' => trim($_POST['travel_info'] ?? ''),
        'travel_date' => trim($_POST['travel_date'] ?? ''),
        'departure_location' => trim($_POST['departure_location'] ?? ''),
        'price' => trim($_POST['price'] ?? ''),
        'image_url' => trim($_POST['image_url'] ?? ''),
    ];

    $errors = [];
    foreach ($data as $key => $value) {
        if ($value === '') {
            $errors[] = 'Preencha todos os campos obrigatorios.';
            break;
        }
    }
    if (!$errors && !is_numeric($data['price'])) {
        $errors[] = 'Preco deve ser um numero valido.';
    }
    if (!$errors && !strtotime($data['travel_date'])) {
        $errors[] = 'Data de viagem invalida.';
    }

    if ($errors) {
        setFlash('error', $errors[0]);
        $package = array_merge($package, $data);
    } else {
        $params = [
            $data['destination'],
            $data['description'],
            $data['location_info'],
            $data['culture_info'],
            $data['attractions_info'],
            $data['travel_info'],
            $data['travel_date'],
            $data['departure_location'],
            (float)$data['price'],
            $data['image_url'],
        ];

        if ($isEdit) {
            $sql = 'UPDATE packages SET destination=?, description=?, location_info=?, culture_info=?, attractions_info=?, travel_info=?, travel_date=?, departure_location=?, price=?, image_url=? WHERE id=?';
            $params[] = $packageId;
            $pdo->prepare($sql)->execute($params);
            setFlash('success', 'Pacote atualizado com sucesso.');
        } else {
            $sql = 'INSERT INTO packages (destination, description, location_info, culture_info, attractions_info, travel_info, travel_date, departure_location, price, image_url) VALUES (?,?,?,?,?,?,?,?,?,?)';
            $pdo->prepare($sql)->execute($params);
            setFlash('success', 'Pacote cadastrado com sucesso.');
        }
        redirect('/viagens/admin/packages.php');
    }
}

renderHeader($pdo, $isEdit ? 'Editar Pacote' : 'Novo Pacote');
renderNav('admin_packages');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1><?= $isEdit ? 'Editar pacote' : 'Novo pacote' ?></h1>
    <p>Preencha todos os campos abaixo para disponibilizar o pacote na vitrine publica.</p>
  </section>

  <section class="card admin-form-card">
    <div class="card-content">
      <form method="post" class="form-grid two-cols">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <label>Destino
          <input type="text" name="destination" value="<?= esc((string)$package['destination']) ?>" required>
        </label>
        <label>Preco (R$)
          <input type="number" step="0.01" min="0" name="price" value="<?= esc((string)$package['price']) ?>" required>
        </label>
        <label>Data da viagem
          <input type="date" name="travel_date" value="<?= esc((string)$package['travel_date']) ?>" required>
        </label>
        <label>Local de saida
          <input type="text" name="departure_location" value="<?= esc((string)$package['departure_location']) ?>" required>
        </label>
        <label class="form-grid-full">URL da imagem
          <input type="url" name="image_url" value="<?= esc((string)$package['image_url']) ?>" required placeholder="https://...">
        </label>
        <label class="form-grid-full">Descricao curta
          <textarea name="description" required><?= esc((string)$package['description']) ?></textarea>
        </label>
        <label>Localizacao (onde fica)
          <textarea name="location_info" required><?= esc((string)$package['location_info']) ?></textarea>
        </label>
        <label>Cultura local
          <textarea name="culture_info" required><?= esc((string)$package['culture_info']) ?></textarea>
        </label>
        <label>Pontos turisticos
          <textarea name="attractions_info" required><?= esc((string)$package['attractions_info']) ?></textarea>
        </label>
        <label>Informacoes da viagem
          <textarea name="travel_info" required><?= esc((string)$package['travel_info']) ?></textarea>
        </label>
        <div class="form-grid-full admin-actions">
          <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Salvar alteracoes' : 'Cadastrar pacote' ?></button>
          <a class="btn btn-secondary" href="/viagens/admin/packages.php">Cancelar</a>
        </div>
      </form>
    </div>
  </section>
</main>
<?php renderFooter(); ?>
