<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';

requireAdmin();

$packages = $pdo->query(
    'SELECT id, destination, price, travel_date, departure_location, image_url
    FROM packages
    ORDER BY id DESC'
)->fetchAll();

renderHeader($pdo, 'Gestao de Pacotes');
renderNav('admin_packages');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Gestao de Pacotes</h1>
    <p>Cadastre, edite ou remova pacotes de viagem oferecidos pelo site.</p>
  </section>

  <div class="admin-actions">
    <a class="btn btn-primary" href="/viagens/admin/package_form.php"><i class="fa-solid fa-plus"></i> Novo pacote</a>
    <a class="btn btn-secondary" href="/viagens/admin/dashboard.php"><i class="fa-solid fa-arrow-left"></i> Voltar ao painel</a>
  </div>

  <section class="table-wrapper">
    <h2>Pacotes cadastrados (<?= count($packages) ?>)</h2>
    <table>
      <thead>
        <tr>
          <th></th>
          <th>Destino</th>
          <th>Saida</th>
          <th>Data</th>
          <th>Preco</th>
          <th>Acoes</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!$packages): ?>
          <tr><td colspan="6">Nenhum pacote cadastrado ainda.</td></tr>
        <?php else: ?>
          <?php foreach ($packages as $package): ?>
            <tr>
              <td><img class="admin-package-thumb lazy" data-src="<?= esc($package['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($package['destination']) ?>"></td>
              <td><?= esc($package['destination']) ?></td>
              <td><?= esc($package['departure_location']) ?></td>
              <td><?= date('d/m/Y', strtotime($package['travel_date'])) ?></td>
              <td>R$ <?= number_format((float)$package['price'], 2, ',', '.') ?></td>
              <td>
                <div class="admin-package-row-actions">
                  <a class="btn btn-secondary btn-sm" href="/viagens/admin/package_form.php?id=<?= (int)$package['id'] ?>">Editar</a>
                  <form class="inline-form" method="post" action="/viagens/admin/package_delete.php" onsubmit="return confirm('Remover o pacote <?= esc(addslashes($package['destination'])) ?>?');">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="id" value="<?= (int)$package['id'] ?>">
                    <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </section>
</main>
<?php renderFooter(); ?>
