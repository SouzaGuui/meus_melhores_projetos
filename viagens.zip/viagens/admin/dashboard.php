<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/layout.php';
require_once __DIR__ . '/../includes/nav.php';

requireAdmin();

$statusFilter = strtolower(trim((string)($_GET['status'] ?? '')));
$allowedStatusFilters = ['confirmada' => 'Confirmada', 'cancelada' => 'Cancelada'];
$statusLabel = $allowedStatusFilters[$statusFilter] ?? null;
$statusQuery = $statusLabel !== null ? '?status=' . urlencode($statusFilter) : '';
$reservationsAnchorUrl = '/viagens/admin/dashboard.php' . $statusQuery . '#reservas-realizadas';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_settings'])) {
    requireCsrfToken();
    
    $settings = [
        'site_title' => trim($_POST['site_title'] ?? ''),
        'hero_subtitle' => trim($_POST['hero_subtitle'] ?? ''),
        'about_title' => trim($_POST['about_title'] ?? ''),
        'about_history' => trim($_POST['about_history'] ?? ''),
        'about_mission' => trim($_POST['about_mission'] ?? ''),
        'about_values' => trim($_POST['about_values'] ?? ''),
        'footer_about' => trim($_POST['footer_about'] ?? ''),
        'contact_email' => trim($_POST['contact_email'] ?? ''),
        'contact_phone' => trim($_POST['contact_phone'] ?? ''),
        'primary_color' => trim($_POST['primary_color'] ?? ''),
        'accent_color' => trim($_POST['accent_color'] ?? ''),
        'success_color' => trim($_POST['success_color'] ?? ''),
    ];

    $stmt = $pdo->prepare(
        'INSERT INTO site_settings (setting_key, setting_value)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)'
    );
    foreach ($settings as $key => $value) {
        $stmt->execute([$key, $value]);
    }

    setFlash('success', 'Configurações atualizadas com sucesso.');
    redirect('/viagens/admin/dashboard.php');
}

$users = $pdo->query('SELECT id, name, email, is_admin, created_at FROM users ORDER BY created_at DESC')->fetchAll();
$reservationsSql = 'SELECT r.id, r.status, r.reserved_at, u.name AS user_name, p.destination, p.price
    FROM reservations r
    INNER JOIN users u ON u.id = r.user_id
    INNER JOIN packages p ON p.id = r.package_id';
$reservationParams = [];

if ($statusLabel !== null) {
    $reservationsSql .= ' WHERE r.status = ?';
    $reservationParams[] = $statusLabel;
}

$reservationsSql .= ' ORDER BY r.reserved_at DESC';
$reservationsStmt = $pdo->prepare($reservationsSql);
$reservationsStmt->execute($reservationParams);
$reservations = $reservationsStmt->fetchAll();

// Enhanced statistics
$allReservations = $pdo->query('SELECT r.status, p.price FROM reservations r INNER JOIN packages p ON p.id = r.package_id')->fetchAll();
$confirmedCount = count(array_filter($allReservations, fn($r) => strcasecmp($r['status'], 'Confirmada') === 0));
$canceledCount = count(array_filter($allReservations, fn($r) => strcasecmp($r['status'], 'Cancelada') === 0));
$totalRevenue = array_sum(array_column(array_filter($allReservations, fn($r) => strcasecmp($r['status'], 'Confirmada') === 0), 'price'));
$packageCount = $pdo->query('SELECT COUNT(*) AS total FROM packages')->fetchColumn();

$topTrips = $pdo->query(
    'SELECT p.destination, COUNT(r.id) AS total
    FROM reservations r
    INNER JOIN packages p ON p.id = r.package_id
    GROUP BY p.destination
    ORDER BY total DESC
    LIMIT 5'
)->fetchAll();

renderHeader($pdo, 'Painel Admin');
renderNav('admin');
?>
<main class="container">
  <?php renderAlerts(); ?>
  <section class="page-header">
    <h1>Dashboard Administrativo</h1>
    <p>Controle usuários, reservas, pacotes e aparência do site.</p>
  </section>

  <div class="admin-actions">
    <a class="btn btn-primary" href="/viagens/admin/packages.php"><i class="fa-solid fa-suitcase-rolling"></i> Gerenciar pacotes</a>
    <a class="btn btn-secondary" href="/viagens/pacotes.php" target="_blank" rel="noopener"><i class="fa-solid fa-eye"></i> Visualizar site</a>
  </div>

  <section class="stats-grid">
    <article class="stat-card"><h3>Total de usuários</h3><strong><?= count($users) ?></strong></article>
    <article class="stat-card"><h3>Total de reservas</h3><strong><?= count($allReservations) ?></strong></article>
    <article class="stat-card"><h3>Reservas confirmadas</h3><strong><?= $confirmedCount ?></strong></article>
    <article class="stat-card"><h3>Reservas canceladas</h3><strong><?= $canceledCount ?></strong></article>
    <article class="stat-card"><h3>Receita total</h3><strong>R$ <?= number_format((float)$totalRevenue, 2, ',', '.') ?></strong></article>
    <article class="stat-card"><h3>Pacotes ativos</h3><strong><?= (int)$packageCount ?></strong></article>
  </section>

  <section class="table-wrapper" id="reservas-realizadas">
    <h2>Usuários cadastrados</h2>
    <table>
      <thead><tr><th>Nome</th><th>Email</th><th>Perfil</th><th>Cadastro</th></tr></thead>
      <tbody>
      <?php foreach ($users as $user): ?>
        <tr>
          <td><?= esc($user['name']) ?></td>
          <td><?= esc($user['email']) ?></td>
          <td><?= (int)$user['is_admin'] === 1 ? 'Admin' : 'Cliente' ?></td>
          <td><?= date('d/m/Y H:i', strtotime($user['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section class="table-wrapper">
    <div class="section-title">
      <h2>Reservas realizadas<?= $statusLabel !== null ? ' - ' . esc($statusLabel) : '' ?></h2>
      <nav class="category-filters" aria-label="Filtrar reservas por status">
        <a class="category-chip<?= $statusLabel === null ? ' is-active' : '' ?>" href="/viagens/admin/dashboard.php#reservas-realizadas">Todas</a>
        <a class="category-chip<?= $statusFilter === 'confirmada' ? ' is-active' : '' ?>" href="/viagens/admin/dashboard.php?status=confirmada#reservas-realizadas">Confirmada</a>
        <a class="category-chip<?= $statusFilter === 'cancelada' ? ' is-active' : '' ?>" href="/viagens/admin/dashboard.php?status=cancelada#reservas-realizadas">Cancelada</a>
      </nav>
    </div>
    <table>
      <thead><tr><th>Cliente</th><th>Destino</th><th>Status</th><th>Data</th><th>Acoes</th></tr></thead>
      <tbody>
      <?php foreach ($reservations as $reservation): ?>
        <tr>
          <td><?= esc($reservation['user_name']) ?></td>
          <td><?= esc($reservation['destination']) ?></td>
          <td><?= esc($reservation['status']) ?></td>
          <td><?= date('d/m/Y H:i', strtotime($reservation['reserved_at'])) ?></td>
          <td>
            <?php if (strcasecmp((string)$reservation['status'], 'Cancelada') !== 0): ?>
              <form method="post" action="/viagens/admin/reservation_cancel.php" class="inline-form" onsubmit="return confirm('Deseja cancelar esta reserva?');">
                <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                <input type="hidden" name="reservation_id" value="<?= (int)$reservation['id'] ?>">
                <input type="hidden" name="redirect_to" value="<?= esc($reservationsAnchorUrl) ?>">
                <button type="submit" class="btn btn-danger btn-sm">Cancelar</button>
              </form>
            <?php endif; ?>
            <form method="post" action="/viagens/admin/reservation_delete.php" class="inline-form" onsubmit="return confirm('Deseja excluir esta reserva do painel?');">
              <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
              <input type="hidden" name="reservation_id" value="<?= (int)$reservation['id'] ?>">
              <input type="hidden" name="redirect_to" value="<?= esc($reservationsAnchorUrl) ?>">
              <button type="submit" class="btn btn-secondary btn-sm">Excluir</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </section>

  <section class="card admin-form-card">
    <div class="card-content">
      <h2>Personalização do site</h2>
      <form method="post" class="form-grid two-cols">
        <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
        <input type="hidden" name="update_settings" value="1">
        <label>Título do site
          <input type="text" name="site_title" value="<?= esc(siteSetting($pdo, 'site_title')) ?>" required>
        </label>
        <label>Subtítulo
          <input type="text" name="hero_subtitle" value="<?= esc(siteSetting($pdo, 'hero_subtitle')) ?>" required>
        </label>
        <label>Titulo da secao Sobre
          <input type="text" name="about_title" value="<?= esc(siteSetting($pdo, 'about_title')) ?>" required>
        </label>
        <label>Historia da empresa
          <input type="text" name="about_history" value="<?= esc(siteSetting($pdo, 'about_history')) ?>" required>
        </label>
        <label>Missao
          <input type="text" name="about_mission" value="<?= esc(siteSetting($pdo, 'about_mission')) ?>" required>
        </label>
        <label>Valores
          <input type="text" name="about_values" value="<?= esc(siteSetting($pdo, 'about_values')) ?>" required>
        </label>
        <label>Texto institucional do rodape
          <input type="text" name="footer_about" value="<?= esc(siteSetting($pdo, 'footer_about')) ?>" required>
        </label>
        <label>Email de contato
          <input type="email" name="contact_email" value="<?= esc(siteSetting($pdo, 'contact_email')) ?>" required>
        </label>
        <label>Telefone de contato
          <input type="text" name="contact_phone" value="<?= esc(siteSetting($pdo, 'contact_phone')) ?>" required>
        </label>
        <label>Cor principal
          <input type="color" name="primary_color" value="<?= esc(siteSetting($pdo, 'primary_color', '#0f4c81')) ?>">
        </label>
        <label>Cor de destaque
          <input type="color" name="accent_color" value="<?= esc(siteSetting($pdo, 'accent_color', '#f6a623')) ?>">
        </label>
        <label>Cor de sucesso
          <input type="color" name="success_color" value="<?= esc(siteSetting($pdo, 'success_color', '#1ea672')) ?>">
        </label>
        <button type="submit" class="btn btn-primary">Salvar alterações</button>
      </form>
    </div>
  </section>
</main>
<?php renderFooter(); ?>
