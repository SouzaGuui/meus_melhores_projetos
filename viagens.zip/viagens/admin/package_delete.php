<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireAdmin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('/viagens/admin/packages.php');
}

requireCsrfToken();

$packageId = (int)($_POST['id'] ?? 0);
if ($packageId <= 0) {
    setFlash('error', 'Pacote invalido.');
    redirect('/viagens/admin/packages.php');
}

$stmt = $pdo->prepare('DELETE FROM packages WHERE id = ?');
$stmt->execute([$packageId]);

setFlash('success', 'Pacote removido com sucesso.');
redirect('/viagens/admin/packages.php');
