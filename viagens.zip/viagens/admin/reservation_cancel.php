<?php
declare(strict_types=1);

require_once __DIR__ . '/../includes/db.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

requireAdmin();

$fallbackRedirect = '/viagens/admin/dashboard.php#reservas-realizadas';
$redirectTo = (string)($_POST['redirect_to'] ?? $fallbackRedirect);
if (!str_starts_with($redirectTo, '/viagens/')) {
    $redirectTo = $fallbackRedirect;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect($fallbackRedirect);
}

requireCsrfToken();

$reservationId = (int)($_POST['reservation_id'] ?? 0);
if ($reservationId <= 0) {
    setFlash('error', 'Reserva invalida.');
    redirect($redirectTo);
}

$checkStmt = $pdo->prepare('SELECT id, status FROM reservations WHERE id = ? LIMIT 1');
$checkStmt->execute([$reservationId]);
$reservation = $checkStmt->fetch();

if (!$reservation) {
    setFlash('error', 'Reserva nao encontrada.');
    redirect($redirectTo);
}

if (strcasecmp((string)$reservation['status'], 'Cancelada') === 0) {
    setFlash('error', 'Esta reserva ja esta cancelada.');
    redirect($redirectTo);
}

$cancelStmt = $pdo->prepare('UPDATE reservations SET status = "Cancelada" WHERE id = ?');
$cancelStmt->execute([$reservationId]);

setFlash('success', 'Reserva cancelada com sucesso.');
redirect($redirectTo);
