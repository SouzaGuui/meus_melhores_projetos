<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/layout.php';
require_once __DIR__ . '/includes/nav.php';
require_once __DIR__ . '/includes/favorites.php';
require_once __DIR__ . '/includes/categories.php';

$loggedIn = isLoggedIn();
$packages = $pdo->query('SELECT id, destination, price, image_url FROM packages ORDER BY id DESC LIMIT 3')->fetchAll();
$favoriteIds = $loggedIn ? getFavoritePackageIds($pdo) : [];
$categories = getCategories();
$siteSubtitle = siteSetting($pdo, 'hero_subtitle', 'Planeje sua proxima viagem com seguranca e conforto.');
$aboutTitle = siteSetting($pdo, 'about_title', 'Sobre a Destino Certo Turismo');
$aboutHistory = siteSetting($pdo, 'about_history', 'Agencia especialista em turismo com atendimento personalizado.');
$aboutMission = siteSetting($pdo, 'about_mission', 'Proporcionar experiencias unicas de viagem.');
$aboutValues = siteSetting($pdo, 'about_values', 'Seguranca, qualidade e confianca.');
$footerAbout = siteSetting($pdo, 'footer_about', 'Especialistas em roteiros nacionais e internacionais.');
$contactEmail = siteSetting($pdo, 'contact_email', 'contato@destinocertoturismo.com');
$contactPhone = siteSetting($pdo, 'contact_phone', '(11) 4002-8922');

renderHeader($pdo, 'Home');
?>
<?php renderPublicNav($loggedIn, 'inicio'); ?>

<main class="home-main">
  <section class="hero-section">
    <div class="hero-overlay"></div>
    <div class="container hero-content">
      <p class="hero-kicker">Experiências inesquecíveis, do planejamento ao embarque</p>
      <h1>Descubra o destino perfeito para a sua próxima viagem</h1>
      <p><?= esc($siteSubtitle) ?></p>
      <a class="btn btn-accent" href="/viagens/pacotes.php">Explorar pacotes</a>
    </div>
  </section>

  <section class="container home-section" id="sobre">
    <div class="section-heading">
      <h2><?= esc($aboutTitle) ?></h2>
    </div>
    <div class="about-grid">
      <div class="about-media">
        <img src="https://images.unsplash.com/photo-1488085061387-422e29b40080?auto=format&fit=crop&w=1400&q=80" alt="Equipe da agencia de viagens">
      </div>
      <div class="about-content">
        <h3>Nossa história</h3>
        <p><?= esc($aboutHistory) ?></p>
        <h3>Missão</h3>
        <p><?= esc($aboutMission) ?></p>
        <h3>Valores</h3>
        <p><?= esc($aboutValues) ?></p>
      </div>
    </div>
  </section>

  <section class="container home-section" id="categorias">
    <div class="section-heading">
      <h2>Categorias para todos os estilos de viagem</h2>
      <p>Escolha o tipo de experiência que combina com o seu momento e veja apenas os pacotes relacionados.</p>
    </div>
    <div class="category-grid">
      <?php foreach ($categories as $slug => $cat): ?>
        <a class="category-card"
           href="/viagens/pacotes.php?categoria=<?= esc($slug) ?>"
           style="background-image:url('<?= esc($cat['image']) ?>');"
           title="<?= esc($cat['headline']) ?>">
          <span class="category-card-body">
            <span class="category-card-title"><i class="<?= esc($cat['icon']) ?>" aria-hidden="true"></i><?= esc($cat['label']) ?></span>
            <span class="category-card-desc"><?= esc($cat['headline']) ?></span>
          </span>
        </a>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="container home-section">
    <div class="section-heading">
      <h2>Pacotes em destaque</h2>
      <p>Uma seleção dos destinos mais procurados pelos nossos clientes para a próxima reserva.</p>
    </div>
    <div class="card-grid">
      <?php foreach ($packages as $package): ?>
        <?php $isFav = $loggedIn && in_array((int)$package['id'], $favoriteIds, true); ?>
        <article class="card">
          <img class="lazy" data-src="<?= esc($package['image_url']) ?>" src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1 1'%3E%3C/svg%3E" alt="<?= esc($package['destination']) ?>">
          <div class="card-content">
            <h3><?= esc($package['destination']) ?></h3>
            <div class="card-footer">
              <span class="price">R$ <?= number_format((float)$package['price'], 2, ',', '.') ?></span>
              <div class="action-group">
                <?php if ($loggedIn): ?>
                  <form method="post" action="/viagens/user/favorite_toggle.php" class="inline-form">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
                    <input type="hidden" name="redirect_to" value="/viagens/index.php">
                    <button type="submit" class="btn btn-fav btn-sm btn-icon-action<?= $isFav ? ' is-active' : '' ?>" title="<?= $isFav ? 'Remover dos favoritos' : 'Favoritar pacote' ?>">
                      <i class="<?= $isFav ? 'fa-solid' : 'fa-regular' ?> fa-heart"></i>
                    </button>
                  </form>
                <?php else: ?>
                  <a class="btn btn-fav btn-sm btn-icon-action" href="/viagens/login.php?redirect=/viagens/index.php" title="Faca login para favoritar">
                    <i class="fa-regular fa-heart"></i>
                  </a>
                <?php endif; ?>
                <?php if ($loggedIn): ?>
                  <form method="post" action="/viagens/user/cart_add.php" class="inline-form">
                    <input type="hidden" name="csrf_token" value="<?= generateCsrfToken() ?>">
                    <input type="hidden" name="package_id" value="<?= (int)$package['id'] ?>">
                    <input type="hidden" name="redirect_to" value="/viagens/index.php">
                    <button type="submit" class="btn btn-secondary btn-sm btn-icon-action" title="Adicionar ao carrinho">
                      <i class="fa-solid fa-cart-plus"></i>
                    </button>
                  </form>
                <?php else: ?>
                  <a class="btn btn-secondary btn-sm btn-icon-action" href="/viagens/login.php?redirect=/viagens/index.php" title="Faça login para adicionar ao carrinho">
                    <i class="fa-solid fa-cart-plus"></i>
                  </a>
                <?php endif; ?>
                <a class="btn btn-primary btn-sm btn-text-action" href="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?>#agendar">Agendar</a>
              </div>
            </div>
            <a class="details-link" href="/viagens/pacote_detalhes.php?id=<?= (int)$package['id'] ?>">Ver detalhes</a>
          </div>
        </article>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="container home-section">
    <div class="section-heading">
      <h2>Por que viajar com a Destino Certo?</h2>
    </div>
    <div class="benefits-grid">
      <article class="benefit-card"><i class="fa-solid fa-bolt"></i><h3>Reserva simplificada</h3><p>Processo rápido e intuitivo, concluído em poucos cliques a partir de qualquer dispositivo.</p></article>
      <article class="benefit-card"><i class="fa-solid fa-shield-halved"></i><h3>Segurança e confiança</h3><p>Seus dados são armazenados com proteção e cada reserva é confirmada antes do embarque.</p></article>
      <article class="benefit-card"><i class="fa-solid fa-headset"></i><h3>Suporte humanizado</h3><p>Atendimento dedicado para esclarecer dúvidas e acompanhá-lo antes, durante e após a viagem.</p></article>
      <article class="benefit-card"><i class="fa-solid fa-tags"></i><h3>Melhores preços</h3><p>Tarifas competitivas e parcerias que garantem o melhor custo-benefício do mercado.</p></article>
    </div>
  </section>

  <section class="container">
    <div class="cta-box">
      <h2>Pronto para viajar?</h2>
      <p>Crie a sua conta gratuitamente e comece agora a montar o roteiro dos seus sonhos com o suporte da nossa equipe.</p>
      <a class="btn btn-accent" href="/viagens/cadastro.php">Criar conta gratuita</a>
    </div>
  </section>
</main>

<footer class="home-footer" id="contato">
  <div class="container footer-grid">
    <div>
      <h3>Destino Certo Turismo</h3>
      <p><?= esc($footerAbout) ?></p>
    </div>
    <div>
      <h4>Links úteis</h4>
      <a href="/viagens/index.php">Início</a>
      <a href="/viagens/pacotes.php">Pacotes</a>
      <a href="/viagens/login.php">Entrar</a>
      <a href="/viagens/cadastro.php">Cadastrar</a>
    </div>
    <div>
      <h4>Contato</h4>
      <a href="mailto:<?= esc($contactEmail) ?>"><?= esc($contactEmail) ?></a>
      <a href="tel:<?= esc(preg_replace('/\s+/', '', $contactPhone)) ?>"><?= esc($contactPhone) ?></a>
      <p class="copyright">© <?= date('Y') ?> Destino Certo Turismo. Todos os direitos reservados.</p>
    </div>
  </div>
</footer>
<?php renderFooter(); ?>
