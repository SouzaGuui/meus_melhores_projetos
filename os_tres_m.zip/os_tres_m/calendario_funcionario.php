<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requirePermission('calendario.view');

$user = currentUser();
$nivel = getNivelAcesso();
$funcionarioId = (int)($_GET['id'] ?? $user['id']);

if ($nivel === 'funcionario') {
    $funcionarioId = (int)$user['id'];
}

$pdo = db();
$stmt = $pdo->prepare('SELECT id, nome, cargo, setor, foto_perfil, nivel_acesso FROM usuarios WHERE id = ? AND status = ?');
$stmt->execute([$funcionarioId, 'ativo']);
$funcionario = $stmt->fetch();

if (!$funcionario) {
    header('Location: calendario.php');
    exit;
}

if (($funcionario['nivel_acesso'] ?? '') === 'admin' && $nivel !== 'admin' && !can('*')) {
    header('Location: ' . BASE_URL . 'acesso_negado.php');
    exit;
}

if (in_array($nivel, ['gerente', 'coordenacao'], true) && ($funcionario['setor'] ?? '') !== ($user['setor'] ?? '')) {
    header('Location: acesso_negado.php');
    exit;
}

$pageTitle = 'Calendário — ' . $funcionario['nome'];
$breadcrumb = 'Calendário Individual';
$mes = (int)($_GET['mes'] ?? date('n'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$mesesPt = [1=>'Janeiro',2=>'Fevereiro',3=>'Março',4=>'Abril',5=>'Maio',6=>'Junho',7=>'Julho',8=>'Agosto',9=>'Setembro',10=>'Outubro',11=>'Novembro',12=>'Dezembro'];
$voltarUrl = can('calendario.filter_team') ? 'calendario.php' : 'dashboard.php';

$extraCSS = '<link href="' . BASE_URL . 'assets/css/calendario.css?v=' . filemtime(__DIR__ . '/assets/css/calendario.css') . '" rel="stylesheet">';
include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <div class="cal-func-hero">
                <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div class="d-flex align-items-center gap-3 flex-grow-1 min-w-0">
                        <a href="<?= htmlspecialchars($voltarUrl) ?>" class="btn btn-outline btn-sm flex-shrink-0"><i class="bi bi-arrow-left"></i></a>
                        <div class="cal-func-avatar">
                            <?php if ($funcionario['foto_perfil']): ?>
                            <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($funcionario['foto_perfil']) ?>" alt="">
                            <?php else: ?>
                            <?= strtoupper(mb_substr($funcionario['nome'], 0, 1)) ?>
                            <?php endif; ?>
                        </div>
                        <div class="min-w-0">
                            <h2 style="font-size:22px;font-weight:800;margin:0"><?= htmlspecialchars($funcionario['nome']) ?></h2>
                            <p style="color:var(--text-muted);font-size:13px;margin:4px 0 0">
                                <?= htmlspecialchars($funcionario['cargo'] ?: '—') ?> · <?= htmlspecialchars($funcionario['setor'] ?: '—') ?>
                            </p>
                            <span class="cal-func-status mt-2" id="calStatusAtual" style="background:var(--bg-secondary);color:var(--text-muted)">—</span>
                        </div>
                    </div>
                    <div class="d-flex gap-2 align-items-center flex-shrink-0">
                        <a href="?id=<?= $funcionarioId ?>&mes=<?= $mes <= 1 ? 12 : $mes - 1 ?>&ano=<?= $mes <= 1 ? $ano - 1 : $ano ?>" class="btn btn-outline btn-sm"><i class="bi bi-chevron-left"></i></a>
                        <span style="font-weight:700;min-width:140px;text-align:center"><?= ($mesesPt[$mes] ?? '') . ' ' . $ano ?></span>
                        <a href="?id=<?= $funcionarioId ?>&mes=<?= $mes >= 12 ? 1 : $mes + 1 ?>&ano=<?= $mes >= 12 ? $ano + 1 : $ano ?>" class="btn btn-outline btn-sm"><i class="bi bi-chevron-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4" id="calResumoCards">
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="cal-stat-card green cal-stat-animate">
                        <span class="cal-stat-val" data-k="taxa_presenca">—</span>
                        <span class="cal-stat-lbl">Taxa presença</span>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="cal-stat-card green cal-stat-animate">
                        <span class="cal-stat-val" data-k="presentes">—</span>
                        <span class="cal-stat-lbl">Presentes</span>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="cal-stat-card red cal-stat-animate">
                        <span class="cal-stat-val" data-k="faltas">—</span>
                        <span class="cal-stat-lbl">Faltas</span>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="cal-stat-card yellow cal-stat-animate">
                        <span class="cal-stat-val" data-k="atrasos">—</span>
                        <span class="cal-stat-lbl">Atrasos</span>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="cal-stat-card purple cal-stat-animate">
                        <span class="cal-stat-val" data-k="horas_extras">—</span>
                        <span class="cal-stat-lbl">H. extras (mês)</span>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-lg-2">
                    <div class="cal-stat-card blue cal-stat-animate">
                        <span class="cal-stat-val" data-k="banco_horas">—</span>
                        <span class="cal-stat-lbl">Banco horas</span>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-3">
                <div class="col-6 col-md-3">
                    <div class="card h-100"><div class="card-body text-center">
                        <div style="font-size:24px;font-weight:800;color:var(--roxo-claro)" id="calProdutividade">—</div>
                        <div style="font-size:12px;color:var(--text-muted)">Produtividade (tarefas)</div>
                    </div></div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card h-100"><div class="card-body text-center">
                        <div style="font-size:24px;font-weight:800;color:var(--verde)" id="calTarefasConcluidas">—</div>
                        <div style="font-size:12px;color:var(--text-muted)">Tarefas concluídas</div>
                    </div></div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card h-100"><div class="card-body text-center">
                        <div style="font-size:24px;font-weight:800;color:var(--azul-claro)" id="calHorasTrab">—</div>
                        <div style="font-size:12px;color:var(--text-muted)">Horas trabalhadas</div>
                    </div></div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="card h-100"><div class="card-body text-center">
                        <div style="font-size:24px;font-weight:800;color:var(--amarelo)" id="calFerias">—</div>
                        <div style="font-size:12px;color:var(--text-muted)">Dias férias/folga</div>
                    </div></div>
                </div>
            </div>

            <div class="cal-legend d-flex flex-wrap gap-2 mb-3">
                <span class="legend-item" style="border-left-color:#10B981">Presente</span>
                <span class="legend-item" style="border-left-color:#EF4444">Falta</span>
                <span class="legend-item" style="border-left-color:#F59E0B">Atrasado</span>
                <span class="legend-item" style="border-left-color:#3B82F6">Férias</span>
                <span class="legend-item" style="border-left-color:#7C3AED">Evento/Reunião</span>
                <span class="legend-item" style="border-left-color:#F97316">Hora extra</span>
            </div>

            <div class="row g-3">
                <div class="col-lg-8">
                    <div class="card mb-3">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-calendar3 me-2"></i>Calendário mensal</h5></div>
                        <div class="card-body">
                            <div id="calMiniGrid" class="cal-mini-month"></div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header"><h5 class="card-title mb-0"><i class="bi bi-calendar-week me-2"></i>Resumo semanal</h5></div>
                        <div class="card-body" id="calResumoSemanal"></div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="card mb-3">
                        <div class="card-header"><h5 class="card-title mb-0">Presença no mês</h5></div>
                        <div class="card-body">
                            <div class="cal-func-chart-wrap">
                                <canvas id="chartPresencaMes"></canvas>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3">
                        <div class="card-header"><h5 class="card-title mb-0">Detalhe do dia</h5></div>
                        <div class="card-body" id="calDiaDetalhe">
                            <p class="text-muted small mb-0">Clique em um dia no calendário.</p>
                        </div>
                    </div>
                    <div class="card mb-3">
                        <div class="card-header"><h5 class="card-title mb-0">Horas extras do mês</h5></div>
                        <div class="card-body p-0" id="calListaHE" style="max-height:200px;overflow-y:auto"></div>
                    </div>
                    <div class="card">
                        <div class="card-header"><h5 class="card-title mb-0">Tarefas do mês</h5></div>
                        <div class="card-body p-0" id="calListaTarefas" style="max-height:220px;overflow-y:auto"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$extraJS = '<script>window.CAL_FUNC_CONFIG=' . json_encode([
    'baseUrl' => BASE_URL,
    'usuarioId' => $funcionarioId,
    'mes' => $mes,
    'ano' => $ano,
], JSON_UNESCAPED_UNICODE) . ';</script>
<script src="' . BASE_URL . 'assets/js/calendario-funcionario.js"></script>';
include 'includes/footer.php';
