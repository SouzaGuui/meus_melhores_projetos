<?php
// ============================================
// RBAC — Controle de Permissões por Perfil
// Os Três M - Sistema Empresarial
// ============================================

$PERMISSOES_POR_NIVEL = [
    'funcionario' => [
        'dashboard.view',
        'perfil.edit_own',
        'ponto.register',
        'ponto.view_own',
        'ponto.report_absence',
        'horas_extras.register',
        'horas_extras.view_own',
        'tarefas.view_own',
        'tarefas.update_status_own',
        'chat.use',
        'notificacoes.view',
        'calendario.view',
        'calendario.edit_own',
    ],
    'coordenacao' => [
        'dashboard.view',
        'perfil.edit_own',
        'ponto.view_own',
        'ponto.view_team',
        'ponto.report_absence',
        'ponto.approve_absence',
        'horas_extras.approve',
        'horas_extras.view_team',
        'export.data',
        'tarefas.view_team',
        'tarefas.update_status_own',
        'funcionarios.view_team',
        'relatorios.basic',
        'chat.use',
        'notificacoes.view',
        'calendario.view',
        'calendario.filter_team',
        'calendario.edit_own',
        'calendario.remove_events',
    ],
    'gerente' => [
        'dashboard.view',
        'perfil.edit_own',
        'ponto.view_own',
        'ponto.view_team',
        'ponto.report_absence',
        'ponto.approve_absence',
        'horas_extras.approve',
        'horas_extras.view_team',
        'export.data',
        'tarefas.view_team',
        'tarefas.create',
        'tarefas.edit_own_created',
        'tarefas.update_status_own',
        'funcionarios.view',
        'funcionarios.create',
        'funcionarios.edit_limited',
        'relatorios.basic',
        'chat.use',
        'notificacoes.view',
        'calendario.view',
        'calendario.filter_team',
        'calendario.edit_own',
        'calendario.remove_events',
    ],
    'rh' => [
        'dashboard.view',
        'perfil.edit_own',
        'perfil.view_others',
        'ponto.view_own',
        'ponto.view_team',
        'ponto.report_absence',
        'ponto.approve_absence',
        'horas_extras.approve',
        'horas_extras.view_team',
        'export.data',
        'tarefas.view_team',
        'tarefas.create',
        'tarefas.edit_all',
        'funcionarios.view',
        'funcionarios.create',
        'funcionarios.edit',
        'funcionarios.reset_password',
        'funcionarios.view_salario',
        'pagamento.view',
        'pagamento.edit',
        'relatorios.full',
        'chat.use',
        'notificacoes.view',
        'calendario.view',
        'calendario.filter_team',
        'calendario.manage',
        'calendario.remove_events',
    ],
    'admin' => ['*'],
];

$PAGINA_PERMISSOES = [
    'dashboard'     => 'dashboard.view',
    'perfil'        => 'perfil.edit_own',
    'ponto'         => 'ponto.view_own',
    'tarefas'       => 'tarefas.view_own',
    'chat'          => 'chat.use',
    'notificacoes'  => 'notificacoes.view',
    'funcionarios'  => 'funcionarios.view',
    'pagamento'     => 'pagamento.view',
    'relatorios'    => 'relatorios.basic',
    'calendario'    => 'calendario.view',
    'configuracoes' => 'configuracoes.view',
    'logs'          => 'logs.view',
];

$PERFIS_CADASTRO_PERMITIDOS = [
    'admin'       => ['funcionario', 'coordenacao', 'gerente', 'rh', 'admin'],
    'rh'          => ['funcionario', 'coordenacao', 'gerente', 'rh'],
    'gerente'     => ['funcionario', 'coordenacao', 'gerente'],
    'coordenacao' => [],
    'funcionario' => [],
];

function getNivelAcesso(): string {
    return $_SESSION['nivel_acesso'] ?? '';
}

function getPermissoesNivel(?string $nivel = null): array {
    global $PERMISSOES_POR_NIVEL;
    $nivel = $nivel ?? getNivelAcesso();
    return $PERMISSOES_POR_NIVEL[$nivel] ?? [];
}

function can(string $permission): bool {
    if (!isLoggedIn()) {
        return false;
    }
    $perms = getPermissoesNivel();
    if (in_array('*', $perms, true)) {
        return true;
    }
    if (in_array($permission, $perms, true)) {
        return true;
    }
    if ($permission === 'relatorios.basic' && in_array('relatorios.full', $perms, true)) {
        return true;
    }
    if ($permission === 'funcionarios.view' && in_array('funcionarios.view_team', $perms, true)) {
        return true;
    }
    if ($permission === 'funcionarios.view_team' && in_array('funcionarios.view', $perms, true)) {
        return true;
    }
    if ($permission === 'tarefas.view_own' && (in_array('tarefas.view_team', $perms, true) || in_array('tarefas.create', $perms, true))) {
        return true;
    }
    if ($permission === 'configuracoes.view' || $permission === 'configuracoes.edit' || $permission === 'logs.view') {
        return in_array('*', $perms, true);
    }
    return false;
}

function canAny(array $permissions): bool {
    foreach ($permissions as $p) {
        if (can($p)) {
            return true;
        }
    }
    return false;
}

function requirePermission(string $permission): void {
    requireLogin();
    if (!can($permission)) {
        if (function_exists('registrarLog')) {
            registrarLog('acesso_negado', 'Sem permissão: ' . $permission);
        }
        header('Location: ' . BASE_URL . 'acesso_negado.php');
        exit;
    }
}

function requireAnyPermission(array $permissions): void {
    requireLogin();
    if (!canAny($permissions)) {
        if (function_exists('registrarLog')) {
            registrarLog('acesso_negado', 'Sem permissão: ' . implode('|', $permissions));
        }
        header('Location: ' . BASE_URL . 'acesso_negado.php');
        exit;
    }
}

function hasPermission($levels): bool {
    if (!is_array($levels)) {
        $levels = [$levels];
    }
    return in_array(getNivelAcesso(), $levels, true);
}

function requireLevel($levels): void {
    requireLogin();
    if (!hasPermission($levels)) {
        header('Location: ' . BASE_URL . 'acesso_negado.php');
        exit;
    }
}

function menuCan(string $item): bool {
    $map = [
        'dashboard'     => 'dashboard.view',
        'perfil'        => 'perfil.edit_own',
        'ponto'         => 'ponto.view_own',
        'tarefas'       => ['tarefas.view_own', 'tarefas.view_team'],
        'chat'          => 'chat.use',
        'funcionarios'  => ['funcionarios.view', 'funcionarios.view_team'],
        'pagamento'     => 'pagamento.view',
        'relatorios'    => ['relatorios.basic', 'relatorios.full'],
        'configuracoes' => 'configuracoes.view',
        'logs'          => 'logs.view',
        'notificacoes'  => 'notificacoes.view',
        'calendario'    => 'calendario.view',
    ];
    if (!isset($map[$item])) {
        return false;
    }
    $req = $map[$item];
    return is_array($req) ? canAny($req) : can($req);
}

function perfisDisponiveisCadastro(): array {
    global $PERFIS_CADASTRO_PERMITIDOS;
    return $PERFIS_CADASTRO_PERMITIDOS[getNivelAcesso()] ?? [];
}

function podeCadastrarFuncionario(): bool {
    return can('funcionarios.create');
}

function podeEditarFuncionarioCompleto(): bool {
    return can('funcionarios.edit');
}

function podeEditarFuncionarioLimitado(): bool {
    return can('funcionarios.edit_limited') || can('funcionarios.edit');
}

function podeVerSalarios(): bool {
    return can('funcionarios.view_salario');
}

function podeDesativarFuncionario(): bool {
    return getNivelAcesso() === 'admin';
}

function podeCriarTarefa(): bool {
    return can('tarefas.create');
}

function podeEditarTarefa(array $tarefa): bool {
    $user = currentUser();
    if (can('*') || can('tarefas.edit_all')) {
        return true;
    }
    if (can('tarefas.edit_own_created') && (int)($tarefa['criado_por'] ?? 0) === (int)$user['id']) {
        return true;
    }
    return false;
}

function podeVerPontoDeOutros(): bool {
    return can('ponto.view_team');
}

function relatoriosPermitidos(): array {
    $todos = ['funcionarios', 'ponto', 'presenca', 'ausencias', 'horas_extras', 'tarefas', 'produtividade', 'pagamento'];
    if (can('relatorios.full')) {
        return $todos;
    }
    if (can('relatorios.basic')) {
        return array_values(array_diff($todos, ['pagamento']));
    }
    return [];
}

function podeExportar(): bool {
    return can('export.data') || can('*');
}

function deveOcultarPerfilAdmin(?array $usuarioRow = null): bool {
    if (getNivelAcesso() === 'admin' || can('*')) {
        return false;
    }
    if ($usuarioRow !== null) {
        return ($usuarioRow['nivel_acesso'] ?? '') === 'admin';
    }
    return true;
}

function sqlOcultarAdmin(string $alias = ''): string {
    if (getNivelAcesso() === 'admin' || can('*')) {
        return '';
    }
    $col = $alias !== '' ? "{$alias}.nivel_acesso" : 'nivel_acesso';
    return " AND {$col} <> 'admin'";
}

function protegerPagina(string $page): void {
    global $PAGINA_PERMISSOES;
    if (!isset($PAGINA_PERMISSOES[$page])) {
        return;
    }
    if ($page === 'funcionarios' && canAny(['funcionarios.view', 'funcionarios.view_team'])) {
        return;
    }
    if ($page === 'tarefas' && canAny(['tarefas.view_own', 'tarefas.view_team'])) {
        return;
    }
    if ($page === 'relatorios' && canAny(['relatorios.basic', 'relatorios.full'])) {
        return;
    }
    if ($page === 'configuracoes' || $page === 'logs') {
        requireLevel(['admin']);
        return;
    }
    requirePermission($PAGINA_PERMISSOES[$page]);
}
