<?php
// ============================================
// GERENCIAMENTO DE SESSÃO
// Os Três M - Sistema Empresarial
// ============================================

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400 * 30, // 30 dias para persistir ao fechar navegador
        'path'     => '/',
        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Lax' // Lax funciona melhor com navegação entre abas
    ]);
    session_start();
    
    // Regenerar ID da sessão periodicamente para segurança
    if (!isset($_SESSION['created'])) {
        $_SESSION['created'] = time();
    } else if (time() - $_SESSION['created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['created'] = time();
    }
}

function isLoggedIn() {
    return isset($_SESSION['usuario_id']) && !empty($_SESSION['usuario_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
}

// requireLevel, hasPermission, can — definidos em permissions.php (carregado via functions.php)

function currentUser() {
    return [
        'id'           => $_SESSION['usuario_id'] ?? null,
        'nome'         => $_SESSION['nome'] ?? '',
        'email'        => $_SESSION['email'] ?? '',
        'nivel_acesso' => $_SESSION['nivel_acesso'] ?? '',
        'foto_perfil'  => $_SESSION['foto_perfil'] ?? null,
        'cargo'        => $_SESSION['cargo'] ?? '',
        'setor'        => $_SESSION['setor'] ?? '',
    ];
}

function setSession($usuario) {
    $_SESSION['usuario_id']   = $usuario['id'];
    $_SESSION['nome']         = $usuario['nome'];
    $_SESSION['email']        = $usuario['email'];
    $_SESSION['nivel_acesso'] = $usuario['nivel_acesso'];
    $_SESSION['foto_perfil']  = $usuario['foto_perfil'];
    $_SESSION['cargo']        = $usuario['cargo'];
    $_SESSION['setor']        = $usuario['setor'];
}

function logout() {
    session_unset();
    session_destroy();
    header('Location: ' . BASE_URL . 'login.php');
    exit;
}

function nivelLabel($nivel) {
    $labels = [
        'funcionario' => 'Funcionário',
        'coordenacao' => 'Coordenação',
        'rh'          => 'RH',
        'gerente'     => 'Gerente',
        'admin'       => 'Administrador',
    ];
    return $labels[$nivel] ?? $nivel;
}
