<?php
// ============================================
// FUNÇÕES AUXILIARES GLOBAIS
// Os Três M - Sistema Empresarial
// ============================================

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/session.php';

// --- Segurança ---
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function hashSenha($senha) {
    return password_hash($senha, PASSWORD_BCRYPT, ['cost' => 12]);
}

function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

// --- Validações ---
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) != 11 || preg_match('/(\d)\1{10}/', $cpf)) return false;
    for ($t = 9; $t < 11; $t++) {
        $d = 0;
        for ($c = 0; $c < $t; $c++) $d += $cpf[$c] * (($t + 1) - $c);
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) return false;
    }
    return true;
}

function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// --- Formatações ---
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

function formatarData($data) {
    if (!$data) return '-';
    return date('d/m/Y', strtotime($data));
}

function formatarDataHora($data) {
    if (!$data) return '-';
    return date('d/m/Y H:i', strtotime($data));
}

function formatarHora($hora) {
    if (!$hora) return '--:--';
    return substr($hora, 0, 5);
}

function calcularHoras($entrada, $saida) {
    if (!$entrada || !$saida) return 0;
    $e = strtotime($entrada);
    $s = strtotime($saida);
    return round(($s - $e) / 3600, 2);
}

// --- Upload de imagem ---
function uploadFoto($file, $pasta = 'perfil') {
    $dir = UPLOAD_PATH . $pasta . '/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $permitidos = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($ext, $permitidos)) return ['erro' => 'Formato não permitido.'];
    if ($file['size'] > 5 * 1024 * 1024) return ['erro' => 'Arquivo muito grande (máx 5MB).'];

    $nome = uniqid('foto_') . '.' . $ext;
    $destino = $dir . $nome;
    if (move_uploaded_file($file['tmp_name'], $destino)) {
        return ['sucesso' => true, 'arquivo' => $pasta . '/' . $nome];
    }
    return ['erro' => 'Erro ao salvar arquivo.'];
}

// --- Notificações ---
function criarNotificacao($usuario_id, $titulo, $mensagem, $tipo = 'sistema', $link = null) {
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo, link) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$usuario_id, $titulo, $mensagem, $tipo, $link]);
}

function contarNotificacoes($usuario_id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND lida = 0");
    $stmt->execute([$usuario_id]);
    return $stmt->fetchColumn();
}

function getNotificacoes($usuario_id, $limit = 10) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id = ? ORDER BY criado_em DESC LIMIT ?");
    $stmt->execute([$usuario_id, $limit]);
    return $stmt->fetchAll();
}

// --- Logs ---
function registrarLog($acao, $descricao = '', $usuario_id = null) {
    $pdo = db();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $uid = $usuario_id ?? ($_SESSION['usuario_id'] ?? null);
    $stmt = $pdo->prepare("INSERT INTO logs_sistema (usuario_id, acao, descricao, ip) VALUES (?, ?, ?, ?)");
    $stmt->execute([$uid, $acao, $descricao, $ip]);
}

// --- Usuários ---
function getUsuario($id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getUsuarios($status = 'ativo') {
    $pdo = db();
    if ($status === 'todos') {
        return $pdo->query("SELECT * FROM usuarios ORDER BY nome")->fetchAll();
    }
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE status = ? ORDER BY nome");
    $stmt->execute([$status]);
    return $stmt->fetchAll();
}

function atualizarOnline($usuario_id, $online = 1) {
    $pdo = db();
    $stmt = $pdo->prepare("UPDATE usuarios SET online = ?, ultimo_acesso = NOW() WHERE id = ?");
    $stmt->execute([$online, $usuario_id]);
}

// --- Ponto ---
function getPontoHoje($usuario_id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM ponto WHERE usuario_id = ? AND data = CURDATE()");
    $stmt->execute([$usuario_id]);
    return $stmt->fetch();
}

// --- Tarefas ---
function getTarefasUsuario($usuario_id) {
    $pdo = db();
    $stmt = $pdo->prepare("
        SELECT t.*, u.nome as criado_por_nome 
        FROM tarefas t 
        JOIN usuarios u ON t.criado_por = u.id 
        WHERE t.atribuido_para = ? 
        ORDER BY t.criado_em DESC
    ");
    $stmt->execute([$usuario_id]);
    return $stmt->fetchAll();
}

// --- Dashboard stats ---
function getDashboardStats() {
    $pdo = db();
    $stats = [];
    $stats['total_funcionarios'] = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE status='ativo'")->fetchColumn();
    $stats['funcionarios_online'] = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE online=1 AND status='ativo'")->fetchColumn();
    $stats['tarefas_pendentes'] = $pdo->query("SELECT COUNT(*) FROM tarefas WHERE status='pendente'")->fetchColumn();
    $stats['tarefas_andamento'] = $pdo->query("SELECT COUNT(*) FROM tarefas WHERE status='em_andamento'")->fetchColumn();
    $stats['tarefas_concluidas'] = $pdo->query("SELECT COUNT(*) FROM tarefas WHERE status='concluida'")->fetchColumn();
    $folha = $pdo->query("SELECT SUM(valor_final) FROM folha_pagamento WHERE mes=MONTH(NOW()) AND ano=YEAR(NOW())")->fetchColumn();
    $stats['folha_mensal'] = $folha ?? 0;
    $stats['presentes_hoje'] = $pdo->query("SELECT COUNT(*) FROM ponto WHERE data=CURDATE() AND status='presente'")->fetchColumn();
    $stats['atrasos_hoje'] = $pdo->query("SELECT COUNT(*) FROM ponto WHERE data=CURDATE() AND atraso > 0")->fetchColumn();
    return $stats;
}

// --- Resposta JSON ---
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// --- CSRF ---
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verificarCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
