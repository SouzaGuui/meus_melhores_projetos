<?php
// ============================================
// FUNÇÕES AUXILIARES GLOBAIS
// Os Três M - Sistema Empresarial
// ============================================

require_once __DIR__ . '/database.php';
require_once __DIR__ . '/session.php';
require_once __DIR__ . '/permissions.php';

// --- Segurança ---
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

function hashSenha($senha) {
    return password_hash($senha, PASSWORD_BCRYPT, ['cost' => 12]);
}

function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

// --- Validações ---
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) != 11 || preg_match('/(\d)\1{10}/', $cpf)) return false;
    for ($t = 9; $t < 11; $t++) {
        $d = 0;
        for ($c = 0; $c < $t; $c++) $d += $cpf[$c] * (($t + 1) - $c);
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) return false;
    }
    return true;
}

function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

// --- Formatações ---
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

function formatarData($data) {
    if (!$data) return '-';
    return date('d/m/Y', strtotime($data));
}

function formatarDataHora($data) {
    if (!$data) return '-';
    return date('d/m/Y H:i', strtotime($data));
}

function formatarHora($hora) {
    if (!$hora) return '--:--';
    return substr($hora, 0, 5);
}

function calcularHoras($entrada, $saida) {
    if (!$entrada || !$saida) return 0;
    $e = strtotime($entrada);
    $s = strtotime($saida);
    return round(($s - $e) / 3600, 2);
}

// --- Upload de imagem ---
function uploadFoto($file, $pasta = 'perfil') {
    $dir = UPLOAD_PATH . $pasta . '/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $permitidos = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($ext, $permitidos)) return ['erro' => 'Formato não permitido.'];
    if ($file['size'] > 5 * 1024 * 1024) return ['erro' => 'Arquivo muito grande (máx 5MB).'];

    $nome = uniqid('foto_') . '.' . $ext;
    $destino = $dir . $nome;
    if (move_uploaded_file($file['tmp_name'], $destino)) {
        return ['sucesso' => true, 'arquivo' => $pasta . '/' . $nome];
    }
    return ['erro' => 'Erro ao salvar arquivo.'];
}

// --- Notificações ---
function criarNotificacao($usuario_id, $titulo, $mensagem, $tipo = 'sistema', $link = null) {
    $pdo = db();
    $stmt = $pdo->prepare("INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo, link) VALUES (?, ?, ?, ?, ?)");
    return $stmt->execute([$usuario_id, $titulo, $mensagem, $tipo, $link]);
}

function contarNotificacoes($usuario_id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notificacoes WHERE usuario_id = ? AND lida = 0");
    $stmt->execute([$usuario_id]);
    return $stmt->fetchColumn();
}

function getNotificacoes($usuario_id, $limit = 10) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id = ? ORDER BY criado_em DESC LIMIT ?");
    $stmt->execute([$usuario_id, $limit]);
    return $stmt->fetchAll();
}

// --- Logs ---
function registrarLog($acao, $descricao = '', $usuario_id = null) {
    $pdo = db();
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $uid = $usuario_id ?? ($_SESSION['usuario_id'] ?? null);
    $stmt = $pdo->prepare("INSERT INTO logs_sistema (usuario_id, acao, descricao, ip) VALUES (?, ?, ?, ?)");
    $stmt->execute([$uid, $acao, $descricao, $ip]);
}

// --- Usuários ---
function getUsuario($id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function getUsuarios($status = 'ativo', bool $ocultarAdmin = true) {
    $pdo = db();
    $filtroAdmin = ($ocultarAdmin && function_exists('sqlOcultarAdmin')) ? sqlOcultarAdmin() : '';
    if ($status === 'todos') {
        return $pdo->query("SELECT * FROM usuarios WHERE 1=1 {$filtroAdmin} ORDER BY nome")->fetchAll();
    }
    $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE status = ? {$filtroAdmin} ORDER BY nome");
    $stmt->execute([$status]);
    return $stmt->fetchAll();
}

function garantirTabelaPontoAusencias(): void {
    static $ok = false;
    if ($ok) {
        return;
    }
    $pdo = db();
    try {
        $pdo->query('SELECT 1 FROM ponto_ausencias LIMIT 1');
        $ok = true;
        return;
    } catch (Exception $e) {
        $sql = file_get_contents(__DIR__ . '/../database/ponto_ausencias.sql');
        if ($sql) {
            $pdo->exec($sql);
        }
        $ok = true;
    }
}

function podeInformarFalta(): bool {
    return can('ponto.report_absence') || can('ponto.register') || can('*');
}

function podeAprovarFalta(): bool {
    return can('ponto.approve_absence') || can('*');
}

function garantirTabelaHorasExtras(): void {
    static $ok = false;
    if ($ok) {
        return;
    }
    $pdo = db();
    try {
        $pdo->query('SELECT 1 FROM horas_extras_solicitacoes LIMIT 1');
        $ok = true;
        return;
    } catch (Exception $e) {
        $sql = file_get_contents(__DIR__ . '/../database/horas_extras_solicitacoes.sql');
        if ($sql) {
            $pdo->exec($sql);
        }
        $ok = true;
    }
}

function podeRegistrarHorasExtras(): bool {
    return can('horas_extras.register') || can('*');
}

function podeAprovarHorasExtras(): bool {
    return can('horas_extras.approve') || can('*');
}

function podeVerHorasExtrasEquipe(): bool {
    return can('horas_extras.view_team') || can('*');
}

function podeVerRelatorioHorasExtras(): bool {
    return podeVerHorasExtrasEquipe();
}

function podeRemoverEventoCalendario(): bool {
    return can('calendario.remove_events') || can('calendario.manage') || can('*');
}

function podeEditarEventoCalendario(array $ev, array $user): bool {
    if (can('calendario.manage') || can('*')) {
        return true;
    }
    if (can('calendario.edit_own') && (int)($ev['criado_por'] ?? 0) === (int)$user['id']) {
        return true;
    }
    return false;
}

function atualizarOnline($usuario_id, $online = 1) {
    $pdo = db();
    $stmt = $pdo->prepare("UPDATE usuarios SET online = ?, ultimo_acesso = NOW() WHERE id = ?");
    $stmt->execute([$online, $usuario_id]);
}

// --- Ponto ---
function getPontoHoje($usuario_id) {
    $pdo = db();
    $stmt = $pdo->prepare("SELECT * FROM ponto WHERE usuario_id = ? AND data = CURDATE()");
    $stmt->execute([$usuario_id]);
    return $stmt->fetch();
}

// --- Tarefas ---
function getTarefasUsuario($usuario_id) {
    $pdo = db();
    $stmt = $pdo->prepare("
        SELECT t.*, u.nome as criado_por_nome 
        FROM tarefas t 
        JOIN usuarios u ON t.criado_por = u.id 
        WHERE t.atribuido_para = ? 
        ORDER BY t.criado_em DESC
    ");
    $stmt->execute([$usuario_id]);
    return $stmt->fetchAll();
}

// --- Dashboard stats ---
function getDashboardStats() {
    $pdo = db();
    $user = currentUser();
    $nivel = $user['nivel_acesso'] ?? 'funcionario';
    $uid = (int)($user['id'] ?? 0);
    $setor = $user['setor'] ?? '';
    $stats = [];

    if ($nivel === 'funcionario') {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para = ? AND status = 'pendente'");
        $stmt->execute([$uid]);
        $stats['tarefas_pendentes'] = $stmt->fetchColumn();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para = ? AND status = 'em_andamento'");
        $stmt->execute([$uid]);
        $stats['tarefas_andamento'] = $stmt->fetchColumn();
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para = ? AND status = 'concluida'");
        $stmt->execute([$uid]);
        $stats['tarefas_concluidas'] = $stmt->fetchColumn();
        $stats['total_funcionarios'] = 1;
        $stats['funcionarios_online'] = 1;
        $stats['folha_mensal'] = 0;
        $stats['presentes_hoje'] = 0;
        $stats['atrasos_hoje'] = 0;
        $ponto = getPontoHoje($uid);
        $stats['ponto_hoje'] = $ponto ? ($ponto['entrada'] ? 1 : 0) : 0;
        return $stats;
    }

    if (in_array($nivel, ['coordenacao', 'gerente'], true) && $setor) {
        $stmtEq = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE status='ativo' AND setor = ?" . sqlOcultarAdmin());
        $stmtEq->execute([$setor]);
        $stats['total_funcionarios'] = $stmtEq->fetchColumn();
    } else {
        $stats['total_funcionarios'] = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE status='ativo'" . sqlOcultarAdmin())->fetchColumn();
    }

    $stats['funcionarios_online'] = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE online=1 AND status='ativo'" . sqlOcultarAdmin())->fetchColumn();

    if (in_array($nivel, ['coordenacao', 'gerente'], true) && $setor) {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM tarefas t
            JOIN usuarios u ON t.atribuido_para = u.id
            WHERE t.status = 'pendente' AND u.setor = ?
        ");
        $stmt->execute([$setor]);
        $stats['tarefas_pendentes'] = $stmt->fetchColumn();
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM tarefas t
            JOIN usuarios u ON t.atribuido_para = u.id
            WHERE t.status = 'em_andamento' AND u.setor = ?
        ");
        $stmt->execute([$setor]);
        $stats['tarefas_andamento'] = $stmt->fetchColumn();
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM tarefas t
            JOIN usuarios u ON t.atribuido_para = u.id
            WHERE t.status = 'concluida' AND u.setor = ?
        ");
        $stmt->execute([$setor]);
        $stats['tarefas_concluidas'] = $stmt->fetchColumn();
    } else {
        $stats['tarefas_pendentes'] = $pdo->query("SELECT COUNT(*) FROM tarefas WHERE status='pendente'")->fetchColumn();
        $stats['tarefas_andamento'] = $pdo->query("SELECT COUNT(*) FROM tarefas WHERE status='em_andamento'")->fetchColumn();
        $stats['tarefas_concluidas'] = $pdo->query("SELECT COUNT(*) FROM tarefas WHERE status='concluida'")->fetchColumn();
    }

    if (podeVerSalarios()) {
        $folha = $pdo->query("SELECT SUM(valor_final) FROM folha_pagamento WHERE mes=MONTH(NOW()) AND ano=YEAR(NOW())")->fetchColumn();
        $stats['folha_mensal'] = $folha ?? 0;
    } else {
        $stats['folha_mensal'] = 0;
    }

    $stats['presentes_hoje'] = $pdo->query("SELECT COUNT(*) FROM ponto p JOIN usuarios u ON p.usuario_id = u.id WHERE p.data=CURDATE() AND p.status='presente'" . sqlOcultarAdmin('u'))->fetchColumn();
    $stats['atrasos_hoje'] = $pdo->query("SELECT COUNT(*) FROM ponto p JOIN usuarios u ON p.usuario_id = u.id WHERE p.data=CURDATE() AND p.atraso > 0" . sqlOcultarAdmin('u'))->fetchColumn();
    $stats['mostrar_folha'] = podeVerSalarios();
    $stats['perfil_dashboard'] = $nivel;
    if (!isset($stats['ponto_hoje'])) {
        $stats['ponto_hoje'] = 0;
    }

    return $stats;
}

// --- Resposta JSON ---
function jsonResponse($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// --- CSRF ---
function csrfToken() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verificarCSRF($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}
