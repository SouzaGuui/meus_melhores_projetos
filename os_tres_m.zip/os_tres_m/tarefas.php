<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Tarefas';
$breadcrumb = 'Tarefas';
$user = currentUser();
$pdo = db();

// Salvar tarefa
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $acao = $_POST['acao'];

    if ($acao === 'salvar' && podeCriarTarefa()) {
        $id = (int)($_POST['id'] ?? 0);
        $titulo = sanitize($_POST['titulo'] ?? '');
        $descricao = sanitize($_POST['descricao'] ?? '');
        $atribuido = (int)($_POST['atribuido_para'] ?? 0);
        $prazo = sanitize($_POST['prazo'] ?? '');
        $prioridade = sanitize($_POST['prioridade'] ?? 'media');
        $status = sanitize($_POST['status'] ?? 'pendente');
        $obs = sanitize($_POST['observacoes'] ?? '');

        if (!$titulo || !$atribuido) {
            jsonResponse(['erro' => 'Preencha os campos obrigatórios.']);
        }

        if ($id > 0) {
            $tarefaAtual = $pdo->prepare("SELECT * FROM tarefas WHERE id = ?");
            $tarefaAtual->execute([$id]);
            $tarefaRow = $tarefaAtual->fetch();
            if (!$tarefaRow || !podeEditarTarefa($tarefaRow)) {
                header('Location: ' . BASE_URL . 'acesso_negado.php');
                exit;
            }
            $pdo->prepare("UPDATE tarefas SET titulo=?,descricao=?,atribuido_para=?,prazo=?,prioridade=?,status=?,observacoes=? WHERE id=?")
                ->execute([$titulo,$descricao,$atribuido,$prazo?:null,$prioridade,$status,$obs,$id]);
            criarNotificacao($atribuido, 'Tarefa Atualizada', "A tarefa \"$titulo\" foi atualizada.", 'tarefa', 'tarefas.php');
            registrarLog('editar_tarefa', "Tarefa ID $id editada");
        } else {
            $pdo->prepare("INSERT INTO tarefas (titulo,descricao,criado_por,atribuido_para,prazo,prioridade,status,observacoes) VALUES (?,?,?,?,?,?,?,?)")
                ->execute([$titulo,$descricao,$user['id'],$atribuido,$prazo?:null,$prioridade,$status,$obs]);
            criarNotificacao($atribuido, 'Nova Tarefa Atribuída', "Você recebeu a tarefa: \"$titulo\".", 'tarefa', 'tarefas.php');
            registrarLog('nova_tarefa', "Nova tarefa: $titulo");
        }
        header('Location: tarefas.php?msg=Tarefa+salva+com+sucesso&tipo=success');
        exit;
    }

    if ($acao === 'status') {
        $id = (int)($_POST['id'] ?? 0);
        $novoStatus = sanitize($_POST['status'] ?? '');
        if (!can('tarefas.view_team')) {
            $permitidos = ['pendente', 'em_andamento', 'concluida'];
            if (!in_array($novoStatus, $permitidos, true)) {
                jsonResponse(['erro' => 'Status não permitido.'], 403);
            }
            $chk = $pdo->prepare('SELECT id FROM tarefas WHERE id = ? AND atribuido_para = ?');
            $chk->execute([$id, $user['id']]);
            if (!$chk->fetch()) {
                jsonResponse(['erro' => 'Tarefa não encontrada.'], 404);
            }
            $pdo->prepare('UPDATE tarefas SET status = ? WHERE id = ? AND atribuido_para = ?')
                ->execute([$novoStatus, $id, $user['id']]);
        } else {
            $pdo->prepare('UPDATE tarefas SET status = ? WHERE id = ?')
                ->execute([$novoStatus, $id]);
        }
        jsonResponse(['sucesso' => true]);
    }

    if ($acao === 'excluir' && (getNivelAcesso() === 'admin' || can('tarefas.edit_all'))) {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM tarefas WHERE id=?")->execute([$id]);
        header('Location: tarefas.php?msg=Tarefa+excluída&tipo=success');
        exit;
    }
}

// Filtros
$filtroStatus = sanitize($_GET['status'] ?? 'todos');
$filtroPrioridade = sanitize($_GET['prioridade'] ?? '');
$busca = sanitize($_GET['busca'] ?? '');
$view = sanitize($_GET['view'] ?? 'lista');

$where = "WHERE 1=1";
$params = [];

if (!can('tarefas.view_team')) {
    $where .= " AND t.atribuido_para = ?";
    $params[] = $user['id'];
} elseif (getNivelAcesso() === 'coordenacao' || getNivelAcesso() === 'gerente') {
    if (!empty($user['setor'])) {
        $where .= " AND EXISTS (SELECT 1 FROM usuarios u2 WHERE u2.id = t.atribuido_para AND u2.setor = ?)";
        $params[] = $user['setor'];
    }
}

if ($filtroStatus !== 'todos') { $where .= " AND t.status = ?"; $params[] = $filtroStatus; }
if ($filtroPrioridade) { $where .= " AND t.prioridade = ?"; $params[] = $filtroPrioridade; }
if ($busca) { $where .= " AND (t.titulo LIKE ? OR t.descricao LIKE ?)"; $params[] = "%$busca%"; $params[] = "%$busca%"; }

$stmt = $pdo->prepare("
    SELECT t.*, 
           u1.nome as atribuido_nome, u1.foto_perfil as atribuido_foto,
           u2.nome as criado_nome
    FROM tarefas t
    JOIN usuarios u1 ON t.atribuido_para = u1.id
    JOIN usuarios u2 ON t.criado_por = u2.id
    $where
    ORDER BY FIELD(t.prioridade,'urgente','alta','media','baixa'), t.prazo ASC, t.criado_em DESC
");
$stmt->execute($params);
$tarefas = $stmt->fetchAll();

// Contadores
$contadores = ['pendente'=>0,'em_andamento'=>0,'concluida'=>0,'cancelada'=>0];
foreach ($tarefas as $t) { if (isset($contadores[$t['status']])) $contadores[$t['status']]++; }

$funcionarios = getUsuarios('ativo');
$mensagem = sanitize($_GET['msg'] ?? '');
$tipoMsg = sanitize($_GET['tipo'] ?? 'info');
$modoFuncionario = !can('tarefas.view_team');
if ($modoFuncionario) {
    $view = 'lista';
}

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <?php if ($mensagem): ?>
            <div class="alert alert-<?= $tipoMsg ?> fade-in mb-3">
                <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($mensagem) ?>
            </div>
            <?php endif; ?>

            <!-- Header -->
            <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div>
                    <h2 style="font-size:20px;font-weight:800;color:var(--text-primary);margin:0">Gestão de Tarefas</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0"><?= count($tarefas) ?> tarefa(s)</p>
                </div>
                <div class="d-flex gap-2">
                    <?php if (!$modoFuncionario): ?>
                    <div class="btn-group">
                        <a href="?view=lista<?= $filtroStatus!=='todos'?'&status='.$filtroStatus:'' ?>" class="btn btn-outline btn-sm <?= $view==='lista'?'active':'' ?>">
                            <i class="bi bi-list-ul"></i>
                        </a>
                        <a href="?view=kanban<?= $filtroStatus!=='todos'?'&status='.$filtroStatus:'' ?>" class="btn btn-outline btn-sm <?= $view==='kanban'?'active':'' ?>">
                            <i class="bi bi-kanban"></i>
                        </a>
                    </div>
                    <?php endif; ?>
                    <?php if (podeCriarTarefa()): ?>
                    <button class="btn btn-primary" onclick="abrirModalTarefa()">
                        <i class="bi bi-plus-circle-fill"></i> Nova Tarefa
                    </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Contadores -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <a href="?status=pendente" class="stat-card yellow text-decoration-none d-flex">
                        <div class="stat-icon yellow"><i class="bi bi-hourglass"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $contadores['pendente'] ?></div>
                            <div class="stat-label">Pendentes</div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-md-3">
                    <a href="?status=em_andamento" class="stat-card blue text-decoration-none d-flex">
                        <div class="stat-icon blue"><i class="bi bi-arrow-repeat"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $contadores['em_andamento'] ?></div>
                            <div class="stat-label">Em Andamento</div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-md-3">
                    <a href="?status=concluida" class="stat-card green text-decoration-none d-flex">
                        <div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $contadores['concluida'] ?></div>
                            <div class="stat-label">Concluídas</div>
                        </div>
                    </a>
                </div>
                <div class="col-6 col-md-3">
                    <a href="?status=todos" class="stat-card purple text-decoration-none d-flex">
                        <div class="stat-icon purple"><i class="bi bi-list-check"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= count($tarefas) ?></div>
                            <div class="stat-label">Total</div>
                        </div>
                    </a>
                </div>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <input type="hidden" name="view" value="<?= $view ?>">
                        <div class="col-12 col-md-4">
                            <label class="form-label">Pesquisar</label>
                            <input type="text" name="busca" class="form-control" placeholder="Título ou descrição..." value="<?= htmlspecialchars($busca) ?>">
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="todos">Todos</option>
                                <option value="pendente" <?= $filtroStatus==='pendente'?'selected':'' ?>>Pendente</option>
                                <option value="em_andamento" <?= $filtroStatus==='em_andamento'?'selected':'' ?>>Em Andamento</option>
                                <option value="concluida" <?= $filtroStatus==='concluida'?'selected':'' ?>>Concluída</option>
                                <?php if (!$modoFuncionario): ?><option value="cancelada" <?= $filtroStatus==='cancelada'?'selected':'' ?>>Cancelada</option><?php endif; ?>
                            </select>
                        </div>
                        <?php if (!$modoFuncionario): ?>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Prioridade</label>
                            <select name="prioridade" class="form-select">
                                <option value="">Todas</option>
                                <option value="urgente" <?= $filtroPrioridade==='urgente'?'selected':'' ?>>Urgente</option>
                                <option value="alta" <?= $filtroPrioridade==='alta'?'selected':'' ?>>Alta</option>
                                <option value="media" <?= $filtroPrioridade==='media'?'selected':'' ?>>Média</option>
                                <option value="baixa" <?= $filtroPrioridade==='baixa'?'selected':'' ?>>Baixa</option>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="col-12 col-md-4 d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-search"></i> Filtrar</button>
                            <a href="tarefas.php" class="btn btn-outline"><i class="bi bi-x"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <?php if ($view === 'kanban' && !$modoFuncionario): ?>
            <!-- KANBAN VIEW -->
            <div class="row g-3">
                <?php
                $colunas = [
                    'pendente' => ['label'=>'Pendente','color'=>'var(--amarelo)','icon'=>'hourglass'],
                    'em_andamento' => ['label'=>'Em Andamento','color'=>'var(--azul-claro)','icon'=>'arrow-repeat'],
                    'concluida' => ['label'=>'Concluída','color'=>'var(--verde)','icon'=>'check-circle'],
                    'cancelada' => ['label'=>'Cancelada','color'=>'var(--vermelho)','icon'=>'x-circle'],
                ];
                foreach ($colunas as $colStatus => $col):
                    $colTarefas = array_filter($tarefas, fn($t) => $t['status'] === $colStatus);
                ?>
                <div class="col-12 col-md-6 col-xl-3">
                    <div class="card h-100">
                        <div class="card-header" style="border-left:3px solid <?= $col['color'] ?>">
                            <h6 class="card-title" style="color:<?= $col['color'] ?>">
                                <i class="bi bi-<?= $col['icon'] ?> me-2"></i><?= $col['label'] ?>
                            </h6>
                            <span class="badge" style="background:<?= $col['color'] ?>20;color:<?= $col['color'] ?>;font-size:11px"><?= count($colTarefas) ?></span>
                        </div>
                        <div class="card-body" style="padding:12px;display:flex;flex-direction:column;gap:10px;min-height:200px">
                            <?php foreach ($colTarefas as $t): ?>
                            <div class="kanban-card" style="background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:10px;padding:14px;cursor:pointer" onclick="editarTarefa(<?= htmlspecialchars(json_encode($t)) ?>)">
                                <div class="d-flex justify-content-between align-items-start mb-2">
                                    <span class="badge-status prioridade-<?= $t['prioridade'] ?>"><?= ucfirst($t['prioridade']) ?></span>
                                    <?php if ($t['prazo']): ?>
                                    <span style="font-size:11px;color:<?= strtotime($t['prazo']) < time() && $t['status']!=='concluida' ? 'var(--vermelho)' : 'var(--text-muted)' ?>">
                                        <i class="bi bi-calendar3"></i> <?= formatarData($t['prazo']) ?>
                                    </span>
                                    <?php endif; ?>
                                </div>
                                <p style="font-size:13px;font-weight:600;color:var(--text-primary);margin-bottom:8px"><?= htmlspecialchars($t['titulo']) ?></p>
                                <?php if ($t['descricao']): ?>
                                <p style="font-size:12px;color:var(--text-muted);margin-bottom:8px"><?= htmlspecialchars(substr($t['descricao'],0,80)) ?>...</p>
                                <?php endif; ?>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="user-avatar" style="width:24px;height:24px;font-size:10px">
                                        <?= strtoupper(substr($t['atribuido_nome'],0,2)) ?>
                                    </div>
                                    <span style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars(explode(' ',$t['atribuido_nome'])[0]) ?></span>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php if (empty($colTarefas)): ?>
                            <div style="text-align:center;padding:24px;color:var(--text-muted);font-size:13px">
                                <i class="bi bi-inbox" style="font-size:24px;display:block;margin-bottom:8px"></i>
                                Nenhuma tarefa
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php else: ?>
            <!-- LISTA VIEW -->
            <div class="table-wrapper">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tarefa</th>
                                <?php if (!$modoFuncionario): ?><th>Atribuído a</th><th>Criado por</th><th>Prioridade</th><?php endif; ?>
                                <th>Prazo</th>
                                <th>Status</th>
                                <?php if (!$modoFuncionario): ?><th>Ações</th><?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tarefas)): ?>
                            <tr>
                                <td colspan="<?= $modoFuncionario ? 3 : 7 ?>" class="text-center" style="padding:40px;color:var(--text-muted)">
                                    <i class="bi bi-check2-square" style="font-size:32px;display:block;margin-bottom:8px"></i>
                                    Nenhuma tarefa encontrada
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($tarefas as $t): ?>
                            <tr>
                                <td>
                                    <div style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($t['titulo']) ?></div>
                                    <?php if ($t['descricao']): ?>
                                    <div style="font-size:12px;color:var(--text-muted);margin-top:6px;white-space:pre-wrap"><?= nl2br(htmlspecialchars($t['descricao'])) ?></div>
                                    <?php endif; ?>
                                </td>
                                <?php if (!$modoFuncionario): ?>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="user-avatar" style="width:28px;height:28px;font-size:11px">
                                            <?= strtoupper(substr($t['atribuido_nome'],0,2)) ?>
                                        </div>
                                        <span style="font-size:13px"><?= htmlspecialchars(explode(' ',$t['atribuido_nome'])[0]) ?></span>
                                    </div>
                                </td>
                                <td style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars(explode(' ',$t['criado_nome'])[0]) ?></td>
                                <td><span class="badge-status prioridade-<?= $t['prioridade'] ?>"><?= ucfirst($t['prioridade']) ?></span></td>
                                <?php endif; ?>
                                <td style="font-size:12px;color:<?= $t['prazo'] && strtotime($t['prazo']) < time() && $t['status']!=='concluida' ? 'var(--vermelho)' : 'var(--text-muted)' ?>">
                                    <?= $t['prazo'] ? formatarData($t['prazo']) : '-' ?>
                                </td>
                                <td>
                                    <select class="form-select form-select-sm status-select" style="width:auto;font-size:12px;min-width:130px" data-id="<?= $t['id'] ?>" onchange="atualizarStatus(this)">
                                        <option value="pendente" <?= $t['status']==='pendente'?'selected':'' ?>>Pendente</option>
                                        <option value="em_andamento" <?= $t['status']==='em_andamento'?'selected':'' ?>>Em Andamento</option>
                                        <option value="concluida" <?= $t['status']==='concluida'?'selected':'' ?>>Concluída</option>
                                        <?php if (!$modoFuncionario): ?><option value="cancelada" <?= $t['status']==='cancelada'?'selected':'' ?>>Cancelada</option><?php endif; ?>
                                    </select>
                                </td>
                                <?php if (!$modoFuncionario): ?>
                                <td>
                                    <div class="d-flex gap-1">
                                        <?php if (podeEditarTarefa($t)): ?>
                                        <button class="btn btn-outline btn-icon btn-sm" onclick="editarTarefa(<?= htmlspecialchars(json_encode($t)) ?>)" title="Editar">
                                            <i class="bi bi-pencil-fill" style="color:var(--azul-claro)"></i>
                                        </button>
                                        <button class="btn btn-outline btn-icon btn-sm" onclick="excluirTarefa(<?= $t['id'] ?>)" title="Excluir">
                                            <i class="bi bi-trash-fill" style="color:var(--vermelho)"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<!-- Modal Tarefa -->
<div class="modal fade" id="modalTarefa" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="tarefaModalTitulo"><i class="bi bi-plus-circle me-2"></i>Nova Tarefa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" id="formTarefa">
                <input type="hidden" name="acao" value="salvar">
                <input type="hidden" name="id" id="tarefaId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Título *</label>
                            <input type="text" name="titulo" id="tarefaTitulo" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Descrição</label>
                            <textarea name="descricao" id="tarefaDesc" class="form-control" rows="3"></textarea>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Atribuir para *</label>
                            <select name="atribuido_para" id="tarefaAtribuido" class="form-select" required>
                                <option value="">Selecione...</option>
                                <?php foreach ($funcionarios as $f): ?>
                                <option value="<?= $f['id'] ?>"><?= htmlspecialchars($f['nome']) ?> — <?= htmlspecialchars($f['cargo'] ?: $f['setor']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Prazo</label>
                            <input type="date" name="prazo" id="tarefaPrazo" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Prioridade</label>
                            <select name="prioridade" id="tarefaPrioridade" class="form-select">
                                <option value="baixa">Baixa</option>
                                <option value="media" selected>Média</option>
                                <option value="alta">Alta</option>
                                <option value="urgente">Urgente</option>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Status</label>
                            <select name="status" id="tarefaStatus" class="form-select">
                                <option value="pendente">Pendente</option>
                                <option value="em_andamento">Em Andamento</option>
                                <option value="concluida">Concluída</option>
                                <option value="cancelada">Cancelada</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observações</label>
                            <textarea name="observacoes" id="tarefaObs" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Salvar Tarefa</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $extraJS = '<script>
function abrirModalTarefa() {
    document.getElementById("tarefaModalTitulo").innerHTML = \'<i class="bi bi-plus-circle me-2"></i>Nova Tarefa\';
    document.getElementById("tarefaId").value = "0";
    document.getElementById("formTarefa").reset();
    new bootstrap.Modal(document.getElementById("modalTarefa")).show();
}

function editarTarefa(t) {
    document.getElementById("tarefaModalTitulo").innerHTML = \'<i class="bi bi-pencil me-2"></i>Editar Tarefa\';
    document.getElementById("tarefaId").value = t.id;
    document.getElementById("tarefaTitulo").value = t.titulo;
    document.getElementById("tarefaDesc").value = t.descricao || "";
    document.getElementById("tarefaAtribuido").value = t.atribuido_para;
    document.getElementById("tarefaPrazo").value = t.prazo || "";
    document.getElementById("tarefaPrioridade").value = t.prioridade;
    document.getElementById("tarefaStatus").value = t.status;
    document.getElementById("tarefaObs").value = t.observacoes || "";
    new bootstrap.Modal(document.getElementById("modalTarefa")).show();
}

function excluirTarefa(id) {
    if (!confirm("Excluir esta tarefa?")) return;
    const form = document.createElement("form");
    form.method = "POST";
    form.innerHTML = `<input name="acao" value="excluir"><input name="id" value="${id}">`;
    document.body.appendChild(form);
    form.submit();
}

function atualizarStatus(sel) {
    fetch("tarefas.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: `acao=status&id=${sel.dataset.id}&status=${sel.value}`
    })
    .then(r => r.json())
    .then(d => { if (d.sucesso) showToast("Status atualizado!", "success"); });
}
</script>'; ?>

<?php include 'includes/footer.php'; ?>
