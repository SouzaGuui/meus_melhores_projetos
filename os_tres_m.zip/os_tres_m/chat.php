<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requirePermission('chat.use');

$pageTitle = 'Chat';
$breadcrumb = 'Chat';
$user = currentUser();
$pdo = db();

// Conversa ativa
$conversaId = (int)($_GET['conversa'] ?? 0);
$destinatarioId = (int)($_GET['para'] ?? 0);

// Iniciar nova conversa (IDs ordenados evita conversas duplicadas)
if ($destinatarioId > 0 && $destinatarioId !== (int)$user['id']) {
    $u1 = min((int)$user['id'], $destinatarioId);
    $u2 = max((int)$user['id'], $destinatarioId);
    $stmt = $pdo->prepare('SELECT id FROM conversas WHERE usuario1_id = ? AND usuario2_id = ? LIMIT 1');
    $stmt->execute([$u1, $u2]);
    $conv = $stmt->fetch();
    if ($conv) {
        $conversaId = (int)$conv['id'];
    } else {
        $pdo->prepare('INSERT INTO conversas (usuario1_id, usuario2_id) VALUES (?, ?)')->execute([$u1, $u2]);
        $conversaId = (int)$pdo->lastInsertId();
    }
    header('Location: chat.php?conversa=' . $conversaId);
    exit;
}

// Buscar conversas do usuário
$conversas = $pdo->prepare("
    SELECT c.*,
           CASE WHEN c.usuario1_id = ? THEN u2.id ELSE u1.id END as outro_id,
           CASE WHEN c.usuario1_id = ? THEN u2.nome ELSE u1.nome END as outro_nome,
           CASE WHEN c.usuario1_id = ? THEN u2.foto_perfil ELSE u1.foto_perfil END as outro_foto,
           CASE WHEN c.usuario1_id = ? THEN u2.online ELSE u1.online END as outro_online,
           CASE WHEN c.usuario1_id = ? THEN u2.cargo ELSE u1.cargo END as outro_cargo,
           (SELECT COUNT(*) FROM mensagens m WHERE m.conversa_id = c.id AND m.lida = 0 AND m.remetente_id != ?) as nao_lidas
    FROM conversas c
    JOIN usuarios u1 ON c.usuario1_id = u1.id
    JOIN usuarios u2 ON c.usuario2_id = u2.id
    WHERE c.usuario1_id = ? OR c.usuario2_id = ?
    ORDER BY c.ultima_mensagem_em DESC
");
$conversas->execute(array_fill(0, 8, $user['id']));
$listaConversas = $conversas->fetchAll();
if (getNivelAcesso() !== 'admin' && !can('*')) {
    $listaConversas = array_values(array_filter($listaConversas, function ($c) use ($user) {
        $outroId = (int)($c['outro_id'] ?? 0);
        if ($outroId <= 0) {
            return true;
        }
        $st = db()->prepare("SELECT nivel_acesso FROM usuarios WHERE id = ?");
        $st->execute([$outroId]);
        return $st->fetchColumn() !== 'admin';
    }));
}

// Mensagens da conversa ativa
$mensagens = [];
$outroUsuario = null;
if ($conversaId > 0) {
    // Verificar acesso
    $stmt = $pdo->prepare("SELECT * FROM conversas WHERE id=? AND (usuario1_id=? OR usuario2_id=?)");
    $stmt->execute([$conversaId,$user['id'],$user['id']]);
    $convAtiva = $stmt->fetch();
    if ($convAtiva) {
        $outroId = $convAtiva['usuario1_id'] == $user['id'] ? $convAtiva['usuario2_id'] : $convAtiva['usuario1_id'];
        $outroUsuario = getUsuario($outroId);

        // Marcar como lidas
        $pdo->prepare("UPDATE mensagens SET lida=1 WHERE conversa_id=? AND remetente_id!=?")->execute([$conversaId,$user['id']]);

        $stmt = $pdo->prepare("
            SELECT m.*, u.nome as remetente_nome, u.foto_perfil as remetente_foto
            FROM mensagens m
            JOIN usuarios u ON m.remetente_id = u.id
            WHERE m.conversa_id = ?
            ORDER BY m.criado_em ASC
        ");
        $stmt->execute([$conversaId]);
        $mensagens = $stmt->fetchAll();
    }
}

// Lista de usuários para nova conversa
$todosUsuarios = $pdo->prepare("SELECT id,nome,cargo,setor,foto_perfil,online FROM usuarios WHERE id != ? AND status='ativo'" . sqlOcultarAdmin() . " ORDER BY nome");
$todosUsuarios->execute([$user['id']]);
$usuarios = $todosUsuarios->fetchAll();

$extraCSS = '<link href="' . BASE_URL . 'assets/css/chat.css" rel="stylesheet">';
include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content chat-page">

            <div class="chat-wrapper <?= $conversaId ? 'has-active' : '' ?>">

                <!-- Lista de Conversas -->
                <div class="chat-sidebar-panel <?= $conversaId ? 'hide-mobile' : '' ?>">
                    <div style="padding:16px;border-bottom:1px solid var(--border-color)">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 style="font-weight:700;color:var(--text-primary);margin:0">Mensagens</h6>
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalNovaConversa">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                        </div>
                        <div style="position:relative">
                            <i class="bi bi-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:14px"></i>
                            <input type="text" id="buscaConversa" class="form-control" style="padding-left:32px;font-size:13px" placeholder="Pesquisar...">
                        </div>
                    </div>
                    <div style="flex:1;overflow-y:auto" id="listaConversas">
                        <?php if (empty($listaConversas)): ?>
                        <div style="text-align:center;padding:32px;color:var(--text-muted)">
                            <i class="bi bi-chat-dots" style="font-size:32px;display:block;margin-bottom:8px"></i>
                            <p style="font-size:13px">Nenhuma conversa ainda</p>
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalNovaConversa">
                                Iniciar conversa
                            </button>
                        </div>
                        <?php else: ?>
                        <?php foreach ($listaConversas as $c): ?>
                        <a href="chat.php?conversa=<?= $c['id'] ?>" class="chat-item <?= $c['id']==$conversaId?'active':'' ?>" style="display:flex;align-items:center;gap:12px;padding:14px 16px;text-decoration:none;border-bottom:1px solid var(--border-color);transition:var(--transition);<?= $c['id']==$conversaId?'background:rgba(37,99,235,0.1)':'' ?>">
                            <div style="position:relative;flex-shrink:0">
                                <div class="user-avatar" style="width:42px;height:42px;font-size:14px">
                                    <?php if ($c['outro_foto']): ?>
                                        <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($c['outro_foto']) ?>" alt="">
                                    <?php else: ?>
                                        <?= strtoupper(substr($c['outro_nome'],0,2)) ?>
                                    <?php endif; ?>
                                </div>
                                <span style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:<?= $c['outro_online']?'var(--verde)':'var(--text-muted)' ?>;border:2px solid var(--bg-card)"></span>
                            </div>
                            <div style="flex:1;min-width:0">
                                <div style="display:flex;justify-content:space-between;align-items:center">
                                    <span style="font-size:13.5px;font-weight:600;color:var(--text-primary)"><?= htmlspecialchars(explode(' ',$c['outro_nome'])[0]) ?></span>
                                    <span style="font-size:11px;color:var(--text-muted)"><?= $c['ultima_mensagem_em'] ? date('H:i',strtotime($c['ultima_mensagem_em'])) : '' ?></span>
                                </div>
                                <div style="display:flex;justify-content:space-between;align-items:center">
                                    <span style="font-size:12px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:160px"><?= htmlspecialchars(substr($c['ultima_mensagem'] ?? 'Iniciar conversa',0,40)) ?></span>
                                    <?php if ($c['nao_lidas'] > 0): ?>
                                    <span style="background:var(--azul-principal);color:white;font-size:10px;font-weight:700;min-width:18px;height:18px;border-radius:9px;display:flex;align-items:center;justify-content:center;padding:0 4px"><?= $c['nao_lidas'] ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Área de Chat -->
                <div class="chat-main-panel <?= !$conversaId ? 'hide-mobile' : '' ?>">
                    <?php if ($conversaId > 0 && $outroUsuario): ?>
                    <!-- Header do chat -->
                    <div class="chat-header-bar">
                        <a href="chat.php" class="btn btn-outline btn-sm d-md-none me-1"><i class="bi bi-arrow-left"></i></a>
                        <div style="position:relative">
                            <div class="user-avatar" style="width:40px;height:40px;font-size:14px">
                                <?php if ($outroUsuario['foto_perfil']): ?>
                                    <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($outroUsuario['foto_perfil']) ?>" alt="">
                                <?php else: ?>
                                    <?= strtoupper(substr($outroUsuario['nome'],0,2)) ?>
                                <?php endif; ?>
                            </div>
                            <span style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:<?= $outroUsuario['online']?'var(--verde)':'var(--text-muted)' ?>;border:2px solid var(--bg-card)"></span>
                        </div>
                        <div>
                            <div style="font-weight:700;color:var(--text-primary)"><?= htmlspecialchars($outroUsuario['nome']) ?></div>
                            <div style="font-size:12px;color:<?= $outroUsuario['online']?'var(--verde)':'var(--text-muted)' ?>">
                                <?= $outroUsuario['online'] ? '● Online' : '○ Offline' ?>
                                <?php if ($outroUsuario['cargo']): ?> — <?= htmlspecialchars($outroUsuario['cargo']) ?><?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Mensagens -->
                    <div id="chatMensagens" style="flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:12px">
                        <?php foreach ($mensagens as $m): ?>
                        <?php $isMeu = $m['remetente_id'] == $user['id']; ?>
                        <div class="chat-msg-row <?= $isMeu ? 'mine' : 'theirs' ?>" data-id="<?= (int)$m['id'] ?>">
                            <?php if (!$isMeu): ?>
                            <div class="chat-msg-avatar"><?= strtoupper(substr($m['remetente_nome'],0,2)) ?></div>
                            <?php endif; ?>
                            <div class="chat-msg-bubble-wrap">
                                <div class="chat-msg-bubble"><?= nl2br(htmlspecialchars($m['mensagem'])) ?></div>
                                <div class="chat-msg-meta">
                                    <span><?= date('H:i',strtotime($m['criado_em'])) ?></span>
                                    <?php if ($isMeu): ?>
                                    <i class="bi bi-check<?= $m['lida']?'-all':'' ?> msg-status <?= $m['lida']?'lida':'' ?>"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($mensagens)): ?>
                        <div class="chat-empty-state">
                            <i class="bi bi-chat-heart" style="font-size:40px;display:block;margin-bottom:12px;opacity:0.4"></i>
                            <p style="font-size:14px">Inicie a conversa com <?= htmlspecialchars(explode(' ',$outroUsuario['nome'])[0]) ?></p>
                        </div>
                        <?php endif; ?>
                    </div>

                    <div class="chat-compose">
                        <form id="formMensagem" style="display:flex;gap:10px;align-items:flex-end;width:100%">
                            <textarea id="inputMensagem" rows="1" placeholder="Digite sua mensagem... (Enter envia, Shift+Enter quebra linha)" autocomplete="off"></textarea>
                            <button type="submit" id="btnEnviarMsg" class="btn btn-primary btn-send-chat" title="Enviar" data-no-loading="1">
                                <i class="bi bi-send-fill"></i>
                            </button>
                        </form>
                    </div>

                    <?php else: ?>
                    <!-- Sem conversa selecionada -->
                    <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--text-muted)">
                        <i class="bi bi-chat-dots" style="font-size:64px;margin-bottom:16px;opacity:0.3"></i>
                        <h5 style="color:var(--text-secondary);font-weight:600">Selecione uma conversa</h5>
                        <p style="font-size:14px">Ou inicie uma nova conversa</p>
                        <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#modalNovaConversa">
                            <i class="bi bi-pencil-square"></i> Nova Conversa
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal Nova Conversa -->
<div class="modal fade" id="modalNovaConversa" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Nova Conversa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div style="position:relative;margin-bottom:12px">
                    <i class="bi bi-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted)"></i>
                    <input type="text" id="buscaUsuario" class="form-control" style="padding-left:36px" placeholder="Pesquisar usuário...">
                </div>
                <div id="listaUsuarios" style="max-height:300px;overflow-y:auto">
                    <?php foreach ($usuarios as $u): ?>
                    <a href="chat.php?para=<?= $u['id'] ?>" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="border-radius:10px;transition:var(--transition)" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background='transparent'">
                        <div style="position:relative">
                            <div class="user-avatar" style="width:40px;height:40px;font-size:14px">
                                <?php if ($u['foto_perfil']): ?>
                                    <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($u['foto_perfil']) ?>" alt="">
                                <?php else: ?>
                                    <?= strtoupper(substr($u['nome'],0,2)) ?>
                                <?php endif; ?>
                            </div>
                            <span style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:<?= $u['online']?'var(--verde)':'var(--text-muted)' ?>;border:2px solid var(--bg-card)"></span>
                        </div>
                        <div>
                            <div style="font-weight:600;color:var(--text-primary);font-size:14px"><?= htmlspecialchars($u['nome']) ?></div>
                            <div style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($u['cargo'] ?: $u['setor'] ?: 'Funcionário') ?></div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
$ultimaMsgId = !empty($mensagens) ? (int)end($mensagens)['id'] : 0;
$extraJS = '<script>window.CHAT_CONFIG=' . json_encode([
    'baseUrl' => BASE_URL,
    'conversaId' => $conversaId,
    'userId' => (int)$user['id'],
    'ultimaMensagemId' => $ultimaMsgId,
], JSON_UNESCAPED_UNICODE) . ';</script>
<script src="' . BASE_URL . 'assets/js/chat.js"></script>';
?>

<?php include 'includes/footer.php'; ?>
