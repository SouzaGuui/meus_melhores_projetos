<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Chat';
$breadcrumb = 'Chat';
$user = currentUser();
$pdo = db();

// Conversa ativa
$conversaId = (int)($_GET['conversa'] ?? 0);
$destinatarioId = (int)($_GET['para'] ?? 0);

// Iniciar nova conversa
if ($destinatarioId > 0 && $destinatarioId !== (int)$user['id']) {
    $stmt = $pdo->prepare("SELECT id FROM conversas WHERE (usuario1_id=? AND usuario2_id=?) OR (usuario1_id=? AND usuario2_id=?) LIMIT 1");
    $stmt->execute([$user['id'],$destinatarioId,$destinatarioId,$user['id']]);
    $conv = $stmt->fetch();
    if ($conv) {
        $conversaId = $conv['id'];
    } else {
        $pdo->prepare("INSERT INTO conversas (usuario1_id,usuario2_id) VALUES (?,?)")->execute([$user['id'],$destinatarioId]);
        $conversaId = $pdo->lastInsertId();
    }
    header("Location: chat.php?conversa=$conversaId");
    exit;
}

// Buscar conversas do usuário
$conversas = $pdo->prepare("
    SELECT c.*,
           CASE WHEN c.usuario1_id = ? THEN u2.id ELSE u1.id END as outro_id,
           CASE WHEN c.usuario1_id = ? THEN u2.nome ELSE u1.nome END as outro_nome,
           CASE WHEN c.usuario1_id = ? THEN u2.foto_perfil ELSE u1.foto_perfil END as outro_foto,
           CASE WHEN c.usuario1_id = ? THEN u2.online ELSE u1.online END as outro_online,
           CASE WHEN c.usuario1_id = ? THEN u2.cargo ELSE u1.cargo END as outro_cargo,
           (SELECT COUNT(*) FROM mensagens m WHERE m.conversa_id = c.id AND m.lida = 0 AND m.remetente_id != ?) as nao_lidas
    FROM conversas c
    JOIN usuarios u1 ON c.usuario1_id = u1.id
    JOIN usuarios u2 ON c.usuario2_id = u2.id
    WHERE c.usuario1_id = ? OR c.usuario2_id = ?
    ORDER BY c.ultima_mensagem_em DESC
");
$conversas->execute(array_fill(0, 8, $user['id']));
$listaConversas = $conversas->fetchAll();

// Mensagens da conversa ativa
$mensagens = [];
$outroUsuario = null;
if ($conversaId > 0) {
    // Verificar acesso
    $stmt = $pdo->prepare("SELECT * FROM conversas WHERE id=? AND (usuario1_id=? OR usuario2_id=?)");
    $stmt->execute([$conversaId,$user['id'],$user['id']]);
    $convAtiva = $stmt->fetch();
    if ($convAtiva) {
        $outroId = $convAtiva['usuario1_id'] == $user['id'] ? $convAtiva['usuario2_id'] : $convAtiva['usuario1_id'];
        $outroUsuario = getUsuario($outroId);

        // Marcar como lidas
        $pdo->prepare("UPDATE mensagens SET lida=1 WHERE conversa_id=? AND remetente_id!=?")->execute([$conversaId,$user['id']]);

        $stmt = $pdo->prepare("
            SELECT m.*, u.nome as remetente_nome, u.foto_perfil as remetente_foto
            FROM mensagens m
            JOIN usuarios u ON m.remetente_id = u.id
            WHERE m.conversa_id = ?
            ORDER BY m.criado_em ASC
        ");
        $stmt->execute([$conversaId]);
        $mensagens = $stmt->fetchAll();
    }
}

// Lista de usuários para nova conversa
$todosUsuarios = $pdo->prepare("SELECT id,nome,cargo,setor,foto_perfil,online FROM usuarios WHERE id != ? AND status='ativo' ORDER BY nome");
$todosUsuarios->execute([$user['id']]);
$usuarios = $todosUsuarios->fetchAll();

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content" style="padding:0;height:calc(100vh - var(--topbar-height));display:flex;flex-direction:column">

            <div class="chat-wrapper" style="display:flex;flex:1;overflow:hidden;margin:16px;gap:16px">

                <!-- Lista de Conversas -->
                <div class="chat-sidebar" style="width:300px;flex-shrink:0;background:var(--bg-card);border:1px solid var(--border-color);border-radius:var(--radius);display:flex;flex-direction:column;overflow:hidden">
                    <div style="padding:16px;border-bottom:1px solid var(--border-color)">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h6 style="font-weight:700;color:var(--text-primary);margin:0">Mensagens</h6>
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalNovaConversa">
                                <i class="bi bi-pencil-square"></i>
                            </button>
                        </div>
                        <div style="position:relative">
                            <i class="bi bi-search" style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:var(--text-muted);font-size:14px"></i>
                            <input type="text" id="buscaConversa" class="form-control" style="padding-left:32px;font-size:13px" placeholder="Pesquisar...">
                        </div>
                    </div>
                    <div style="flex:1;overflow-y:auto" id="listaConversas">
                        <?php if (empty($listaConversas)): ?>
                        <div style="text-align:center;padding:32px;color:var(--text-muted)">
                            <i class="bi bi-chat-dots" style="font-size:32px;display:block;margin-bottom:8px"></i>
                            <p style="font-size:13px">Nenhuma conversa ainda</p>
                            <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalNovaConversa">
                                Iniciar conversa
                            </button>
                        </div>
                        <?php else: ?>
                        <?php foreach ($listaConversas as $c): ?>
                        <a href="chat.php?conversa=<?= $c['id'] ?>" class="chat-item <?= $c['id']==$conversaId?'active':'' ?>" style="display:flex;align-items:center;gap:12px;padding:14px 16px;text-decoration:none;border-bottom:1px solid var(--border-color);transition:var(--transition);<?= $c['id']==$conversaId?'background:rgba(37,99,235,0.1)':'' ?>">
                            <div style="position:relative;flex-shrink:0">
                                <div class="user-avatar" style="width:42px;height:42px;font-size:14px">
                                    <?php if ($c['outro_foto']): ?>
                                        <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($c['outro_foto']) ?>" alt="">
                                    <?php else: ?>
                                        <?= strtoupper(substr($c['outro_nome'],0,2)) ?>
                                    <?php endif; ?>
                                </div>
                                <span style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:<?= $c['outro_online']?'var(--verde)':'var(--text-muted)' ?>;border:2px solid var(--bg-card)"></span>
                            </div>
                            <div style="flex:1;min-width:0">
                                <div style="display:flex;justify-content:space-between;align-items:center">
                                    <span style="font-size:13.5px;font-weight:600;color:var(--text-primary)"><?= htmlspecialchars(explode(' ',$c['outro_nome'])[0]) ?></span>
                                    <span style="font-size:11px;color:var(--text-muted)"><?= $c['ultima_mensagem_em'] ? date('H:i',strtotime($c['ultima_mensagem_em'])) : '' ?></span>
                                </div>
                                <div style="display:flex;justify-content:space-between;align-items:center">
                                    <span style="font-size:12px;color:var(--text-muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:160px"><?= htmlspecialchars(substr($c['ultima_mensagem'] ?? 'Iniciar conversa',0,40)) ?></span>
                                    <?php if ($c['nao_lidas'] > 0): ?>
                                    <span style="background:var(--azul-principal);color:white;font-size:10px;font-weight:700;min-width:18px;height:18px;border-radius:9px;display:flex;align-items:center;justify-content:center;padding:0 4px"><?= $c['nao_lidas'] ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Área de Chat -->
                <div style="flex:1;background:var(--bg-card);border:1px solid var(--border-color);border-radius:var(--radius);display:flex;flex-direction:column;overflow:hidden">
                    <?php if ($conversaId > 0 && $outroUsuario): ?>
                    <!-- Header do chat -->
                    <div style="padding:14px 20px;border-bottom:1px solid var(--border-color);display:flex;align-items:center;gap:12px">
                        <div style="position:relative">
                            <div class="user-avatar" style="width:40px;height:40px;font-size:14px">
                                <?php if ($outroUsuario['foto_perfil']): ?>
                                    <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($outroUsuario['foto_perfil']) ?>" alt="">
                                <?php else: ?>
                                    <?= strtoupper(substr($outroUsuario['nome'],0,2)) ?>
                                <?php endif; ?>
                            </div>
                            <span style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:<?= $outroUsuario['online']?'var(--verde)':'var(--text-muted)' ?>;border:2px solid var(--bg-card)"></span>
                        </div>
                        <div>
                            <div style="font-weight:700;color:var(--text-primary)"><?= htmlspecialchars($outroUsuario['nome']) ?></div>
                            <div style="font-size:12px;color:<?= $outroUsuario['online']?'var(--verde)':'var(--text-muted)' ?>">
                                <?= $outroUsuario['online'] ? '● Online' : '○ Offline' ?>
                                <?php if ($outroUsuario['cargo']): ?> — <?= htmlspecialchars($outroUsuario['cargo']) ?><?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Mensagens -->
                    <div id="chatMensagens" style="flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:12px">
                        <?php foreach ($mensagens as $m): ?>
                        <?php $isMeu = $m['remetente_id'] == $user['id']; ?>
                        <div style="display:flex;justify-content:<?= $isMeu?'flex-end':'flex-start' ?>;gap:8px;align-items:flex-end">
                            <?php if (!$isMeu): ?>
                            <div class="user-avatar" style="width:28px;height:28px;font-size:10px;flex-shrink:0">
                                <?= strtoupper(substr($m['remetente_nome'],0,2)) ?>
                            </div>
                            <?php endif; ?>
                            <div style="max-width:65%">
                                <div style="background:<?= $isMeu?'linear-gradient(135deg,#2563EB,#7C3AED)':'var(--bg-secondary)' ?>;color:<?= $isMeu?'white':'var(--text-primary)' ?>;padding:10px 14px;border-radius:<?= $isMeu?'16px 16px 4px 16px':'16px 16px 16px 4px' ?>;font-size:13.5px;line-height:1.5;border:<?= $isMeu?'none':'1px solid var(--border-color)' ?>">
                                    <?= nl2br(htmlspecialchars($m['mensagem'])) ?>
                                </div>
                                <div style="font-size:11px;color:var(--text-muted);margin-top:4px;text-align:<?= $isMeu?'right':'left' ?>">
                                    <?= date('H:i',strtotime($m['criado_em'])) ?>
                                    <?php if ($isMeu): ?>
                                    <i class="bi bi-check<?= $m['lida']?'-all':'' ?>" style="color:<?= $m['lida']?'var(--azul-claro)':'var(--text-muted)' ?>"></i>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($mensagens)): ?>
                        <div style="text-align:center;color:var(--text-muted);margin:auto">
                            <i class="bi bi-chat-heart" style="font-size:40px;display:block;margin-bottom:12px;opacity:0.4"></i>
                            <p style="font-size:14px">Inicie a conversa com <?= htmlspecialchars(explode(' ',$outroUsuario['nome'])[0]) ?></p>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Input de mensagem -->
                    <div style="padding:16px;border-top:1px solid var(--border-color)">
                        <form id="formMensagem" style="display:flex;gap:10px;align-items:flex-end">
                            <textarea id="inputMensagem" class="form-control" rows="1" placeholder="Digite uma mensagem..." style="resize:none;max-height:120px;overflow-y:auto" onkeydown="handleEnter(event)"></textarea>
                            <button type="submit" class="btn btn-primary" style="flex-shrink:0;height:42px;width:42px;padding:0;justify-content:center">
                                <i class="bi bi-send-fill"></i>
                            </button>
                        </form>
                    </div>

                    <?php else: ?>
                    <!-- Sem conversa selecionada -->
                    <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;color:var(--text-muted)">
                        <i class="bi bi-chat-dots" style="font-size:64px;margin-bottom:16px;opacity:0.3"></i>
                        <h5 style="color:var(--text-secondary);font-weight:600">Selecione uma conversa</h5>
                        <p style="font-size:14px">Ou inicie uma nova conversa</p>
                        <button class="btn btn-primary mt-2" data-bs-toggle="modal" data-bs-target="#modalNovaConversa">
                            <i class="bi bi-pencil-square"></i> Nova Conversa
                        </button>
                    </div>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>

<!-- Modal Nova Conversa -->
<div class="modal fade" id="modalNovaConversa" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil-square me-2"></i>Nova Conversa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div style="position:relative;margin-bottom:12px">
                    <i class="bi bi-search" style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:var(--text-muted)"></i>
                    <input type="text" id="buscaUsuario" class="form-control" style="padding-left:36px" placeholder="Pesquisar usuário...">
                </div>
                <div id="listaUsuarios" style="max-height:300px;overflow-y:auto">
                    <?php foreach ($usuarios as $u): ?>
                    <a href="chat.php?para=<?= $u['id'] ?>" class="d-flex align-items-center gap-3 p-3 text-decoration-none" style="border-radius:10px;transition:var(--transition)" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background='transparent'">
                        <div style="position:relative">
                            <div class="user-avatar" style="width:40px;height:40px;font-size:14px">
                                <?php if ($u['foto_perfil']): ?>
                                    <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($u['foto_perfil']) ?>" alt="">
                                <?php else: ?>
                                    <?= strtoupper(substr($u['nome'],0,2)) ?>
                                <?php endif; ?>
                            </div>
                            <span style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;border-radius:50%;background:<?= $u['online']?'var(--verde)':'var(--text-muted)' ?>;border:2px solid var(--bg-card)"></span>
                        </div>
                        <div>
                            <div style="font-weight:600;color:var(--text-primary);font-size:14px"><?= htmlspecialchars($u['nome']) ?></div>
                            <div style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($u['cargo'] ?: $u['setor'] ?: 'Funcionário') ?></div>
                        </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $extraJS = '<script>
const conversaId = ' . $conversaId . ';
const userId = ' . $user['id'] . ';

// Scroll para o final
function scrollBottom() {
    const el = document.getElementById("chatMensagens");
    if (el) el.scrollTop = el.scrollHeight;
}
scrollBottom();

// Enviar mensagem
document.getElementById("formMensagem")?.addEventListener("submit", function(e) {
    e.preventDefault();
    const msg = document.getElementById("inputMensagem").value.trim();
    if (!msg || !conversaId) return;

    fetch("api/chat_enviar.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({conversa_id: conversaId, mensagem: msg})
    })
    .then(r => r.json())
    .then(d => {
        if (d.sucesso) {
            document.getElementById("inputMensagem").value = "";
            adicionarMensagem(d.mensagem, true);
        }
    });
});

function handleEnter(e) {
    if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        document.getElementById("formMensagem")?.dispatchEvent(new Event("submit"));
    }
}

function adicionarMensagem(m, isMeu) {
    const container = document.getElementById("chatMensagens");
    if (!container) return;
    const div = document.createElement("div");
    div.style.cssText = `display:flex;justify-content:${isMeu?"flex-end":"flex-start"};gap:8px;align-items:flex-end`;
    div.innerHTML = `
        <div style="max-width:65%">
            <div style="background:${isMeu?"linear-gradient(135deg,#2563EB,#7C3AED)":"var(--bg-secondary)"};color:${isMeu?"white":"var(--text-primary)"};padding:10px 14px;border-radius:${isMeu?"16px 16px 4px 16px":"16px 16px 16px 4px"};font-size:13.5px;line-height:1.5;border:${isMeu?"none":"1px solid var(--border-color)"}">
                ${m.mensagem.replace(/\n/g,"<br>")}
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px;text-align:${isMeu?"right":"left"}">${m.hora}</div>
        </div>
    `;
    container.appendChild(div);
    scrollBottom();
}

// Polling para novas mensagens
let ultimaMensagemId = <?= !empty($mensagens) ? end($mensagens)["id"] : 0 ?>;
if (conversaId > 0) {
    setInterval(() => {
        fetch(`api/chat_novas.php?conversa_id=${conversaId}&ultima_id=${ultimaMensagemId}`)
        .then(r => r.json())
        .then(d => {
            if (d.mensagens && d.mensagens.length > 0) {
                d.mensagens.forEach(m => {
                    adicionarMensagem(m, m.remetente_id == userId);
                    ultimaMensagemId = m.id;
                });
            }
        });
    }, 3000);
}

// Busca de conversa
document.getElementById("buscaConversa")?.addEventListener("input", function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll(".chat-item").forEach(el => {
        el.style.display = el.textContent.toLowerCase().includes(q) ? "" : "none";
    });
});

// Busca de usuário no modal
document.getElementById("buscaUsuario")?.addEventListener("input", function() {
    const q = this.value.toLowerCase();
    document.querySelectorAll("#listaUsuarios a").forEach(el => {
        el.style.display = el.textContent.toLowerCase().includes(q) ? "" : "none";
    });
});
</script>'; ?>

<?php include 'includes/footer.php'; ?>
