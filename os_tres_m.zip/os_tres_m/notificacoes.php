<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Notificações';
$breadcrumb = 'Notificações';
$user = currentUser();
$pdo = db();

// Marcar todas como lidas ao abrir
$pdo->prepare("UPDATE notificacoes SET lida=1 WHERE usuario_id=?")->execute([$user['id']]);

$notifs = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id=? ORDER BY criado_em DESC LIMIT 100");
$notifs->execute([$user['id']]);
$todas = $notifs->fetchAll();

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <div class="d-flex align-items-center justify-content-between mb-4">
                <div>
                    <h2 style="font-size:20px;font-weight:800;color:var(--text-primary);margin:0">Notificações</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0"><?= count($todas) ?> notificação(ões)</p>
                </div>
            </div>

            <div class="card">
                <div class="card-body" style="padding:0">
                    <?php if (empty($todas)): ?>
                    <div style="text-align:center;padding:60px;color:var(--text-muted)">
                        <i class="bi bi-bell-slash" style="font-size:48px;display:block;margin-bottom:16px;opacity:0.3"></i>
                        <h5 style="color:var(--text-secondary)">Nenhuma notificação</h5>
                        <p style="font-size:14px">Você está em dia!</p>
                    </div>
                    <?php else: ?>
                    <?php
                    $icons = ['tarefa'=>'check2-square','aviso'=>'megaphone','ponto'=>'clock','pagamento'=>'cash','chat'=>'chat-dots','sistema'=>'gear'];
                    $colors = ['tarefa'=>'var(--azul-claro)','aviso'=>'var(--amarelo)','ponto'=>'var(--verde)','pagamento'=>'var(--roxo-claro)','chat'=>'var(--azul-claro)','sistema'=>'var(--text-muted)'];
                    foreach ($todas as $n):
                    ?>
                    <a href="<?= $n['link'] ?? '#' ?>" class="d-flex align-items-start gap-3 p-4 text-decoration-none" style="border-bottom:1px solid var(--border-color);transition:var(--transition)" onmouseover="this.style.background='var(--bg-hover)'" onmouseout="this.style.background='transparent'">
                        <div style="width:44px;height:44px;border-radius:10px;background:<?= str_replace(')',',0.15)',$colors[$n['tipo']]??'rgba(148,163,184') ?>;display:flex;align-items:center;justify-content:center;font-size:18px;color:<?= $colors[$n['tipo']] ?? 'var(--text-muted)' ?>;flex-shrink:0">
                            <i class="bi bi-<?= $icons[$n['tipo']] ?? 'bell' ?>"></i>
                        </div>
                        <div style="flex:1">
                            <div style="font-weight:600;color:var(--text-primary);font-size:14px;margin-bottom:4px"><?= htmlspecialchars($n['titulo']) ?></div>
                            <div style="font-size:13px;color:var(--text-secondary);margin-bottom:6px"><?= htmlspecialchars($n['mensagem']) ?></div>
                            <div style="font-size:11px;color:var(--text-muted)"><?= formatarDataHora($n['criado_em']) ?></div>
                        </div>
                        <span class="badge-status" style="background:rgba(37,99,235,0.1);color:var(--azul-claro);font-size:10px"><?= ucfirst($n['tipo']) ?></span>
                    </a>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
