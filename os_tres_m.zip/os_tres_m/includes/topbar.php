<?php
$user = currentUser();
$notifs = getNotificacoes($user['id'], 8);
$notifCount = contarNotificacoes($user['id']);
?>
<!-- TOPBAR -->
<header class="topbar">
    <div class="topbar-left">
        <button class="sidebar-toggle" id="sidebarToggle">
            <i class="bi bi-list"></i>
        </button>
        <div class="topbar-title">
            <h1><?= $pageTitle ?? 'Dashboard' ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="<?= BASE_URL ?>dashboard.php">Início</a></li>
                    <?php if (isset($breadcrumb)): ?>
                        <li class="breadcrumb-item active"><?= $breadcrumb ?></li>
                    <?php endif; ?>
                </ol>
            </nav>
        </div>
    </div>
    <div class="topbar-right">
        <!-- Pesquisa -->
        <div class="topbar-search d-none d-md-flex">
            <i class="bi bi-search"></i>
            <input type="text" placeholder="Pesquisar..." id="globalSearch">
        </div>

        <!-- Modo escuro -->
        <button class="topbar-btn" id="themeToggle" title="Alternar tema">
            <i class="bi bi-moon-fill" id="themeIcon"></i>
        </button>

        <!-- Notificações -->
        <div class="dropdown">
            <button class="topbar-btn position-relative" data-bs-toggle="dropdown" id="notifBtn">
                <i class="bi bi-bell-fill"></i>
                <?php if ($notifCount > 0): ?>
                    <span class="notif-badge"><?= $notifCount > 9 ? '9+' : $notifCount ?></span>
                <?php endif; ?>
            </button>
            <div class="dropdown-menu dropdown-menu-end notif-dropdown">
                <div class="notif-header">
                    <span>Notificações</span>
                    <?php if ($notifCount > 0): ?>
                        <a href="#" class="mark-all-read" data-action="markAllRead">Marcar todas como lidas</a>
                    <?php endif; ?>
                </div>
                <div class="notif-list">
                    <?php if (empty($notifs)): ?>
                        <div class="notif-empty">
                            <i class="bi bi-bell-slash"></i>
                            <p>Nenhuma notificação</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($notifs as $n): ?>
                            <a href="<?= $n['link'] ?? '#' ?>" class="notif-item <?= !$n['lida'] ? 'unread' : '' ?>" data-id="<?= $n['id'] ?>">
                                <div class="notif-icon notif-<?= $n['tipo'] ?>">
                                    <?php
                                    $icons = ['tarefa'=>'check2-square','aviso'=>'megaphone','ponto'=>'clock','pagamento'=>'cash','chat'=>'chat-dots','sistema'=>'gear'];
                                    echo '<i class="bi bi-' . ($icons[$n['tipo']] ?? 'bell') . '"></i>';
                                    ?>
                                </div>
                                <div class="notif-content">
                                    <p class="notif-title"><?= htmlspecialchars($n['titulo']) ?></p>
                                    <p class="notif-msg"><?= htmlspecialchars(substr($n['mensagem'], 0, 60)) ?>...</p>
                                    <span class="notif-time"><?= formatarDataHora($n['criado_em']) ?></span>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                <div class="notif-footer">
                    <a href="<?= BASE_URL ?>notificacoes.php">Ver todas</a>
                </div>
            </div>
        </div>

        <!-- Perfil -->
        <div class="dropdown">
            <button class="topbar-user" data-bs-toggle="dropdown">
                <div class="user-avatar-sm">
                    <?php if ($user['foto_perfil']): ?>
                        <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($user['foto_perfil']) ?>" alt="">
                    <?php else: ?>
                        <span><?= strtoupper(substr($user['nome'], 0, 2)) ?></span>
                    <?php endif; ?>
                </div>
                <div class="d-none d-md-block">
                    <span class="user-name-top"><?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?></span>
                    <span class="user-role-top"><?= nivelLabel($user['nivel_acesso']) ?></span>
                </div>
                <i class="bi bi-chevron-down ms-1"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end user-dropdown">
                <li><a class="dropdown-item" href="<?= BASE_URL ?>perfil.php"><i class="bi bi-person"></i> Meu Perfil</a></li>
                <li><a class="dropdown-item" href="<?= BASE_URL ?>configuracoes.php"><i class="bi bi-gear"></i> Configurações</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item text-danger" href="<?= BASE_URL ?>api/logout.php"><i class="bi bi-box-arrow-left"></i> Sair</a></li>
            </ul>
        </div>
    </div>
</header>
