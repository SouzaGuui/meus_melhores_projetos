<?php
/**
 * Favicon e meta de identidade — incluir no <head> de todas as páginas
 */
$faviconBase = BASE_URL . 'assets/img/';
$faviconVer = @filemtime(__DIR__ . '/../assets/img/favicon.svg') ?: time();
?>
<link rel="icon" href="<?= $faviconBase ?>favicon.svg?v=<?= $faviconVer ?>" type="image/svg+xml">
<link rel="icon" href="<?= $faviconBase ?>logo.svg?v=<?= $faviconVer ?>" type="image/svg+xml" sizes="any">
<link rel="apple-touch-icon" href="<?= $faviconBase ?>logo.svg?v=<?= $faviconVer ?>">
<link rel="manifest" href="<?= BASE_URL ?>manifest.webmanifest">
<meta name="theme-color" content="#F97316" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0F1117" media="(prefers-color-scheme: dark)">
<meta name="application-name" content="Os Três M">
