<?php
$user = currentUser();
$nivel = $user['nivel_acesso'];
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
?>
<!-- Overlay mobile -->
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <!-- Logo -->
    <div class="sidebar-brand">
        <div class="brand-logo">
            <span class="brand-icon">M³</span>
        </div>
        <div class="brand-text">
            <span class="brand-name">Os Três M</span>
            <span class="brand-sub">Sistema Empresarial</span>
        </div>
        <button class="sidebar-close d-lg-none" id="sidebarClose">
            <i class="bi bi-x-lg"></i>
        </button>
    </div>

    <!-- User Info -->
    <div class="sidebar-user">
        <div class="user-avatar">
            <?php if ($user['foto_perfil']): ?>
                <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($user['foto_perfil']) ?>" alt="Foto">
            <?php else: ?>
                <span><?= strtoupper(substr($user['nome'], 0, 2)) ?></span>
            <?php endif; ?>
            <span class="user-status online"></span>
        </div>
        <div class="user-info">
            <span class="user-name"><?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?></span>
            <span class="user-role"><?= nivelLabel($nivel) ?></span>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="sidebar-nav">
        <div class="nav-section">
            <span class="nav-label">Principal</span>
            <a href="<?= BASE_URL ?>dashboard.php" class="nav-item <?= $currentPage === 'dashboard' ? 'active' : '' ?>">
                <i class="bi bi-grid-1x2-fill"></i>
                <span>Dashboard</span>
            </a>
            <a href="<?= BASE_URL ?>perfil.php" class="nav-item <?= $currentPage === 'perfil' ? 'active' : '' ?>">
                <i class="bi bi-person-circle"></i>
                <span>Meu Perfil</span>
            </a>
        </div>

        <div class="nav-section">
            <span class="nav-label">Operacional</span>
            <a href="<?= BASE_URL ?>ponto.php" class="nav-item <?= $currentPage === 'ponto' ? 'active' : '' ?>">
                <i class="bi bi-clock-fill"></i>
                <span>Folha de Ponto</span>
                <?php $pontoHoje = getPontoHoje($user['id']); ?>
                <?php if (!$pontoHoje || !$pontoHoje['entrada']): ?>
                    <span class="nav-badge badge-red">!</span>
                <?php endif; ?>
            </a>
            <a href="<?= BASE_URL ?>tarefas.php" class="nav-item <?= $currentPage === 'tarefas' ? 'active' : '' ?>">
                <i class="bi bi-check2-square"></i>
                <span>Tarefas</span>
                <?php
                $pdo = db();
                $stmtT = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para = ? AND status = 'pendente'");
                $stmtT->execute([$user['id']]);
                $pendentes = $stmtT->fetchColumn();
                if ($pendentes > 0): ?>
                    <span class="nav-badge badge-blue"><?= $pendentes ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= BASE_URL ?>chat.php" class="nav-item <?= $currentPage === 'chat' ? 'active' : '' ?>">
                <i class="bi bi-chat-dots-fill"></i>
                <span>Chat</span>
                <?php
                $stmtM = $pdo->prepare("SELECT COUNT(*) FROM mensagens m JOIN conversas c ON m.conversa_id = c.id WHERE m.lida = 0 AND m.remetente_id != ? AND (c.usuario1_id = ? OR c.usuario2_id = ?)");
                $stmtM->execute([$user['id'], $user['id'], $user['id']]);
                $msgs = $stmtM->fetchColumn();
                if ($msgs > 0): ?>
                    <span class="nav-badge badge-green"><?= $msgs ?></span>
                <?php endif; ?>
            </a>
        </div>

        <?php if (hasPermission(['rh', 'gerente', 'coordenacao', 'admin'])): ?>
        <div class="nav-section">
            <span class="nav-label">Gestão</span>
            <?php if (hasPermission(['rh', 'admin'])): ?>
            <a href="<?= BASE_URL ?>funcionarios.php" class="nav-item <?= $currentPage === 'funcionarios' ? 'active' : '' ?>">
                <i class="bi bi-people-fill"></i>
                <span>Funcionários</span>
            </a>
            <a href="<?= BASE_URL ?>pagamento.php" class="nav-item <?= $currentPage === 'pagamento' ? 'active' : '' ?>">
                <i class="bi bi-cash-stack"></i>
                <span>Folha Salarial</span>
            </a>
            <?php endif; ?>
            <?php if (hasPermission(['gerente', 'coordenacao', 'rh', 'admin'])): ?>
            <a href="<?= BASE_URL ?>relatorios.php" class="nav-item <?= $currentPage === 'relatorios' ? 'active' : '' ?>">
                <i class="bi bi-bar-chart-fill"></i>
                <span>Relatórios</span>
            </a>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if (hasPermission(['admin'])): ?>
        <div class="nav-section">
            <span class="nav-label">Administração</span>
            <a href="<?= BASE_URL ?>configuracoes.php" class="nav-item <?= $currentPage === 'configuracoes' ? 'active' : '' ?>">
                <i class="bi bi-gear-fill"></i>
                <span>Configurações</span>
            </a>
            <a href="<?= BASE_URL ?>logs.php" class="nav-item <?= $currentPage === 'logs' ? 'active' : '' ?>">
                <i class="bi bi-journal-text"></i>
                <span>Logs do Sistema</span>
            </a>
        </div>
        <?php endif; ?>
    </nav>

    <!-- Sidebar Footer -->
    <div class="sidebar-footer">
        <a href="<?= BASE_URL ?>api/logout.php" class="nav-item logout-btn">
            <i class="bi bi-box-arrow-left"></i>
            <span>Sair</span>
        </a>
    </div>
</aside>
