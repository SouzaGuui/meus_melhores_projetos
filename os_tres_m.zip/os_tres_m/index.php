<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . 'dashboard.php');
} else {
    header('Location: ' . BASE_URL . 'login.php');
}
exit;
