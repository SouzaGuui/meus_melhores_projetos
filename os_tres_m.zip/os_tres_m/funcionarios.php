<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requireLevel(['rh','admin','gerente','coordenacao']);

$pageTitle = 'Funcionários';
$breadcrumb = 'Funcionários';
$pdo = db();

// Filtros
$busca = sanitize($_GET['busca'] ?? '');
$filtroStatus = sanitize($_GET['status'] ?? 'todos');
$filtroSetor = sanitize($_GET['setor'] ?? '');
$pagina = max(1, (int)($_GET['pagina'] ?? 1));
$porPagina = 10;
$offset = ($pagina - 1) * $porPagina;

// Query
$where = "WHERE 1=1";
$params = [];
if ($busca) { $where .= " AND (nome LIKE ? OR email LIKE ? OR cpf LIKE ?)"; $params = array_merge($params, ["%$busca%","%$busca%","%$busca%"]); }
if ($filtroStatus !== 'todos') { $where .= " AND status = ?"; $params[] = $filtroStatus; }
if ($filtroSetor) { $where .= " AND setor = ?"; $params[] = $filtroSetor; }

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios $where");
$totalStmt->execute($params);
$total = $totalStmt->fetchColumn();
$totalPaginas = ceil($total / $porPagina);

$stmt = $pdo->prepare("SELECT * FROM usuarios $where ORDER BY nome LIMIT $porPagina OFFSET $offset");
$stmt->execute($params);
$funcionarios = $stmt->fetchAll();

$setores = $pdo->query("SELECT DISTINCT setor FROM usuarios WHERE setor != '' ORDER BY setor")->fetchAll(PDO::FETCH_COLUMN);

// Ação: salvar funcionário
$mensagem = '';
$tipoMsg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $acao = $_POST['acao'];

    if ($acao === 'salvar') {
        $id = (int)($_POST['id'] ?? 0);
        $nome = sanitize($_POST['nome'] ?? '');
        $email = sanitize($_POST['email'] ?? '');
        $cpf = preg_replace('/[^0-9]/', '', $_POST['cpf'] ?? '');
        $telefone = sanitize($_POST['telefone'] ?? '');
        $data_nasc = sanitize($_POST['data_nascimento'] ?? '');
        $cep = sanitize($_POST['cep'] ?? '');
        $cargo = sanitize($_POST['cargo'] ?? '');
        $setor = sanitize($_POST['setor'] ?? '');
        $salario = (float)str_replace(['.', ','], ['', '.'], $_POST['salario'] ?? '0');
        $data_cont = sanitize($_POST['data_contratacao'] ?? '');
        $nivel = sanitize($_POST['nivel_acesso'] ?? 'funcionario');
        $status = sanitize($_POST['status'] ?? 'ativo');
        $senha = $_POST['senha'] ?? '';

        if (!$nome || !$email || !$cpf) {
            $mensagem = 'Preencha os campos obrigatórios.';
            $tipoMsg = 'danger';
        } elseif (!validarEmail($email)) {
            $mensagem = 'E-mail inválido.';
            $tipoMsg = 'danger';
        } elseif (!validarCPF($cpf)) {
            $mensagem = 'CPF inválido.';
            $tipoMsg = 'danger';
        } else {
            // Upload foto
            $foto = null;
            if (!empty($_FILES['foto_perfil']['name'])) {
                $upload = uploadFoto($_FILES['foto_perfil'], 'perfil');
                if (isset($upload['erro'])) {
                    $mensagem = $upload['erro'];
                    $tipoMsg = 'danger';
                } else {
                    $foto = $upload['arquivo'];
                }
            }

            if (!$mensagem) {
                if ($id > 0) {
                    // Editar
                    $fotoSql = $foto ? ", foto_perfil = ?" : "";
                    $senhaSql = $senha ? ", senha = ?" : "";
                    $sql = "UPDATE usuarios SET nome=?, email=?, cpf=?, telefone=?, data_nascimento=?, cep=?, cargo=?, setor=?, salario=?, data_contratacao=?, nivel_acesso=?, status=? $fotoSql $senhaSql WHERE id=?";
                    $p = [$nome,$email,$cpf,$telefone,$data_nasc,$cep,$cargo,$setor,$salario,$data_cont,$nivel,$status];
                    if ($foto) $p[] = $foto;
                    if ($senha) $p[] = hashSenha($senha);
                    $p[] = $id;
                    $pdo->prepare($sql)->execute($p);
                    $mensagem = 'Funcionário atualizado com sucesso!';
                    $tipoMsg = 'success';
                    registrarLog('editar_funcionario', "Funcionário ID $id editado");
                } else {
                    // Novo
                    if (!$senha) { $mensagem = 'Informe a senha.'; $tipoMsg = 'danger'; }
                    else {
                        // Verificar duplicatas
                        $dup = $pdo->prepare("SELECT id FROM usuarios WHERE email=? OR cpf=?");
                        $dup->execute([$email, $cpf]);
                        if ($dup->fetch()) {
                            $mensagem = 'E-mail ou CPF já cadastrado.';
                            $tipoMsg = 'danger';
                        } else {
                            $sql = "INSERT INTO usuarios (nome,email,senha,cpf,telefone,data_nascimento,cep,cargo,setor,salario,data_contratacao,nivel_acesso,status,foto_perfil) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                            $pdo->prepare($sql)->execute([$nome,$email,hashSenha($senha),$cpf,$telefone,$data_nasc,$cep,$cargo,$setor,$salario,$data_cont,$nivel,$status,$foto]);
                            $novoId = $pdo->lastInsertId();
                            criarNotificacao($novoId, 'Bem-vindo ao sistema!', "Olá $nome, seu cadastro foi criado com sucesso.", 'sistema');
                            $mensagem = 'Funcionário cadastrado com sucesso!';
                            $tipoMsg = 'success';
                            registrarLog('novo_funcionario', "Novo funcionário: $nome");
                        }
                    }
                }
            }
        }
    } elseif ($acao === 'excluir') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0 && $id !== (int)$user['id']) {
            $pdo->prepare("UPDATE usuarios SET status='inativo' WHERE id=?")->execute([$id]);
            $mensagem = 'Funcionário desativado.';
            $tipoMsg = 'success';
            registrarLog('desativar_funcionario', "Funcionário ID $id desativado");
        }
    }
    header("Location: funcionarios.php?msg=" . urlencode($mensagem) . "&tipo=$tipoMsg");
    exit;
}

if (isset($_GET['msg'])) {
    $mensagem = sanitize($_GET['msg']);
    $tipoMsg = sanitize($_GET['tipo'] ?? 'info');
}

$user = currentUser();
include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <?php if ($mensagem): ?>
            <div class="alert alert-<?= $tipoMsg ?> fade-in mb-3">
                <i class="bi bi-<?= $tipoMsg==='success'?'check-circle':'exclamation-circle' ?>-fill"></i>
                <?= htmlspecialchars($mensagem) ?>
            </div>
            <?php endif; ?>

            <!-- Header -->
            <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div>
                    <h2 style="font-size:20px;font-weight:800;color:var(--text-primary);margin:0">Gestão de Funcionários</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0"><?= $total ?> funcionário(s) encontrado(s)</p>
                </div>
                <?php if (hasPermission(['rh','admin'])): ?>
                <button class="btn btn-primary" onclick="abrirModal()">
                    <i class="bi bi-person-plus-fill"></i> Novo Funcionário
                </button>
                <?php endif; ?>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-12 col-md-4">
                            <label class="form-label">Pesquisar</label>
                            <div class="input-group">
                                <span class="input-group-text" style="background:var(--bg-secondary);border-color:var(--border-color);color:var(--text-muted)"><i class="bi bi-search"></i></span>
                                <input type="text" name="busca" class="form-control" placeholder="Nome, e-mail ou CPF..." value="<?= htmlspecialchars($busca) ?>">
                            </div>
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="todos" <?= $filtroStatus==='todos'?'selected':'' ?>>Todos</option>
                                <option value="ativo" <?= $filtroStatus==='ativo'?'selected':'' ?>>Ativo</option>
                                <option value="inativo" <?= $filtroStatus==='inativo'?'selected':'' ?>>Inativo</option>
                            </select>
                        </div>
                        <div class="col-6 col-md-3">
                            <label class="form-label">Setor</label>
                            <select name="setor" class="form-select">
                                <option value="">Todos os setores</option>
                                <?php foreach ($setores as $s): ?>
                                <option value="<?= htmlspecialchars($s) ?>" <?= $filtroSetor===$s?'selected':'' ?>><?= htmlspecialchars($s) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-3 d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-fill"><i class="bi bi-search"></i> Filtrar</button>
                            <a href="funcionarios.php" class="btn btn-outline"><i class="bi bi-x"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabela -->
            <div class="table-wrapper">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Funcionário</th>
                                <th>Cargo / Setor</th>
                                <th>Contato</th>
                                <th>Nível</th>
                                <th>Contratação</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($funcionarios)): ?>
                            <tr>
                                <td colspan="7" class="text-center" style="padding:40px;color:var(--text-muted)">
                                    <i class="bi bi-people" style="font-size:32px;display:block;margin-bottom:8px"></i>
                                    Nenhum funcionário encontrado
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($funcionarios as $f): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-3">
                                        <div class="user-avatar" style="width:38px;height:38px;font-size:13px;flex-shrink:0">
                                            <?php if ($f['foto_perfil']): ?>
                                                <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($f['foto_perfil']) ?>" alt="">
                                            <?php else: ?>
                                                <?= strtoupper(substr($f['nome'],0,2)) ?>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <div style="font-weight:600;color:var(--text-primary);font-size:13.5px"><?= htmlspecialchars($f['nome']) ?></div>
                                            <div style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($f['email']) ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div style="font-size:13px;color:var(--text-primary)"><?= htmlspecialchars($f['cargo'] ?: '-') ?></div>
                                    <div style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($f['setor'] ?: '-') ?></div>
                                </td>
                                <td>
                                    <div style="font-size:12px"><?= htmlspecialchars($f['telefone'] ?: '-') ?></div>
                                    <div style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($f['cpf']) ?></div>
                                </td>
                                <td><span class="badge-status status-ativo" style="background:rgba(37,99,235,0.15);color:var(--azul-claro)"><?= nivelLabel($f['nivel_acesso']) ?></span></td>
                                <td style="font-size:12px"><?= formatarData($f['data_contratacao']) ?></td>
                                <td><span class="badge-status status-<?= $f['status'] ?>"><?= ucfirst($f['status']) ?></span></td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <button class="btn btn-outline btn-icon btn-sm" onclick="editarFuncionario(<?= htmlspecialchars(json_encode($f)) ?>)" title="Editar">
                                            <i class="bi bi-pencil-fill" style="color:var(--azul-claro)"></i>
                                        </button>
                                        <a href="ponto.php?usuario_id=<?= $f['id'] ?>" class="btn btn-outline btn-icon btn-sm" title="Ver Ponto">
                                            <i class="bi bi-clock-fill" style="color:var(--verde)"></i>
                                        </a>
                                        <?php if (hasPermission(['admin','rh']) && $f['id'] != $user['id']): ?>
                                        <button class="btn btn-outline btn-icon btn-sm" onclick="confirmarExcluir(<?= $f['id'] ?>, '<?= htmlspecialchars($f['nome']) ?>')" title="Desativar">
                                            <i class="bi bi-person-x-fill" style="color:var(--vermelho)"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginação -->
                <?php if ($totalPaginas > 1): ?>
                <div class="d-flex justify-content-between align-items-center p-3" style="border-top:1px solid var(--border-color)">
                    <span style="font-size:13px;color:var(--text-muted)">Página <?= $pagina ?> de <?= $totalPaginas ?></span>
                    <nav>
                        <ul class="pagination mb-0">
                            <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                            <li class="page-item <?= $i==$pagina?'active':'' ?>">
                                <a class="page-link" href="?pagina=<?= $i ?>&busca=<?= urlencode($busca) ?>&status=<?= $filtroStatus ?>&setor=<?= urlencode($filtroSetor) ?>"><?= $i ?></a>
                            </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<!-- Modal Funcionário -->
<div class="modal fade" id="modalFuncionario" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitulo"><i class="bi bi-person-plus me-2"></i>Novo Funcionário</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="formFuncionario">
                <input type="hidden" name="acao" value="salvar">
                <input type="hidden" name="id" id="funcId" value="0">
                <div class="modal-body">
                    <div class="row g-3">
                        <!-- Foto -->
                        <div class="col-12 text-center">
                            <div class="foto-preview" id="fotoPreview" style="width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#2563EB,#7C3AED);display:inline-flex;align-items:center;justify-content:center;font-size:24px;font-weight:700;color:white;cursor:pointer;overflow:hidden;margin-bottom:8px" onclick="document.getElementById('fotoInput').click()">
                                <span id="fotoInitials">?</span>
                            </div>
                            <br>
                            <input type="file" name="foto_perfil" id="fotoInput" accept="image/*" style="display:none" onchange="previewFoto(this)">
                            <button type="button" class="btn btn-outline btn-sm" onclick="document.getElementById('fotoInput').click()">
                                <i class="bi bi-camera"></i> Foto de Perfil
                            </button>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Nome Completo *</label>
                            <input type="text" name="nome" id="funcNome" class="form-control" required oninput="atualizarInitials(this.value)">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">E-mail *</label>
                            <input type="email" name="email" id="funcEmail" class="form-control" required>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">CPF *</label>
                            <input type="text" name="cpf" id="funcCpf" class="form-control" placeholder="000.000.000-00" maxlength="14">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Telefone</label>
                            <input type="text" name="telefone" id="funcTelefone" class="form-control" placeholder="(00) 00000-0000">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Data de Nascimento</label>
                            <input type="date" name="data_nascimento" id="funcNasc" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">CEP</label>
                            <input type="text" name="cep" id="funcCep" class="form-control" placeholder="00000-000" maxlength="9">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Cargo</label>
                            <input type="text" name="cargo" id="funcCargo" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Setor</label>
                            <input type="text" name="setor" id="funcSetor" class="form-control" list="setoresList">
                            <datalist id="setoresList">
                                <?php foreach ($setores as $s): ?>
                                <option value="<?= htmlspecialchars($s) ?>">
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Salário Base (R$)</label>
                            <input type="text" name="salario" id="funcSalario" class="form-control" placeholder="0,00">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Data de Contratação</label>
                            <input type="date" name="data_contratacao" id="funcContratacao" class="form-control">
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Nível de Acesso</label>
                            <select name="nivel_acesso" id="funcNivel" class="form-select">
                                <option value="funcionario">Funcionário</option>
                                <option value="coordenacao">Coordenação</option>
                                <option value="rh">RH</option>
                                <option value="gerente">Gerente</option>
                                <?php if (hasPermission(['admin'])): ?>
                                <option value="admin">Administrador</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Status</label>
                            <select name="status" id="funcStatus" class="form-select">
                                <option value="ativo">Ativo</option>
                                <option value="inativo">Inativo</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Senha <span id="senhaObrig" class="text-danger">*</span></label>
                            <input type="password" name="senha" id="funcSenha" class="form-control" placeholder="Mínimo 6 caracteres">
                            <div class="form-text" style="color:var(--text-muted);font-size:12px">Deixe em branco para manter a senha atual (ao editar)</div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Confirmar Exclusão -->
<div class="modal fade" id="modalExcluir" tabindex="-1">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Confirmar Desativação</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p style="color:var(--text-secondary)">Deseja desativar o funcionário <strong id="nomeExcluir"></strong>?</p>
            </div>
            <div class="modal-footer">
                <form method="POST">
                    <input type="hidden" name="acao" value="excluir">
                    <input type="hidden" name="id" id="idExcluir">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-danger"><i class="bi bi-person-x"></i> Desativar</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $extraJS = '<script>
function abrirModal() {
    document.getElementById("modalTitulo").innerHTML = \'<i class="bi bi-person-plus me-2"></i>Novo Funcionário\';
    document.getElementById("funcId").value = "0";
    document.getElementById("formFuncionario").reset();
    document.getElementById("fotoInitials").textContent = "?";
    document.getElementById("senhaObrig").style.display = "inline";
    new bootstrap.Modal(document.getElementById("modalFuncionario")).show();
}

function editarFuncionario(f) {
    document.getElementById("modalTitulo").innerHTML = \'<i class="bi bi-pencil me-2"></i>Editar Funcionário\';
    document.getElementById("funcId").value = f.id;
    document.getElementById("funcNome").value = f.nome;
    document.getElementById("funcEmail").value = f.email;
    document.getElementById("funcCpf").value = f.cpf;
    document.getElementById("funcTelefone").value = f.telefone || "";
    document.getElementById("funcNasc").value = f.data_nascimento || "";
    document.getElementById("funcCep").value = f.cep || "";
    document.getElementById("funcCargo").value = f.cargo || "";
    document.getElementById("funcSetor").value = f.setor || "";
    document.getElementById("funcSalario").value = f.salario || "";
    document.getElementById("funcContratacao").value = f.data_contratacao || "";
    document.getElementById("funcNivel").value = f.nivel_acesso;
    document.getElementById("funcStatus").value = f.status;
    document.getElementById("funcSenha").value = "";
    document.getElementById("senhaObrig").style.display = "none";
    atualizarInitials(f.nome);
    new bootstrap.Modal(document.getElementById("modalFuncionario")).show();
}

function confirmarExcluir(id, nome) {
    document.getElementById("idExcluir").value = id;
    document.getElementById("nomeExcluir").textContent = nome;
    new bootstrap.Modal(document.getElementById("modalExcluir")).show();
}

function atualizarInitials(nome) {
    const parts = nome.trim().split(" ");
    const initials = parts.length >= 2 ? parts[0][0] + parts[parts.length-1][0] : (parts[0][0] || "?");
    document.getElementById("fotoInitials").textContent = initials.toUpperCase();
}

function previewFoto(input) {
    if (input.files && input.files[0]) {
        const reader = new FileReader();
        reader.onload = e => {
            const preview = document.getElementById("fotoPreview");
            preview.innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover">`;
        };
        reader.readAsDataURL(input.files[0]);
    }
}

// Máscara CPF
document.getElementById("funcCpf").addEventListener("input", function() {
    let v = this.value.replace(/\D/g,"");
    v = v.replace(/(\d{3})(\d)/,"$1.$2");
    v = v.replace(/(\d{3})(\d)/,"$1.$2");
    v = v.replace(/(\d{3})(\d{1,2})$/,"$1-$2");
    this.value = v;
});

// Máscara Telefone
document.getElementById("funcTelefone").addEventListener("input", function() {
    let v = this.value.replace(/\D/g,"");
    v = v.replace(/^(\d{2})(\d)/,"($1) $2");
    v = v.replace(/(\d{5})(\d)/,"$1-$2");
    this.value = v;
});

// Máscara CEP
document.getElementById("funcCep").addEventListener("input", function() {
    let v = this.value.replace(/\D/g,"");
    v = v.replace(/(\d{5})(\d)/,"$1-$2");
    this.value = v;
});
</script>'; ?>

<?php include 'includes/footer.php'; ?>
