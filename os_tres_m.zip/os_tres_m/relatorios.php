<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requireLevel(['rh','admin','gerente','coordenacao']);

$pageTitle = 'Relatórios';
$breadcrumb = 'Relatórios';
$user = currentUser();
$pdo = db();

$tipo = sanitize($_GET['tipo'] ?? 'funcionarios');
$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$usuarioId = (int)($_GET['usuario_id'] ?? 0);

// Dados do relatório
$dados = [];
$titulo_rel = '';

switch ($tipo) {
    case 'funcionarios':
        $titulo_rel = 'Relatório de Funcionários';
        $dados = $pdo->query("SELECT * FROM usuarios ORDER BY nome")->fetchAll();
        break;
    case 'ponto':
        $titulo_rel = 'Relatório de Ponto';
        $sql = "SELECT p.*, u.nome as funcionario_nome, u.cargo, u.setor FROM ponto p JOIN usuarios u ON p.usuario_id = u.id WHERE MONTH(p.data)=$mes AND YEAR(p.data)=$ano";
        if ($usuarioId) $sql .= " AND p.usuario_id=$usuarioId";
        $sql .= " ORDER BY u.nome, p.data";
        $dados = $pdo->query($sql)->fetchAll();
        break;
    case 'presenca':
        $titulo_rel = 'Relatório de Presença';
        $dados = $pdo->query("
            SELECT u.nome, u.cargo, u.setor,
                   COUNT(CASE WHEN p.status='presente' THEN 1 END) as presentes,
                   COUNT(CASE WHEN p.status='falta' THEN 1 END) as faltas,
                   COUNT(CASE WHEN p.status='ausente' THEN 1 END) as ausentes,
                   SUM(p.horas_trabalhadas) as total_horas,
                   SUM(p.horas_extras) as total_extras
            FROM usuarios u
            LEFT JOIN ponto p ON u.id = p.usuario_id AND MONTH(p.data)=$mes AND YEAR(p.data)=$ano
            WHERE u.status='ativo'
            GROUP BY u.id ORDER BY u.nome
        ")->fetchAll();
        break;
    case 'pagamento':
        $titulo_rel = 'Relatório de Pagamento';
        $dados = $pdo->query("
            SELECT fp.*, u.nome, u.cargo, u.setor
            FROM folha_pagamento fp
            JOIN usuarios u ON fp.usuario_id = u.id
            WHERE fp.mes=$mes AND fp.ano=$ano
            ORDER BY u.nome
        ")->fetchAll();
        break;
    case 'tarefas':
        $titulo_rel = 'Relatório de Tarefas';
        $dados = $pdo->query("
            SELECT t.*, u1.nome as atribuido_nome, u2.nome as criado_nome
            FROM tarefas t
            JOIN usuarios u1 ON t.atribuido_para = u1.id
            JOIN usuarios u2 ON t.criado_por = u2.id
            ORDER BY t.criado_em DESC
        ")->fetchAll();
        break;
    case 'produtividade':
        $titulo_rel = 'Relatório de Produtividade';
        $dados = $pdo->query("
            SELECT u.nome, u.cargo, u.setor,
                   COUNT(CASE WHEN t.status='concluida' THEN 1 END) as concluidas,
                   COUNT(CASE WHEN t.status='pendente' THEN 1 END) as pendentes,
                   COUNT(CASE WHEN t.status='em_andamento' THEN 1 END) as andamento,
                   COUNT(t.id) as total_tarefas,
                   SUM(p.horas_trabalhadas) as horas_mes
            FROM usuarios u
            LEFT JOIN tarefas t ON u.id = t.atribuido_para
            LEFT JOIN ponto p ON u.id = p.usuario_id AND MONTH(p.data)=$mes AND YEAR(p.data)=$ano
            WHERE u.status='ativo'
            GROUP BY u.id ORDER BY concluidas DESC
        ")->fetchAll();
        break;
}

$funcionarios = getUsuarios('ativo');
include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div>
                    <h2 style="font-size:20px;font-weight:800;color:var(--text-primary);margin:0">Relatórios</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0"><?= $titulo_rel ?></p>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline btn-sm" onclick="window.print()">
                        <i class="bi bi-printer"></i> Imprimir
                    </button>
                    <a href="api/exportar_pdf.php?tipo=<?= $tipo ?>&mes=<?= $mes ?>&ano=<?= $ano ?>&usuario_id=<?= $usuarioId ?>" class="btn btn-danger btn-sm" target="_blank">
                        <i class="bi bi-file-pdf"></i> PDF
                    </a>
                    <a href="api/exportar_excel.php?tipo=<?= $tipo ?>&mes=<?= $mes ?>&ano=<?= $ano ?>&usuario_id=<?= $usuarioId ?>" class="btn btn-success btn-sm">
                        <i class="bi bi-file-excel"></i> Excel
                    </a>
                </div>
            </div>

            <!-- Tipos de Relatório -->
            <div class="row g-3 mb-4">
                <?php
                $tipos = [
                    ['key'=>'funcionarios','label'=>'Funcionários','icon'=>'people-fill','color'=>'blue'],
                    ['key'=>'ponto','label'=>'Ponto','icon'=>'clock-fill','color'=>'green'],
                    ['key'=>'presenca','label'=>'Presença','icon'=>'calendar-check','color'=>'purple'],
                    ['key'=>'pagamento','label'=>'Pagamento','icon'=>'cash-stack','color'=>'yellow'],
                    ['key'=>'tarefas','label'=>'Tarefas','icon'=>'check2-square','color'=>'blue'],
                    ['key'=>'produtividade','label'=>'Produtividade','icon'=>'graph-up','color'=>'green'],
                ];
                foreach ($tipos as $t):
                ?>
                <div class="col-6 col-md-4 col-xl-2">
                    <a href="?tipo=<?= $t['key'] ?>&mes=<?= $mes ?>&ano=<?= $ano ?>" class="stat-card <?= $t['color'] ?> text-decoration-none d-flex <?= $tipo===$t['key']?'ring-active':'' ?>" style="<?= $tipo===$t['key']?'border-color:var(--azul-principal);box-shadow:0 0 0 2px rgba(37,99,235,0.3)':'' ?>">
                        <div class="stat-icon <?= $t['color'] ?>"><i class="bi bi-<?= $t['icon'] ?>"></i></div>
                        <div class="stat-info">
                            <div style="font-size:13px;font-weight:700;color:var(--text-primary)"><?= $t['label'] ?></div>
                            <div style="font-size:11px;color:var(--text-muted)"><?= count($dados) ?> registros</div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <input type="hidden" name="tipo" value="<?= $tipo ?>">
                        <?php if (in_array($tipo, ['ponto','presenca','pagamento','produtividade'])): ?>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Mês</label>
                            <select name="mes" class="form-select">
                                <?php for ($m=1;$m<=12;$m++): ?>
                                <option value="<?= $m ?>" <?= $m==$mes?'selected':'' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Ano</label>
                            <select name="ano" class="form-select">
                                <?php for ($a=date('Y');$a>=date('Y')-3;$a--): ?>
                                <option value="<?= $a ?>" <?= $a==$ano?'selected':'' ?>><?= $a ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <?php if ($tipo === 'ponto'): ?>
                        <div class="col-12 col-md-4">
                            <label class="form-label">Funcionário</label>
                            <select name="usuario_id" class="form-select">
                                <option value="0">Todos</option>
                                <?php foreach ($funcionarios as $f): ?>
                                <option value="<?= $f['id'] ?>" <?= $f['id']==$usuarioId?'selected':'' ?>><?= htmlspecialchars($f['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="col-12 col-md-2">
                            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Filtrar</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabela do Relatório -->
            <div class="table-wrapper" id="relatorioTabela">
                <div class="card-header">
                    <h5 class="card-title"><i class="bi bi-table me-2"></i><?= $titulo_rel ?></h5>
                    <span style="font-size:12px;color:var(--text-muted)"><?= count($dados) ?> registros</span>
                </div>
                <div class="table-responsive">
                    <?php if ($tipo === 'funcionarios'): ?>
                    <table class="table">
                        <thead><tr><th>#</th><th>Nome</th><th>E-mail</th><th>CPF</th><th>Cargo</th><th>Setor</th><th>Contratação</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php foreach ($dados as $i=>$d): ?>
                            <tr>
                                <td style="color:var(--text-muted)"><?= $i+1 ?></td>
                                <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($d['nome']) ?></td>
                                <td><?= htmlspecialchars($d['email']) ?></td>
                                <td><?= htmlspecialchars($d['cpf']) ?></td>
                                <td><?= htmlspecialchars($d['cargo'] ?: '-') ?></td>
                                <td><?= htmlspecialchars($d['setor'] ?: '-') ?></td>
                                <td><?= formatarData($d['data_contratacao']) ?></td>
                                <td><span class="badge-status status-<?= $d['status'] ?>"><?= ucfirst($d['status']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php elseif ($tipo === 'ponto'): ?>
                    <table class="table">
                        <thead><tr><th>Funcionário</th><th>Data</th><th>Entrada</th><th>Saída</th><th>Horas</th><th>Extras</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php foreach ($dados as $d): ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($d['funcionario_nome']) ?></td>
                                <td><?= formatarData($d['data']) ?></td>
                                <td style="color:var(--verde)"><?= formatarHora($d['entrada']) ?></td>
                                <td style="color:var(--vermelho)"><?= formatarHora($d['saida']) ?></td>
                                <td><?= $d['horas_trabalhadas'] > 0 ? number_format($d['horas_trabalhadas'],1).'h' : '-' ?></td>
                                <td style="color:var(--roxo-claro)"><?= $d['horas_extras'] > 0 ? '+'.number_format($d['horas_extras'],1).'h' : '-' ?></td>
                                <td><span class="badge-status status-<?= $d['status'] ?>"><?= ucfirst($d['status']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php elseif ($tipo === 'presenca'): ?>
                    <table class="table">
                        <thead><tr><th>Funcionário</th><th>Cargo</th><th>Presenças</th><th>Faltas</th><th>Ausências</th><th>Total Horas</th><th>H. Extras</th></tr></thead>
                        <tbody>
                            <?php foreach ($dados as $d): ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($d['nome']) ?></td>
                                <td style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($d['cargo'] ?: '-') ?></td>
                                <td style="color:var(--verde)"><?= $d['presentes'] ?></td>
                                <td style="color:var(--vermelho)"><?= $d['faltas'] ?></td>
                                <td style="color:var(--amarelo)"><?= $d['ausentes'] ?></td>
                                <td><?= number_format($d['total_horas'],1) ?>h</td>
                                <td style="color:var(--roxo-claro)"><?= number_format($d['total_extras'],1) ?>h</td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php elseif ($tipo === 'pagamento'): ?>
                    <table class="table">
                        <thead><tr><th>Funcionário</th><th>Salário Base</th><th>H. Extras</th><th>Benefícios</th><th>Descontos</th><th>Multas</th><th>Valor Final</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php $totalGeral = 0; foreach ($dados as $d): $totalGeral += $d['valor_final']; ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($d['nome']) ?></td>
                                <td><?= formatarMoeda($d['salario_base']) ?></td>
                                <td style="color:var(--verde)"><?= formatarMoeda($d['horas_extras_valor']) ?></td>
                                <td style="color:var(--azul-claro)"><?= formatarMoeda($d['beneficios']) ?></td>
                                <td style="color:var(--vermelho)">-<?= formatarMoeda($d['descontos']) ?></td>
                                <td style="color:var(--vermelho)">-<?= formatarMoeda($d['multas']) ?></td>
                                <td style="font-weight:700"><?= formatarMoeda($d['valor_final']) ?></td>
                                <td><span class="badge-status status-<?= $d['status'] ?>"><?= ucfirst($d['status']) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr style="background:var(--bg-secondary)">
                                <td colspan="6" style="font-weight:700;text-align:right">TOTAL:</td>
                                <td style="font-weight:800;color:var(--azul-claro)"><?= formatarMoeda($totalGeral) ?></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>

                    <?php elseif ($tipo === 'tarefas'): ?>
                    <table class="table">
                        <thead><tr><th>Título</th><th>Atribuído a</th><th>Criado por</th><th>Prioridade</th><th>Prazo</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php foreach ($dados as $d): ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($d['titulo']) ?></td>
                                <td><?= htmlspecialchars($d['atribuido_nome']) ?></td>
                                <td style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($d['criado_nome']) ?></td>
                                <td><span class="badge-status prioridade-<?= $d['prioridade'] ?>"><?= ucfirst($d['prioridade']) ?></span></td>
                                <td style="font-size:12px"><?= $d['prazo'] ? formatarData($d['prazo']) : '-' ?></td>
                                <td><span class="badge-status status-<?= $d['status'] ?>"><?= str_replace('_',' ',ucfirst($d['status'])) ?></span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <?php elseif ($tipo === 'produtividade'): ?>
                    <table class="table">
                        <thead><tr><th>Funcionário</th><th>Cargo</th><th>Concluídas</th><th>Pendentes</th><th>Andamento</th><th>Total</th><th>Horas/Mês</th><th>Eficiência</th></tr></thead>
                        <tbody>
                            <?php foreach ($dados as $d): ?>
                            <?php $efic = $d['total_tarefas'] > 0 ? round(($d['concluidas']/$d['total_tarefas'])*100) : 0; ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($d['nome']) ?></td>
                                <td style="font-size:12px;color:var(--text-muted)"><?= htmlspecialchars($d['cargo'] ?: '-') ?></td>
                                <td style="color:var(--verde)"><?= $d['concluidas'] ?></td>
                                <td style="color:var(--amarelo)"><?= $d['pendentes'] ?></td>
                                <td style="color:var(--azul-claro)"><?= $d['andamento'] ?></td>
                                <td><?= $d['total_tarefas'] ?></td>
                                <td><?= number_format($d['horas_mes'],1) ?>h</td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="progress flex-fill" style="height:6px">
                                            <div class="progress-bar <?= $efic>=70?'green':($efic>=40?'blue':'') ?>" style="width:<?= $efic ?>%;background:<?= $efic>=70?'var(--verde)':($efic>=40?'var(--azul-claro)':'var(--vermelho)') ?>"></div>
                                        </div>
                                        <span style="font-size:12px;font-weight:600;color:<?= $efic>=70?'var(--verde)':($efic>=40?'var(--azul-claro)':'var(--vermelho)') ?>"><?= $efic ?>%</span>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php endif; ?>

                    <?php if (empty($dados)): ?>
                    <div style="text-align:center;padding:40px;color:var(--text-muted)">
                        <i class="bi bi-inbox" style="font-size:32px;display:block;margin-bottom:8px"></i>
                        Nenhum dado encontrado para este período
                    </div>
                    <?php endif; ?>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
