<?php
/**
 * Cria/atualiza usuários Gerente e Coordenação no banco.
 * Acesse: http://localhost/os_tres_m/criar_perfis.php
 * Apague após usar em produção.
 */
$ipLocal = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
$ehCli = (php_sapi_name() === 'cli');
if (!$ehCli && !in_array($ipLocal, ['127.0.0.1', '::1'], true)) {
    http_response_code(403);
    die('Acesso negado. Execute apenas em localhost.');
}

require_once 'config/database.php';
require_once 'config/functions.php';

header('Content-Type: text/html; charset=utf-8');

$usuarios = [
    'gerente@ostresm.com' => [
        'senha' => 'Gerente@123',
        'nome' => 'Gerente Operacional',
        'cpf' => '222.222.222-22',
        'cargo' => 'Gerente',
        'setor' => 'Operações',
        'nivel_acesso' => 'gerente',
    ],
    'coordenacao@ostresm.com' => [
        'senha' => 'Coord@123456',
        'nome' => 'Coordenação Geral',
        'cpf' => '333.333.333-33',
        'cargo' => 'Coordenador',
        'setor' => 'Operações',
        'nivel_acesso' => 'coordenacao',
    ],
];

$log = [];
try {
    $pdo = db();
    $buscar = $pdo->prepare('SELECT id FROM usuarios WHERE email = ? LIMIT 1');
    $atualizar = $pdo->prepare('
        UPDATE usuarios SET nome=?, senha=?, cpf=?, cargo=?, setor=?, nivel_acesso=?, status=\'ativo\'
        WHERE email=?
    ');
    $inserir = $pdo->prepare('
        INSERT INTO usuarios (nome, email, senha, cpf, cargo, setor, nivel_acesso, status, data_contratacao)
        VALUES (?, ?, ?, ?, ?, ?, ?, \'ativo\', CURDATE())
    ');

    foreach ($usuarios as $email => $d) {
        $hash = hashSenha($d['senha']);
        $buscar->execute([$email]);
        if ($buscar->fetchColumn()) {
            $atualizar->execute([$d['nome'], $hash, $d['cpf'], $d['cargo'], $d['setor'], $d['nivel_acesso'], $email]);
            $log[] = "Atualizado: $email";
        } else {
            $inserir->execute([$d['nome'], $email, $hash, $d['cpf'], $d['cargo'], $d['setor'], $d['nivel_acesso']]);
            $log[] = "Criado: $email";
        }
        $ok = password_verify($d['senha'], $hash);
        $log[] = 'Teste senha ' . ($ok ? 'OK' : 'FALHOU') . " — {$d['senha']}";
    }

    $lista = $pdo->query("SELECT email, nivel_acesso, status FROM usuarios WHERE email IN ('gerente@ostresm.com','coordenacao@ostresm.com')")->fetchAll();
} catch (Exception $e) {
    $log[] = 'ERRO: ' . $e->getMessage();
    $lista = [];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Criar perfis — Os Três M</title>
<style>
body{font-family:system-ui,sans-serif;background:#0f1117;color:#f1f5f9;padding:40px;max-width:640px;margin:0 auto}
.ok{color:#6ee7b7}.card{background:#1e2130;border-radius:12px;padding:24px;margin-top:20px}
a.btn{display:inline-block;margin-top:16px;padding:12px 20px;background:#2563eb;color:#fff;text-decoration:none;border-radius:8px;font-weight:700}
table{width:100%;border-collapse:collapse;margin-top:12px;font-size:14px}
th,td{padding:8px;text-align:left;border-bottom:1px solid rgba(255,255,255,.08)}
</style>
</head>
<body>
<h1>Perfis Gerente e Coordenação</h1>
<div class="card">
<?php foreach ($log as $m): ?>
<p class="ok"><?= htmlspecialchars($m) ?></p>
<?php endforeach; ?>
<?php if ($lista): ?>
<table>
<tr><th>E-mail</th><th>Perfil</th><th>Status</th></tr>
<?php foreach ($lista as $u): ?>
<tr><td><?= htmlspecialchars($u['email']) ?></td><td><?= htmlspecialchars($u['nivel_acesso']) ?></td><td><?= htmlspecialchars($u['status']) ?></td></tr>
<?php endforeach; ?>
</table>
<?php endif; ?>
<a class="btn" href="login.php">Ir para o Login</a>
</div>
<p style="color:#64748b;font-size:13px;margin-top:24px">Apague <code>criar_perfis.php</code> após confirmar o acesso.</p>
</body>
</html>
