-- ============================================
-- BANCO DE DADOS - OS TRÊS M
-- Sistema Empresarial Completo
-- ============================================

CREATE DATABASE IF NOT EXISTS os_tres_m CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE os_tres_m;

-- ============================================
-- TABELA: usuarios
-- ============================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    cpf VARCHAR(14) NOT NULL UNIQUE,
    data_nascimento DATE,
    cep VARCHAR(10),
    telefone VARCHAR(20),
    cargo VARCHAR(100),
    setor VARCHAR(100),
    salario DECIMAL(10,2) DEFAULT 0.00,
    data_contratacao DATE,
    nivel_acesso ENUM('funcionario','coordenacao','rh','gerente','admin') DEFAULT 'funcionario',
    status ENUM('ativo','inativo') DEFAULT 'ativo',
    foto_perfil VARCHAR(255) DEFAULT NULL,
    ultimo_acesso DATETIME DEFAULT NULL,
    online TINYINT(1) DEFAULT 0,
    token_recuperacao VARCHAR(255) DEFAULT NULL,
    token_expiracao DATETIME DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- TABELA: ponto
-- ============================================
CREATE TABLE IF NOT EXISTS ponto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data DATE NOT NULL,
    entrada TIME DEFAULT NULL,
    saida TIME DEFAULT NULL,
    horas_trabalhadas DECIMAL(5,2) DEFAULT 0.00,
    horas_extras DECIMAL(5,2) DEFAULT 0.00,
    atraso DECIMAL(5,2) DEFAULT 0.00,
    status ENUM('presente','ausente','falta','ferias','licenca') DEFAULT 'presente',
    observacao TEXT DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: folha_pagamento
-- ============================================
CREATE TABLE IF NOT EXISTS folha_pagamento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    mes INT NOT NULL,
    ano INT NOT NULL,
    salario_base DECIMAL(10,2) DEFAULT 0.00,
    horas_extras_valor DECIMAL(10,2) DEFAULT 0.00,
    descontos DECIMAL(10,2) DEFAULT 0.00,
    beneficios DECIMAL(10,2) DEFAULT 0.00,
    multas DECIMAL(10,2) DEFAULT 0.00,
    valor_final DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('pendente','processado','pago') DEFAULT 'pendente',
    observacao TEXT DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: tarefas
-- ============================================
CREATE TABLE IF NOT EXISTS tarefas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descricao TEXT,
    criado_por INT NOT NULL,
    atribuido_para INT NOT NULL,
    prazo DATE,
    prioridade ENUM('baixa','media','alta','urgente') DEFAULT 'media',
    status ENUM('pendente','em_andamento','concluida','cancelada') DEFAULT 'pendente',
    observacoes TEXT DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (criado_por) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (atribuido_para) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: notificacoes
-- ============================================
CREATE TABLE IF NOT EXISTS notificacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(200) NOT NULL,
    mensagem TEXT NOT NULL,
    tipo ENUM('tarefa','aviso','ponto','pagamento','chat','sistema') DEFAULT 'sistema',
    lida TINYINT(1) DEFAULT 0,
    link VARCHAR(255) DEFAULT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: conversas (chat)
-- ============================================
CREATE TABLE IF NOT EXISTS conversas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario1_id INT NOT NULL,
    usuario2_id INT NOT NULL,
    ultima_mensagem TEXT DEFAULT NULL,
    ultima_mensagem_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario1_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario2_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: mensagens (chat)
-- ============================================
CREATE TABLE IF NOT EXISTS mensagens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversa_id INT NOT NULL,
    remetente_id INT NOT NULL,
    mensagem TEXT NOT NULL,
    lida TINYINT(1) DEFAULT 0,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversa_id) REFERENCES conversas(id) ON DELETE CASCADE,
    FOREIGN KEY (remetente_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ============================================
-- TABELA: logs_sistema
-- ============================================
CREATE TABLE IF NOT EXISTS logs_sistema (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT DEFAULT NULL,
    acao VARCHAR(200) NOT NULL,
    descricao TEXT,
    ip VARCHAR(45),
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ============================================
-- TABELA: configuracoes
-- ============================================
CREATE TABLE IF NOT EXISTS configuracoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT,
    descricao VARCHAR(255),
    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================
-- DADOS INICIAIS
-- ============================================

-- Configurações padrão
INSERT INTO configuracoes (chave, valor, descricao) VALUES
('empresa_nome', 'Os Três M', 'Nome da empresa'),
('empresa_cnpj', '00.000.000/0001-00', 'CNPJ da empresa'),
('horario_entrada', '08:00', 'Horário padrão de entrada'),
('horario_saida', '17:00', 'Horário padrão de saída'),
('horas_diarias', '8', 'Horas de trabalho por dia'),
('tolerancia_atraso', '10', 'Tolerância de atraso em minutos'),
('valor_hora_extra', '1.5', 'Multiplicador hora extra');

-- Usuário administrador padrão
-- Senha: Admin@123
-- Hash gerado com password_hash('Admin@123', PASSWORD_BCRYPT, ['cost'=>10])
INSERT INTO usuarios (nome, email, senha, cpf, cargo, setor, nivel_acesso, status, data_contratacao) VALUES
('Administrador', 'admin@ostresm.com', '$2y$10$TKh8H1.PfQ1HqjNIsITve.RPtZQMkPm1ZQ5oYhHMJHnpoH4lCyOW2', '000.000.000-00', 'Administrador', 'Administração', 'admin', 'ativo', CURDATE());

-- Usuário RH padrão
-- Senha: Rh@123456
INSERT INTO usuarios (nome, email, senha, cpf, cargo, setor, nivel_acesso, status, data_contratacao) VALUES
('Recursos Humanos', 'rh@ostresm.com', '$2y$10$TKh8H1.PfQ1HqjNIsITve.RPtZQMkPm1ZQ5oYhHMJHnpoH4lCyOW2', '111.111.111-11', 'Analista RH', 'RH', 'rh', 'ativo', CURDATE());

-- IMPORTANTE: Após importar, acesse o sistema e troque as senhas.
-- Ou use este script para gerar hashes corretos:
-- php -r "echo password_hash('SuaSenha', PASSWORD_BCRYPT);"
