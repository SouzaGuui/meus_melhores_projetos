<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requireLevel(['rh','admin','gerente']);

$pageTitle = 'Folha de Pagamento';
$breadcrumb = 'Pagamento';
$user = currentUser();
$pdo = db();

$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));

// Salvar folha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $acao = $_POST['acao'];

    if ($acao === 'salvar') {
        $uid = (int)($_POST['usuario_id'] ?? 0);
        $salBase = (float)str_replace(['.', ','], ['', '.'], $_POST['salario_base'] ?? '0');
        $hExtra = (float)str_replace(['.', ','], ['', '.'], $_POST['horas_extras_valor'] ?? '0');
        $desc = (float)str_replace(['.', ','], ['', '.'], $_POST['descontos'] ?? '0');
        $benef = (float)str_replace(['.', ','], ['', '.'], $_POST['beneficios'] ?? '0');
        $multas = (float)str_replace(['.', ','], ['', '.'], $_POST['multas'] ?? '0');
        $obs = sanitize($_POST['observacao'] ?? '');
        $statusFolha = sanitize($_POST['status'] ?? 'pendente');
        $mFolha = (int)($_POST['mes'] ?? $mes);
        $aFolha = (int)($_POST['ano'] ?? $ano);
        $final = $salBase + $hExtra + $benef - $desc - $multas;

        // Verificar se já existe
        $existe = $pdo->prepare("SELECT id FROM folha_pagamento WHERE usuario_id=? AND mes=? AND ano=?");
        $existe->execute([$uid,$mFolha,$aFolha]);
        $folhaExist = $existe->fetch();

        if ($folhaExist) {
            $pdo->prepare("UPDATE folha_pagamento SET salario_base=?,horas_extras_valor=?,descontos=?,beneficios=?,multas=?,valor_final=?,status=?,observacao=? WHERE id=?")
                ->execute([$salBase,$hExtra,$desc,$benef,$multas,$final,$statusFolha,$obs,$folhaExist['id']]);
        } else {
            $pdo->prepare("INSERT INTO folha_pagamento (usuario_id,mes,ano,salario_base,horas_extras_valor,descontos,beneficios,multas,valor_final,status,observacao) VALUES (?,?,?,?,?,?,?,?,?,?,?)")
                ->execute([$uid,$mFolha,$aFolha,$salBase,$hExtra,$desc,$benef,$multas,$final,$statusFolha,$obs]);
        }
        criarNotificacao($uid, 'Folha de Pagamento', "Sua folha de pagamento de " . date('F/Y', mktime(0,0,0,$mFolha,1,$aFolha)) . " foi processada.", 'pagamento');
        registrarLog('folha_pagamento', "Folha processada para usuário $uid");
        header("Location: pagamento.php?mes=$mes&ano=$ano&msg=Folha+salva+com+sucesso&tipo=success");
        exit;
    }

    if ($acao === 'gerar_todos') {
        $funcs = getUsuarios('ativo');
        foreach ($funcs as $f) {
            $existe = $pdo->prepare("SELECT id FROM folha_pagamento WHERE usuario_id=? AND mes=? AND ano=?");
            $existe->execute([$f['id'],$mes,$ano]);
            if (!$existe->fetch()) {
                // Calcular horas extras do mês
                $hExtras = $pdo->prepare("SELECT SUM(horas_extras) FROM ponto WHERE usuario_id=? AND MONTH(data)=? AND YEAR(data)=?");
                $hExtras->execute([$f['id'],$mes,$ano]);
                $totalExtras = (float)$hExtras->fetchColumn();
                $valorExtra = $totalExtras * ($f['salario'] / 176) * 1.5;
                $final = $f['salario'] + $valorExtra;
                $pdo->prepare("INSERT INTO folha_pagamento (usuario_id,mes,ano,salario_base,horas_extras_valor,valor_final,status) VALUES (?,?,?,?,?,?,'pendente')")
                    ->execute([$f['id'],$mes,$ano,$f['salario'],$valorExtra,$final]);
            }
        }
        header("Location: pagamento.php?mes=$mes&ano=$ano&msg=Folhas+geradas+com+sucesso&tipo=success");
        exit;
    }
}

// Buscar folhas do mês
$stmt = $pdo->prepare("
    SELECT fp.*, u.nome, u.cargo, u.setor, u.foto_perfil
    FROM folha_pagamento fp
    JOIN usuarios u ON fp.usuario_id = u.id
    WHERE fp.mes = ? AND fp.ano = ?
    ORDER BY u.nome
");
$stmt->execute([$mes,$ano]);
$folhas = $stmt->fetchAll();

$totalFolha = array_sum(array_column($folhas,'valor_final'));
$totalPago = array_sum(array_column(array_filter($folhas, fn($f)=>$f['status']==='pago'),'valor_final'));

$funcionarios = getUsuarios('ativo');
$mensagem = sanitize($_GET['msg'] ?? '');
$tipoMsg = sanitize($_GET['tipo'] ?? 'info');

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <?php if ($mensagem): ?>
            <div class="alert alert-<?= $tipoMsg ?> fade-in mb-3">
                <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($mensagem) ?>
            </div>
            <?php endif; ?>

            <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div>
                    <h2 style="font-size:20px;font-weight:800;color:var(--text-primary);margin:0">Folha de Pagamento</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0"><?= date('F/Y', mktime(0,0,0,$mes,1,$ano)) ?></p>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <form method="GET" class="d-flex gap-2">
                        <select name="mes" class="form-select form-select-sm" style="width:auto">
                            <?php for ($m=1;$m<=12;$m++): ?>
                            <option value="<?= $m ?>" <?= $m==$mes?'selected':'' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                            <?php endfor; ?>
                        </select>
                        <select name="ano" class="form-select form-select-sm" style="width:auto">
                            <?php for ($a=date('Y');$a>=date('Y')-3;$a--): ?>
                            <option value="<?= $a ?>" <?= $a==$ano?'selected':'' ?>><?= $a ?></option>
                            <?php endfor; ?>
                        </select>
                        <button type="submit" class="btn btn-outline btn-sm"><i class="bi bi-search"></i></button>
                    </form>
                    <?php if (hasPermission(['rh','admin'])): ?>
                    <form method="POST">
                        <input type="hidden" name="acao" value="gerar_todos">
                        <button type="submit" class="btn btn-outline btn-sm" onclick="return confirm('Gerar folha para todos os funcionários?')">
                            <i class="bi bi-lightning-fill"></i> Gerar Todas
                        </button>
                    </form>
                    <button class="btn btn-primary btn-sm" onclick="abrirModal()">
                        <i class="bi bi-plus-circle"></i> Nova Folha
                    </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Stats -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="stat-card purple">
                        <div class="stat-icon purple"><i class="bi bi-cash-stack"></i></div>
                        <div class="stat-info">
                            <div class="stat-value" style="font-size:16px"><?= formatarMoeda($totalFolha) ?></div>
                            <div class="stat-label">Total da Folha</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card green">
                        <div class="stat-icon green"><i class="bi bi-check-circle"></i></div>
                        <div class="stat-info">
                            <div class="stat-value" style="font-size:16px"><?= formatarMoeda($totalPago) ?></div>
                            <div class="stat-label">Total Pago</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card blue">
                        <div class="stat-icon blue"><i class="bi bi-people"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= count($folhas) ?></div>
                            <div class="stat-label">Funcionários</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card yellow">
                        <div class="stat-icon yellow"><i class="bi bi-hourglass"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= count(array_filter($folhas,fn($f)=>$f['status']==='pendente')) ?></div>
                            <div class="stat-label">Pendentes</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabela -->
            <div class="table-wrapper">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Funcionário</th>
                                <th>Salário Base</th>
                                <th>H. Extras</th>
                                <th>Benefícios</th>
                                <th>Descontos</th>
                                <th>Multas</th>
                                <th>Valor Final</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($folhas)): ?>
                            <tr>
                                <td colspan="9" class="text-center" style="padding:40px;color:var(--text-muted)">
                                    <i class="bi bi-cash-coin" style="font-size:32px;display:block;margin-bottom:8px"></i>
                                    Nenhuma folha gerada para este período
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($folhas as $f): ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div class="user-avatar" style="width:34px;height:34px;font-size:12px">
                                            <?= strtoupper(substr($f['nome'],0,2)) ?>
                                        </div>
                                        <div>
                                            <div style="font-weight:600;color:var(--text-primary);font-size:13px"><?= htmlspecialchars($f['nome']) ?></div>
                                            <div style="font-size:11px;color:var(--text-muted)"><?= htmlspecialchars($f['cargo'] ?: $f['setor']) ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td><?= formatarMoeda($f['salario_base']) ?></td>
                                <td style="color:var(--verde)"><?= formatarMoeda($f['horas_extras_valor']) ?></td>
                                <td style="color:var(--azul-claro)"><?= formatarMoeda($f['beneficios']) ?></td>
                                <td style="color:var(--vermelho)">-<?= formatarMoeda($f['descontos']) ?></td>
                                <td style="color:var(--vermelho)">-<?= formatarMoeda($f['multas']) ?></td>
                                <td style="font-weight:700;color:var(--text-primary)"><?= formatarMoeda($f['valor_final']) ?></td>
                                <td>
                                    <select class="form-select form-select-sm" style="width:auto;font-size:12px" onchange="atualizarStatusFolha(this,<?= $f['id'] ?>)">
                                        <option value="pendente" <?= $f['status']==='pendente'?'selected':'' ?>>Pendente</option>
                                        <option value="processado" <?= $f['status']==='processado'?'selected':'' ?>>Processado</option>
                                        <option value="pago" <?= $f['status']==='pago'?'selected':'' ?>>Pago</option>
                                    </select>
                                </td>
                                <td>
                                    <div class="d-flex gap-1">
                                        <button class="btn btn-outline btn-icon btn-sm" onclick="editarFolha(<?= htmlspecialchars(json_encode($f)) ?>)" title="Editar">
                                            <i class="bi bi-pencil-fill" style="color:var(--azul-claro)"></i>
                                        </button>
                                        <a href="api/gerar_holerite.php?id=<?= $f['id'] ?>" class="btn btn-outline btn-icon btn-sm" title="Holerite PDF" target="_blank">
                                            <i class="bi bi-file-pdf-fill" style="color:var(--vermelho)"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                        <?php if (!empty($folhas)): ?>
                        <tfoot>
                            <tr style="background:var(--bg-secondary)">
                                <td colspan="6" style="font-weight:700;color:var(--text-primary);text-align:right">TOTAL:</td>
                                <td style="font-weight:800;color:var(--azul-claro);font-size:15px"><?= formatarMoeda($totalFolha) ?></td>
                                <td colspan="2"></td>
                            </tr>
                        </tfoot>
                        <?php endif; ?>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal Folha -->
<div class="modal fade" id="modalFolha" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="folhaModalTitulo"><i class="bi bi-cash-stack me-2"></i>Nova Folha de Pagamento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <input type="hidden" name="acao" value="salvar">
                <input type="hidden" name="mes" value="<?= $mes ?>">
                <input type="hidden" name="ano" value="<?= $ano ?>">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Funcionário *</label>
                            <select name="usuario_id" id="folhaUsuario" class="form-select" required onchange="carregarSalario(this)">
                                <option value="">Selecione...</option>
                                <?php foreach ($funcionarios as $f): ?>
                                <option value="<?= $f['id'] ?>" data-salario="<?= $f['salario'] ?>"><?= htmlspecialchars($f['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label">Salário Base (R$)</label>
                            <input type="text" name="salario_base" id="folhaSalario" class="form-control" placeholder="0,00">
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label">Horas Extras (R$)</label>
                            <input type="text" name="horas_extras_valor" class="form-control" placeholder="0,00" value="0">
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label">Benefícios (R$)</label>
                            <input type="text" name="beneficios" class="form-control" placeholder="0,00" value="0">
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label">Descontos (R$)</label>
                            <input type="text" name="descontos" class="form-control" placeholder="0,00" value="0">
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label">Multas (R$)</label>
                            <input type="text" name="multas" class="form-control" placeholder="0,00" value="0">
                        </div>
                        <div class="col-6 col-md-4">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="pendente">Pendente</option>
                                <option value="processado">Processado</option>
                                <option value="pago">Pago</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observação</label>
                            <textarea name="observacao" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $extraJS = '<script>
function abrirModal() {
    document.getElementById("folhaModalTitulo").innerHTML = \'<i class="bi bi-cash-stack me-2"></i>Nova Folha de Pagamento\';
    new bootstrap.Modal(document.getElementById("modalFolha")).show();
}

function editarFolha(f) {
    document.getElementById("folhaModalTitulo").innerHTML = \'<i class="bi bi-pencil me-2"></i>Editar Folha\';
    document.getElementById("folhaUsuario").value = f.usuario_id;
    document.getElementById("folhaSalario").value = f.salario_base;
    new bootstrap.Modal(document.getElementById("modalFolha")).show();
}

function carregarSalario(sel) {
    const opt = sel.options[sel.selectedIndex];
    document.getElementById("folhaSalario").value = opt.dataset.salario || "0";
}

function atualizarStatusFolha(sel, id) {
    fetch("api/folha_status.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({id, status: sel.value})
    })
    .then(r => r.json())
    .then(d => { if (d.sucesso) showToast("Status atualizado!", "success"); });
}
</script>'; ?>

<?php include 'includes/footer.php'; ?>
