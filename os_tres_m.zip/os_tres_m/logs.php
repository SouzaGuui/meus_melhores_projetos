<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requireLevel(['admin']);

$pageTitle = 'Logs do Sistema';
$breadcrumb = 'Logs';
$user = currentUser();
$pdo = db();

// Filtros
$busca       = sanitize($_GET['busca'] ?? '');
$filtroUser  = (int)($_GET['usuario_id'] ?? 0);
$filtroTipo  = sanitize($_GET['tipo'] ?? '');
$dataInicio  = sanitize($_GET['data_inicio'] ?? date('Y-m-01'));
$dataFim     = sanitize($_GET['data_fim'] ?? date('Y-m-d'));
$pagina      = max(1, (int)($_GET['pagina'] ?? 1));
$porPagina   = 50;
$offset      = ($pagina - 1) * $porPagina;

$where  = "WHERE l.criado_em BETWEEN ? AND ?";
$params = [$dataInicio . ' 00:00:00', $dataFim . ' 23:59:59'];

if ($busca) {
    $where   .= " AND (l.acao LIKE ? OR l.descricao LIKE ? OR l.ip LIKE ?)";
    $params[] = "%$busca%";
    $params[] = "%$busca%";
    $params[] = "%$busca%";
}
if ($filtroUser) {
    $where   .= " AND l.usuario_id = ?";
    $params[] = $filtroUser;
}
if ($filtroTipo) {
    $where   .= " AND l.acao LIKE ?";
    $params[] = '%' . $filtroTipo . '%';
}

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM logs_sistema l $where");
$totalStmt->execute($params);
$total       = $totalStmt->fetchColumn();
$totalPaginas = ceil($total / $porPagina);

$stmt = $pdo->prepare("
    SELECT l.*, u.nome as usuario_nome
    FROM logs_sistema l
    LEFT JOIN usuarios u ON l.usuario_id = u.id
    $where
    ORDER BY l.criado_em DESC
    LIMIT $porPagina OFFSET $offset
");
$stmt->execute($params);
$logs = $stmt->fetchAll();

$usuarios = getUsuarios('todos');

// Ícones por ação
function logIcon($acao) {
    $map = [
        'login'              => ['bi-box-arrow-in-right', 'var(--verde)'],
        'logout'             => ['bi-box-arrow-left',     'var(--text-muted)'],
        'login_falha'        => ['bi-exclamation-triangle','var(--vermelho)'],
        'novo_funcionario'   => ['bi-person-plus',         'var(--azul-claro)'],
        'editar_funcionario' => ['bi-pencil',              'var(--amarelo)'],
        'desativar_funcionario'=>['bi-person-x',           'var(--vermelho)'],
        'ponto_entrada'      => ['bi-clock',               'var(--verde)'],
        'ponto_saida'        => ['bi-clock-history',       'var(--azul-claro)'],
        'editar_ponto'       => ['bi-pencil-square',       'var(--amarelo)'],
        'nova_tarefa'        => ['bi-plus-square',         'var(--roxo-claro)'],
        'editar_tarefa'      => ['bi-pencil',              'var(--amarelo)'],
        'folha_pagamento'    => ['bi-cash-stack',          'var(--verde)'],
        'configuracoes'      => ['bi-gear',                'var(--text-muted)'],
        'atualizar_perfil'   => ['bi-person-gear',         'var(--azul-claro)'],
        'alterar_senha'      => ['bi-shield-lock',         'var(--roxo-claro)'],
        'recuperar_senha'    => ['bi-key',                 'var(--amarelo)'],
    ];
    foreach ($map as $key => $val) {
        if (str_contains($acao, $key)) return $val;
    }
    return ['bi-circle', 'var(--text-muted)'];
}

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <!-- Header -->
            <div class="d-flex align-items-center justify-content-between mb-4 flex-wrap gap-3">
                <div>
                    <h2 style="font-size:20px;font-weight:800;color:var(--text-primary);margin:0">Logs do Sistema</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0"><?= number_format($total) ?> registro(s) encontrado(s)</p>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <button type="button" class="btn btn-danger btn-sm" id="btnLimparLogs">
                        <i class="bi bi-trash"></i> Limpar Logs
                    </button>
                    <?php if (podeExportar()): ?>
                    <a href="api/exportar_excel.php?tipo=logs&data_inicio=<?= $dataInicio ?>&data_fim=<?= $dataFim ?>&busca=<?= urlencode($busca) ?>&tipo_acao=<?= urlencode($filtroTipo) ?>"
                       class="btn btn-success btn-sm">
                        <i class="bi bi-file-excel"></i> Exportar CSV
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <div class="col-12 col-md-3">
                            <label class="form-label">Pesquisar</label>
                            <input type="text" name="busca" class="form-control"
                                   placeholder="Ação, descrição ou IP..."
                                   value="<?= htmlspecialchars($busca) ?>">
                        </div>
                        <div class="col-12 col-md-3">
                            <label class="form-label">Usuário</label>
                            <select name="usuario_id" class="form-select">
                                <option value="0">Todos</option>
                                <?php foreach ($usuarios as $u): ?>
                                <option value="<?= $u['id'] ?>" <?= $u['id']==$filtroUser?'selected':'' ?>>
                                    <?= htmlspecialchars($u['nome']) ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" class="form-control" value="<?= $dataInicio ?>">
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" class="form-control" value="<?= $dataFim ?>">
                        </div>
                        <div class="col-12 col-md-2">
                            <label class="form-label">Tipo de ação</label>
                            <select name="tipo" class="form-select">
                                <option value="">Todas</option>
                                <?php
                                $tiposLog = ['login','logout','ponto','tarefa','calendario','horas_extras','folha','funcionario','configuracoes','logs'];
                                foreach ($tiposLog as $tl):
                                ?>
                                <option value="<?= $tl ?>" <?= $filtroTipo === $tl ? 'selected' : '' ?>><?= ucfirst(str_replace('_', ' ', $tl)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-2 d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-fill">
                                <i class="bi bi-search"></i> Filtrar
                            </button>
                            <a href="logs.php" class="btn btn-outline"><i class="bi bi-x"></i></a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabela de Logs -->
            <div class="table-wrapper">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Ação</th>
                                <th>Usuário</th>
                                <th>Descrição</th>
                                <th>IP</th>
                                <th>Data/Hora</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($logs)): ?>
                            <tr>
                                <td colspan="6" class="text-center"
                                    style="padding:40px;color:var(--text-muted)">
                                    <i class="bi bi-journal-x"
                                       style="font-size:32px;display:block;margin-bottom:8px"></i>
                                    Nenhum log encontrado
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($logs as $i => $log):
                                [$icon, $color] = logIcon($log['acao']);
                            ?>
                            <tr>
                                <td style="color:var(--text-muted);font-size:12px">
                                    <?= $offset + $i + 1 ?>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center gap-2">
                                        <div style="width:30px;height:30px;border-radius:8px;
                                                    background:<?= str_replace(')',',0.12)',$color) ?>;
                                                    display:flex;align-items:center;justify-content:center;
                                                    color:<?= $color ?>;font-size:13px;flex-shrink:0">
                                            <i class="bi <?= $icon ?>"></i>
                                        </div>
                                        <span style="font-size:13px;font-weight:600;color:var(--text-primary)">
                                            <?= htmlspecialchars(str_replace('_',' ',ucfirst($log['acao']))) ?>
                                        </span>
                                    </div>
                                </td>
                                <td>
                                    <?php if ($log['usuario_nome']): ?>
                                    <span style="font-size:13px;color:var(--text-secondary)">
                                        <?= htmlspecialchars($log['usuario_nome']) ?>
                                    </span>
                                    <?php else: ?>
                                    <span style="font-size:12px;color:var(--text-muted)">Sistema</span>
                                    <?php endif; ?>
                                </td>
                                <td style="font-size:12px;color:var(--text-muted);max-width:280px">
                                    <?= htmlspecialchars(substr($log['descricao'] ?? '', 0, 80)) ?>
                                </td>
                                <td>
                                    <code style="font-size:11px;color:var(--text-muted);
                                                 background:var(--bg-secondary);padding:2px 6px;
                                                 border-radius:4px">
                                        <?= htmlspecialchars($log['ip'] ?? '-') ?>
                                    </code>
                                </td>
                                <td style="font-size:12px;color:var(--text-muted);white-space:nowrap">
                                    <?= formatarDataHora($log['criado_em']) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginação -->
                <?php if ($totalPaginas > 1): ?>
                <div class="d-flex justify-content-between align-items-center p-3"
                     style="border-top:1px solid var(--border-color)">
                    <span style="font-size:13px;color:var(--text-muted)">
                        Página <?= $pagina ?> de <?= $totalPaginas ?>
                        (<?= number_format($total) ?> registros)
                    </span>
                    <nav>
                        <ul class="pagination mb-0">
                            <?php
                            $start = max(1, $pagina - 2);
                            $end   = min($totalPaginas, $pagina + 2);
                            if ($pagina > 1):
                            ?>
                            <li class="page-item">
                                <a class="page-link"
                                   href="?pagina=<?= $pagina-1 ?>&busca=<?= urlencode($busca) ?>&usuario_id=<?= $filtroUser ?>&tipo=<?= urlencode($filtroTipo) ?>&data_inicio=<?= $dataInicio ?>&data_fim=<?= $dataFim ?>">
                                    ‹
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php for ($p = $start; $p <= $end; $p++): ?>
                            <li class="page-item <?= $p==$pagina?'active':'' ?>">
                                <a class="page-link"
                                   href="?pagina=<?= $p ?>&busca=<?= urlencode($busca) ?>&usuario_id=<?= $filtroUser ?>&tipo=<?= urlencode($filtroTipo) ?>&data_inicio=<?= $dataInicio ?>&data_fim=<?= $dataFim ?>">
                                    <?= $p ?>
                                </a>
                            </li>
                            <?php endfor; ?>
                            <?php if ($pagina < $totalPaginas): ?>
                            <li class="page-item">
                                <a class="page-link"
                                   href="?pagina=<?= $pagina+1 ?>&busca=<?= urlencode($busca) ?>&usuario_id=<?= $filtroUser ?>&tipo=<?= urlencode($filtroTipo) ?>&data_inicio=<?= $dataInicio ?>&data_fim=<?= $dataFim ?>">
                                    ›
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<?php
$extraJS = '<script>
document.getElementById("btnLimparLogs")?.addEventListener("click", function() {
    const modo = confirm("Deseja limpar os logs do período filtrado?\\n\\nOK = filtro atual | Cancelar = abortar");
    if (!modo) return;
    const limparAntigos = confirm("Limpar também logs com mais de 30 dias? (além do filtro)");
    const payload = {
        modo: "filtrados",
        data_inicio: "' . $dataInicio . '",
        data_fim: "' . $dataFim . '",
        busca: "' . addslashes($busca) . '",
        usuario_id: ' . (int)$filtroUser . ',
        tipo: "' . addslashes($filtroTipo) . '"
    };
    if (limparAntigos) {
        fetch("' . BASE_URL . 'api/logs_limpar.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin",
            body: JSON.stringify({ modo: "todos_antigos", dias: 30 })
        }).then(() => {});
    }
    fetch("' . BASE_URL . 'api/logs_limpar.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify(payload)
    })
    .then(r => r.json())
    .then(d => {
        if (d.sucesso) {
            showToast(d.mensagem || "Logs removidos.", "success");
            setTimeout(() => location.reload(), 600);
        } else showToast(d.erro || "Erro ao limpar.", "danger");
    });
});
</script>';
include 'includes/footer.php';
?>
