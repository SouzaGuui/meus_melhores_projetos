<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($email) || empty($senha)) {
        $erro = 'Preencha todos os campos.';
    } elseif (!validarEmail($email)) {
        $erro = 'E-mail inválido.';
    } else {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND status = 'ativo' LIMIT 1");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();

        if ($usuario && verificarSenha($senha, $usuario['senha'])) {
            setSession($usuario);
            atualizarOnline($usuario['id'], 1);
            registrarLog('login', 'Login realizado com sucesso', $usuario['id']);
            header('Location: ' . BASE_URL . 'dashboard.php');
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos.';
            registrarLog('login_falha', 'Tentativa de login falhou para: ' . $email);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Os Três M</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --azul-principal: #2563EB;
            --azul-claro: #3B82F6;
            --roxo: #7C3AED;
            --roxo-claro: #8B5CF6;
            --preto: #111827;
            --bg: #0F1117;
            --bg-card: #1E2130;
            --border: rgba(255,255,255,0.08);
            --text: #F1F5F9;
            --text-muted: #64748B;
            --verde: #10B981;
            --vermelho: #EF4444;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Inter', sans-serif;
            background: var(--bg);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow: hidden;
        }

        /* Background animado */
        .bg-animated {
            position: fixed;
            inset: 0;
            z-index: 0;
        }

        .bg-blob {
            position: absolute;
            border-radius: 50%;
            filter: blur(80px);
            opacity: 0.15;
            animation: float 8s ease-in-out infinite;
        }

        .blob-1 {
            width: 500px; height: 500px;
            background: var(--azul-principal);
            top: -100px; left: -100px;
            animation-delay: 0s;
        }

        .blob-2 {
            width: 400px; height: 400px;
            background: var(--roxo);
            bottom: -100px; right: -100px;
            animation-delay: 3s;
        }

        .blob-3 {
            width: 300px; height: 300px;
            background: var(--azul-claro);
            top: 50%; left: 50%;
            transform: translate(-50%, -50%);
            animation-delay: 1.5s;
        }

        @keyframes float {
            0%, 100% { transform: translate(0, 0) scale(1); }
            33% { transform: translate(30px, -30px) scale(1.05); }
            66% { transform: translate(-20px, 20px) scale(0.95); }
        }

        /* Grid pattern */
        .bg-grid {
            position: fixed;
            inset: 0;
            background-image: linear-gradient(rgba(255,255,255,0.03) 1px, transparent 1px),
                              linear-gradient(90deg, rgba(255,255,255,0.03) 1px, transparent 1px);
            background-size: 40px 40px;
            z-index: 0;
        }

        .login-wrapper {
            position: relative;
            z-index: 1;
            width: 100%;
            max-width: 440px;
            padding: 20px;
        }

        .login-card {
            background: rgba(30, 33, 48, 0.85);
            backdrop-filter: blur(20px);
            border: 1px solid var(--border);
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 25px 60px rgba(0,0,0,0.5);
        }

        .login-logo {
            text-align: center;
            margin-bottom: 32px;
        }

        .logo-icon {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, var(--azul-principal), var(--roxo));
            border-radius: 16px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            font-weight: 800;
            color: white;
            letter-spacing: -1px;
            margin-bottom: 16px;
            box-shadow: 0 8px 24px rgba(37,99,235,0.4);
        }

        .login-title {
            font-size: 24px;
            font-weight: 800;
            color: var(--text);
            margin-bottom: 4px;
        }

        .login-subtitle {
            font-size: 14px;
            color: var(--text-muted);
        }

        .form-group { margin-bottom: 18px; }

        .form-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #94A3B8;
            margin-bottom: 8px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-icon {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-muted);
            font-size: 16px;
            pointer-events: none;
        }

        .form-input {
            width: 100%;
            background: rgba(255,255,255,0.05);
            border: 1px solid var(--border);
            border-radius: 10px;
            color: var(--text);
            font-size: 14px;
            padding: 12px 14px 12px 42px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s;
            outline: none;
        }

        .form-input:focus {
            border-color: var(--azul-principal);
            background: rgba(37,99,235,0.05);
            box-shadow: 0 0 0 3px rgba(37,99,235,0.15);
        }

        .form-input::placeholder { color: var(--text-muted); }

        .toggle-senha {
            position: absolute;
            right: 14px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--text-muted);
            cursor: pointer;
            font-size: 16px;
            padding: 0;
            transition: color 0.2s;
        }

        .toggle-senha:hover { color: var(--text); }

        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #94A3B8;
            cursor: pointer;
        }

        .remember-me input[type="checkbox"] {
            width: 16px; height: 16px;
            accent-color: var(--azul-principal);
            cursor: pointer;
        }

        .forgot-link {
            font-size: 13px;
            color: var(--azul-claro);
            text-decoration: none;
            transition: color 0.2s;
        }

        .forgot-link:hover { color: var(--roxo-claro); }

        .btn-login {
            width: 100%;
            background: linear-gradient(135deg, var(--azul-principal), var(--roxo-claro));
            border: none;
            border-radius: 10px;
            color: white;
            font-size: 15px;
            font-weight: 700;
            padding: 13px;
            cursor: pointer;
            transition: all 0.3s;
            font-family: 'Inter', sans-serif;
            box-shadow: 0 4px 16px rgba(37,99,235,0.35);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(37,99,235,0.5);
        }

        .btn-login:active { transform: translateY(0); }

        .alert-msg {
            padding: 12px 16px;
            border-radius: 10px;
            font-size: 13.5px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .alert-error { background: rgba(239,68,68,0.15); color: #FCA5A5; border: 1px solid rgba(239,68,68,0.2); }
        .alert-success { background: rgba(16,185,129,0.15); color: #6EE7B7; border: 1px solid rgba(16,185,129,0.2); }

        .login-footer {
            text-align: center;
            margin-top: 24px;
            font-size: 12px;
            color: var(--text-muted);
        }

        /* Modal recuperação */
        .modal-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.7);
            z-index: 1000;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(4px);
        }

        .modal-overlay.show { display: flex; }

        .modal-box {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 32px;
            width: 100%;
            max-width: 380px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        }

        .modal-box h3 { font-size: 18px; font-weight: 700; color: var(--text); margin-bottom: 8px; }
        .modal-box p { font-size: 13px; color: var(--text-muted); margin-bottom: 20px; }

        .btn-modal {
            width: 100%;
            background: linear-gradient(135deg, var(--azul-principal), var(--azul-claro));
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 14px;
            font-weight: 600;
            padding: 11px;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
            margin-top: 12px;
        }

        .btn-cancel {
            width: 100%;
            background: transparent;
            border: 1px solid var(--border);
            border-radius: 8px;
            color: #94A3B8;
            font-size: 14px;
            font-weight: 600;
            padding: 11px;
            cursor: pointer;
            font-family: 'Inter', sans-serif;
            margin-top: 8px;
        }

        /* Responsividade Login */
        @media (max-width: 480px) {
            .login-wrapper {
                padding: 16px;
            }

            .login-card {
                padding: 32px 24px;
            }

            .logo-icon {
                width: 56px;
                height: 56px;
                font-size: 18px;
                margin-bottom: 12px;
            }

            .login-title {
                font-size: 20px;
            }

            .login-subtitle {
                font-size: 13px;
            }

            .form-input {
                padding: 12px 12px 12px 38px;
                font-size: 14px;
            }

            .input-icon {
                left: 12px;
                font-size: 14px;
            }

            .toggle-senha {
                right: 12px;
                font-size: 14px;
            }

            .btn-login {
                padding: 12px;
                font-size: 14px;
            }

            .modal-box {
                padding: 24px 20px;
                margin: 16px;
            }
        }

        @media (max-width: 360px) {
            .login-card {
                padding: 24px 16px;
            }

            .form-label {
                font-size: 12px;
            }

            .remember-me {
                font-size: 12px;
            }

            .forgot-link {
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="bg-animated">
        <div class="bg-blob blob-1"></div>
        <div class="bg-blob blob-2"></div>
        <div class="bg-blob blob-3"></div>
    </div>
    <div class="bg-grid"></div>

    <div class="login-wrapper">
        <div class="login-card">
            <div class="login-logo">
                <div class="logo-icon">M³</div>
                <h1 class="login-title">Os Três M</h1>
                <p class="login-subtitle">Sistema Empresarial — Acesso Seguro</p>
            </div>

            <?php if ($erro): ?>
                <div class="alert-msg alert-error">
                    <i class="bi bi-exclamation-circle-fill"></i>
                    <?= htmlspecialchars($erro) ?>
                </div>
            <?php endif; ?>

            <?php if ($sucesso): ?>
                <div class="alert-msg alert-success">
                    <i class="bi bi-check-circle-fill"></i>
                    <?= htmlspecialchars($sucesso) ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" id="loginForm">
                <div class="form-group">
                    <label class="form-label">E-mail</label>
                    <div class="input-wrapper">
                        <i class="bi bi-envelope-fill input-icon"></i>
                        <input type="email" name="email" class="form-input"
                               placeholder="seu@email.com"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                               required autocomplete="email">
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Senha</label>
                    <div class="input-wrapper">
                        <i class="bi bi-lock-fill input-icon"></i>
                        <input type="password" name="senha" id="senhaInput" class="form-input"
                               placeholder="••••••••"
                               required autocomplete="current-password">
                        <button type="button" class="toggle-senha" onclick="toggleSenha()">
                            <i class="bi bi-eye-fill" id="senhaIcon"></i>
                        </button>
                    </div>
                </div>

                <div class="form-options">
                    <label class="remember-me">
                        <input type="checkbox" name="lembrar">
                        Lembrar-me
                    </label>
                    <a href="#" class="forgot-link" onclick="abrirRecuperacao()">Esqueci a senha</a>
                </div>

                <button type="submit" class="btn-login" id="btnLogin">
                    <i class="bi bi-box-arrow-in-right"></i>
                    Entrar no Sistema
                </button>
            </form>

            <div class="login-footer">
                <p>© 2025 Os Três M — Todos os direitos reservados</p>
            </div>
        </div>
    </div>

    <!-- Modal Recuperação de Senha -->
    <div class="modal-overlay" id="modalRecuperacao">
        <div class="modal-box">
            <h3><i class="bi bi-key-fill" style="color:#3B82F6"></i> Recuperar Senha</h3>
            <p>Informe seu e-mail cadastrado. Você receberá as instruções para redefinir sua senha.</p>
            <div class="input-wrapper" style="margin-bottom:0">
                <i class="bi bi-envelope-fill input-icon"></i>
                <input type="email" id="emailRecuperacao" class="form-input" placeholder="seu@email.com">
            </div>
            <button class="btn-modal" onclick="enviarRecuperacao()">
                <i class="bi bi-send"></i> Enviar Instruções
            </button>
            <button class="btn-cancel" onclick="fecharRecuperacao()">Cancelar</button>
        </div>
    </div>

    <script>
        function toggleSenha() {
            const input = document.getElementById('senhaInput');
            const icon = document.getElementById('senhaIcon');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'bi bi-eye-slash-fill';
            } else {
                input.type = 'password';
                icon.className = 'bi bi-eye-fill';
            }
        }

        function abrirRecuperacao() {
            document.getElementById('modalRecuperacao').classList.add('show');
        }

        function fecharRecuperacao() {
            document.getElementById('modalRecuperacao').classList.remove('show');
        }

        function enviarRecuperacao() {
            const email = document.getElementById('emailRecuperacao').value;
            if (!email) { alert('Informe o e-mail.'); return; }
            fetch('api/recuperar_senha.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({email})
            })
            .then(r => r.json())
            .then(d => {
                alert(d.mensagem || 'Instruções enviadas!');
                fecharRecuperacao();
            });
        }

        // Loading no submit
        document.getElementById('loginForm').addEventListener('submit', function() {
            const btn = document.getElementById('btnLogin');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Entrando...';
            btn.disabled = true;
        });

        // Fechar modal clicando fora
        document.getElementById('modalRecuperacao').addEventListener('click', function(e) {
            if (e.target === this) fecharRecuperacao();
        });
    </script>
</body>
</html>
