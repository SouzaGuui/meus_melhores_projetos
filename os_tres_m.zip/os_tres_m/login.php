<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (empty($email) || empty($senha)) {
        $erro = 'Preencha todos os campos.';
    } elseif (!validarEmail($email)) {
        $erro = 'E-mail inválido.';
    } else {
        $pdo = db();
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ? AND status = 'ativo' LIMIT 1");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch();

        if ($usuario && verificarSenha($senha, $usuario['senha'])) {
            setSession($usuario);
            atualizarOnline($usuario['id'], 1);
            registrarLog('login', 'Login realizado com sucesso', $usuario['id']);
            header('Location: ' . BASE_URL . 'dashboard.php');
            exit;
        } else {
            $erro = 'E-mail ou senha incorretos.';
            registrarLog('login_falha', 'Tentativa de login falhou para: ' . $email);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Login | Os Três M</title>
    <?php include __DIR__ . '/includes/favicon.php'; ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/login-page.css" rel="stylesheet">
    <link href="<?= BASE_URL ?>assets/css/responsive.css" rel="stylesheet">
</head>
<body class="login-page">
<div class="login-shell">
    <aside class="login-brand">
        <div class="brand-top">
            <div class="brand-badge"><i class="bi bi-building-gear"></i> Os Três M</div>
            <img src="<?= BASE_URL ?>assets/img/logo.svg" alt="Os Três M" class="brand-logo-box" width="56" height="56">
            <h1>Gestão Empresarial</h1>
            <p>Ponto, folha de pagamento, tarefas e comunicação em um só lugar.</p>
        </div>
        <div class="brand-features">
            <div class="brand-feature"><i class="bi bi-clock-fill"></i> Controle de Ponto Inteligente</div>
            <div class="brand-feature"><i class="bi bi-cash-stack"></i> Folha de Pagamento</div>
            <div class="brand-feature"><i class="bi bi-people-fill"></i> Gestão por Cargos</div>
            <div class="brand-feature"><i class="bi bi-chat-dots-fill"></i> Chat Interno</div>
        </div>
    </aside>
    <main class="login-form-panel">
        <h2>Bem-vindo de volta</h2>
        <p class="sub">Acesse sua conta para continuar</p>

        <?php if ($erro): ?>
        <div class="alert-login error"><i class="bi bi-exclamation-circle-fill"></i> <?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>
        <?php if ($sucesso): ?>
        <div class="alert-login success"><i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($sucesso) ?></div>
        <?php endif; ?>

        <form method="POST" id="loginForm">
            <div class="form-field">
                <label for="email">E-mail</label>
                <div class="input-box">
                    <i class="bi bi-envelope-fill icon-left"></i>
                    <input type="email" id="email" name="email" placeholder="seu@email.com"
                           value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required autocomplete="email">
                </div>
            </div>
            <div class="form-field">
                <label for="senhaInput">Senha</label>
                <div class="input-box">
                    <i class="bi bi-lock-fill icon-left"></i>
                    <input type="password" name="senha" id="senhaInput" placeholder="Digite sua senha" required autocomplete="current-password">
                    <button type="button" class="toggle-pw" onclick="toggleSenha()" aria-label="Mostrar senha">
                        <i class="bi bi-eye-fill" id="senhaIcon"></i>
                    </button>
                </div>
            </div>
            <div class="form-row">
                <label><input type="checkbox" name="lembrar"> Lembrar acesso</label>
                <a href="#" onclick="abrirRecuperacao();return false;">Esqueci a senha</a>
            </div>
            <button type="submit" class="btn-entrar" id="btnLogin">
                <i class="bi bi-box-arrow-in-right"></i> Entrar
            </button>
        </form>

        <div class="demo-box">
            <strong>Credenciais de demonstração</strong>
            <div class="demo-table-wrap">
                <table class="demo-table">
                    <thead>
                        <tr>
                            <th>Usuário</th>
                            <th>E-mail</th>
                            <th>Senha</th>
                            <th>Perfil</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Administrador</td>
                            <td><button type="button" class="demo-fill" data-email="admin@ostresm.com" data-senha="Admin@123">admin@ostresm.com</button></td>
                            <td>Admin@123</td>
                            <td>Admin</td>
                        </tr>
                        <tr>
                            <td>RH</td>
                            <td><button type="button" class="demo-fill" data-email="rh@ostresm.com" data-senha="Rh@123456">rh@ostresm.com</button></td>
                            <td>Rh@123456</td>
                            <td>RH</td>
                        </tr>
                        <tr>
                            <td>Gerente</td>
                            <td><button type="button" class="demo-fill" data-email="gerente@ostresm.com" data-senha="Gerente@123">gerente@ostresm.com</button></td>
                            <td>Gerente@123</td>
                            <td>Gerente</td>
                        </tr>
                        <tr>
                            <td>Coordenação</td>
                            <td><button type="button" class="demo-fill" data-email="coordenacao@ostresm.com" data-senha="Coord@123456">coordenacao@ostresm.com</button></td>
                            <td>Coord@123456</td>
                            <td>Coordenação</td>
                        </tr>
                        <tr>
                            <td>Funcionário</td>
                            <td><button type="button" class="demo-fill" data-email="funcionario@ostresm.com" data-senha="Funcionario@123">funcionario@ostresm.com</button></td>
                            <td>Funcionario@123</td>
                            <td>Funcionário</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <p class="demo-hint">Clique no e-mail para preencher o formulário automaticamente.</p>
        </div>
        <p class="login-foot">© 2025 Os Três M — Todos os direitos reservados</p>
    </main>
</div>

<div class="modal-overlay" id="modalRecuperacao">
    <div class="modal-box">
        <h3 style="font-size:18px;font-weight:700;margin-bottom:8px">Recuperar senha</h3>
        <p style="font-size:13px;color:#64748b;margin-bottom:16px">Informe seu e-mail cadastrado.</p>
        <div class="input-box" style="margin-bottom:12px">
            <i class="bi bi-envelope-fill icon-left"></i>
            <input type="email" id="emailRecuperacao" placeholder="seu@email.com" style="width:100%;padding:13px 13px 13px 42px;border:1.5px solid #e2e8f0;border-radius:10px">
        </div>
        <button type="button" class="btn-entrar" onclick="enviarRecuperacao()">Enviar instruções</button>
        <button type="button" class="btn btn-outline w-100 mt-2" onclick="fecharRecuperacao()">Cancelar</button>
    </div>
</div>

<script>
function toggleSenha() {
    const input = document.getElementById('senhaInput');
    const icon = document.getElementById('senhaIcon');
    input.type = input.type === 'password' ? 'text' : 'password';
    icon.className = input.type === 'password' ? 'bi bi-eye-fill' : 'bi bi-eye-slash-fill';
}
function abrirRecuperacao() { document.getElementById('modalRecuperacao').classList.add('show'); }
function fecharRecuperacao() { document.getElementById('modalRecuperacao').classList.remove('show'); }
function enviarRecuperacao() {
    const email = document.getElementById('emailRecuperacao').value;
    if (!email) { alert('Informe o e-mail.'); return; }
    fetch('<?= BASE_URL ?>api/recuperar_senha.php', {
        method: 'POST', credentials: 'same-origin',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email})
    }).then(r => r.json()).then(d => { alert(d.mensagem || 'Verifique seu e-mail.'); fecharRecuperacao(); });
}
document.getElementById('loginForm').addEventListener('submit', function() {
    const btn = document.getElementById('btnLogin');
    btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Entrando...';
    btn.disabled = true;
});
document.getElementById('modalRecuperacao').addEventListener('click', function(e) {
    if (e.target === this) fecharRecuperacao();
});
document.querySelectorAll('.demo-fill').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.getElementById('email').value = this.dataset.email || '';
        document.getElementById('senhaInput').value = this.dataset.senha || '';
        document.getElementById('email').focus();
    });
});
</script>
</body>
</html>
