<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Acesso Negado';
$breadcrumb = 'Acesso Negado';
$user = currentUser();
include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content d-flex align-items-center justify-content-center" style="min-height:60vh">
            <div class="card text-center fade-in" style="max-width:480px;padding:48px 32px">
                <div style="width:80px;height:80px;border-radius:50%;background:rgba(239,68,68,0.12);display:inline-flex;align-items:center;justify-content:center;margin-bottom:24px">
                    <i class="bi bi-shield-lock-fill" style="font-size:36px;color:var(--vermelho)"></i>
                </div>
                <h2 style="font-size:22px;font-weight:800;margin-bottom:8px;color:var(--text-primary)">Acesso Negado</h2>
                <p style="color:var(--text-muted);font-size:14px;margin-bottom:24px">
                    Seu perfil <strong><?= htmlspecialchars(nivelLabel($user['nivel_acesso'])) ?></strong> não tem permissão para acessar esta área.
                </p>
                <div class="d-flex gap-2 justify-content-center flex-wrap">
                    <a href="<?= BASE_URL ?>dashboard.php" class="btn btn-primary">
                        <i class="bi bi-grid-1x2-fill"></i> Ir ao Dashboard
                    </a>
                    <a href="javascript:history.back()" class="btn btn-outline">
                        <i class="bi bi-arrow-left"></i> Voltar
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'includes/footer.php'; ?>
