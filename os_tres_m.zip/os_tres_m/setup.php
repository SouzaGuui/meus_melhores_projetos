<?php
/**
 * ============================================
 * Os Tres M - Script de Configuracao Inicial
 * Acesse: http://localhost/os_tres_m/setup.php
 * APAGUE este arquivo apos a configuracao!
 * ============================================
 */

// Seguranca basica: so rodar localmente
if (!in_array($_SERVER['REMOTE_ADDR'], ['127.0.0.1', '::1', 'localhost'])) {
    http_response_code(403);
    die('Acesso negado. Este script so pode ser executado localmente.');
}

require_once 'config/database.php';
require_once 'config/functions.php';

$mensagens = [];
$erros     = [];

try {
    $pdo = db();

    // 1. Verificar se o banco existe
    $tabelas = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $mensagens[] = "Conexao com banco de dados OK";
    $mensagens[] = "Tabelas encontradas: " . implode(', ', $tabelas);

    // 2. Criar/atualizar usuarios padrao
    $usuariosPadrao = [
        'admin@ostresm.com' => [
            'senha' => 'Admin@123',
            'nome' => 'Administrador',
            'cpf' => '000.000.000-00',
            'cargo' => 'Administrador',
            'setor' => 'Administracao',
            'nivel_acesso' => 'admin',
        ],
        'rh@ostresm.com' => [
            'senha' => 'Rh@123456',
            'nome' => 'Recursos Humanos',
            'cpf' => '111.111.111-11',
            'cargo' => 'Analista RH',
            'setor' => 'RH',
            'nivel_acesso' => 'rh',
        ],
        'gerente@ostresm.com' => [
            'senha' => 'Gerente@123',
            'nome' => 'Gerente Operacional',
            'cpf' => '222.222.222-22',
            'cargo' => 'Gerente',
            'setor' => 'Operações',
            'nivel_acesso' => 'gerente',
        ],
        'coordenacao@ostresm.com' => [
            'senha' => 'Coord@123456',
            'nome' => 'Coordenação Geral',
            'cpf' => '333.333.333-33',
            'cargo' => 'Coordenador',
            'setor' => 'Operações',
            'nivel_acesso' => 'coordenacao',
        ],
        'funcionario@ostresm.com' => [
            'senha' => 'Funcionario@123',
            'nome' => 'Funcionário',
            'cpf' => '444.444.444-44',
            'cargo' => 'Analista',
            'setor' => 'Operações',
            'nivel_acesso' => 'funcionario',
        ],
    ];

    $buscarUsuario = $pdo->prepare("SELECT id FROM usuarios WHERE email = ? LIMIT 1");
    $atualizarUsuario = $pdo->prepare("
        UPDATE usuarios
        SET nome = ?, senha = ?, cargo = ?, setor = ?, nivel_acesso = ?, status = 'ativo'
        WHERE email = ?
    ");
    $criarUsuario = $pdo->prepare("
        INSERT INTO usuarios (nome, email, senha, cpf, cargo, setor, nivel_acesso, status, data_contratacao)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'ativo', CURDATE())
    ");

    foreach ($usuariosPadrao as $email => $dados) {
        $hash = hashSenha($dados['senha']);
        $buscarUsuario->execute([$email]);

        if ($buscarUsuario->fetchColumn()) {
            $atualizarUsuario->execute([
                $dados['nome'],
                $hash,
                $dados['cargo'],
                $dados['setor'],
                $dados['nivel_acesso'],
                $email,
            ]);
            $mensagens[] = "Usuario atualizado: $email (senha: {$dados['senha']})";
        } else {
            $criarUsuario->execute([
                $dados['nome'],
                $email,
                $hash,
                $dados['cpf'],
                $dados['cargo'],
                $dados['setor'],
                $dados['nivel_acesso'],
            ]);
            $mensagens[] = "Usuario criado: $email (senha: {$dados['senha']})";
        }
    }

    // 3. Criar pasta de uploads
    $dirs = [
        __DIR__ . '/uploads',
        __DIR__ . '/uploads/perfil',
    ];
    foreach ($dirs as $dir) {
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
            $mensagens[] = "Pasta criada: $dir";
        } else {
            $mensagens[] = "Pasta ja existe: $dir";
        }
    }

    // 4. Verificar permissoes de escrita
    if (is_writable(__DIR__ . '/uploads/perfil')) {
        $mensagens[] = "Pasta uploads/perfil com permissao de escrita";
    } else {
        $erros[] = "Pasta uploads/perfil sem permissao de escrita";
    }

    $mensagens[] = "Setup concluido com sucesso!";
} catch (Exception $e) {
    $erros[] = "Erro: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>Setup | Os Três M</title>
<?php include __DIR__ . '/includes/favicon.php'; ?>
<style>
  body { font-family: Arial, sans-serif; background: #0F1117; color: #F1F5F9; padding: 40px 20px; }
  .container { max-width: 700px; margin: 0 auto; }
  h1 { font-size: 24px; margin-bottom: 8px; color: #3B82F6; }
  p.sub { color: #64748B; margin-bottom: 24px; font-size: 14px; }
  .card { background: #1E2130; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 24px; margin-bottom: 16px; }
  .msg { padding: 8px 12px; border-radius: 8px; margin-bottom: 8px; font-size: 14px; }
  .msg.ok { background: rgba(16,185,129,0.1); color: #6EE7B7; }
  .msg.err { background: rgba(239,68,68,0.1); color: #FCA5A5; }
  .btn { display: inline-block; background: linear-gradient(135deg,#2563EB,#7C3AED); color: white; padding: 12px 24px; border-radius: 8px; text-decoration: none; font-weight: 700; margin-top: 16px; }
  .warn { background: rgba(245,158,11,0.1); border: 1px solid rgba(245,158,11,0.2); border-radius: 8px; padding: 12px 16px; color: #FCD34D; font-size: 13px; margin-top: 16px; }
  table { width: 100%; border-collapse: collapse; margin-top: 12px; }
  th, td { padding: 8px 12px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.06); font-size: 13px; }
  th { color: #64748B; font-size: 11px; text-transform: uppercase; }
</style>
</head>
<body>
<div class="container">
    <h1>Os Tres M - Setup</h1>
    <p class="sub">Configuracao inicial e reparo dos acessos administrativos</p>

    <div class="card">
        <h3 style="margin-bottom:16px;font-size:16px">Resultado da Configuracao</h3>
        <?php foreach ($mensagens as $m): ?>
        <div class="msg ok"><?= htmlspecialchars($m) ?></div>
        <?php endforeach; ?>
        <?php foreach ($erros as $e): ?>
        <div class="msg err"><?= htmlspecialchars($e) ?></div>
        <?php endforeach; ?>
    </div>

    <?php if (empty($erros)): ?>
    <div class="card">
        <h3 style="margin-bottom:16px;font-size:16px">Credenciais de Acesso</h3>
        <table>
            <thead><tr><th>Usuario</th><th>E-mail</th><th>Senha</th><th>Nivel</th></tr></thead>
            <tbody>
                <tr><td>Administrador</td><td>admin@ostresm.com</td><td><code style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px">Admin@123</code></td><td>Admin</td></tr>
                <tr><td>RH</td><td>rh@ostresm.com</td><td><code style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px">Rh@123456</code></td><td>RH</td></tr>
                <tr><td>Gerente</td><td>gerente@ostresm.com</td><td><code style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px">Gerente@123</code></td><td>Gerente</td></tr>
                <tr><td>Coordenação</td><td>coordenacao@ostresm.com</td><td><code style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px">Coord@123456</code></td><td>Coordenação</td></tr>
                <tr><td>Funcionário</td><td>funcionario@ostresm.com</td><td><code style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px">Funcionario@123</code></td><td>Funcionário</td></tr>
            </tbody>
        </table>
        <a href="login.php" class="btn">Acessar o Sistema</a>
    </div>
    <?php endif; ?>

    <div class="warn">
        <strong>IMPORTANTE:</strong> Apague ou renomeie este arquivo apos a configuracao.
        <br>Este arquivo nao deve existir em producao.
        <br><br>
        <strong>Caminho:</strong> <code style="background:rgba(255,255,255,0.1);padding:2px 6px;border-radius:4px"><?= __FILE__ ?></code>
    </div>
</div>
</body>
</html>
