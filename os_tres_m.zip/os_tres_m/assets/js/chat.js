/**
 * Os Três M — Chat interno (polling, envio único, sem duplicação)
 */
(function () {
    'use strict';
    if (window.__CHAT_INITIALIZED__) return;
    window.__CHAT_INITIALIZED__ = true;

    const cfg = window.CHAT_CONFIG || {};
    const baseUrl = cfg.baseUrl || '';
    const conversaId = parseInt(cfg.conversaId, 10) || 0;
    const userId = parseInt(cfg.userId, 10) || 0;

    let ultimaMensagemId = parseInt(cfg.ultimaMensagemId, 10) || 0;
    let enviando = false;
    let pollTimer = null;
    let pollEmAndamento = false;
    let listaEmAndamento = false;
    const idsConhecidos = new Set();

    function escapeHtml(text) {
        const d = document.createElement('div');
        d.textContent = text;
        return d.innerHTML;
    }

    function scrollBottom(smooth) {
        const el = document.getElementById('chatMensagens');
        if (!el) return;
        el.scrollTo({ top: el.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
    }

    function statusIcon(m, isMeu) {
        if (!isMeu) return '';
        if (m.status === 'lida' || m.lida === 1 || m.lida === true) {
            return '<i class="bi bi-check-all msg-status lida" title="Visualizada"></i>';
        }
        if (m.status === 'enviada') {
            return '<i class="bi bi-check msg-status" title="Enviada"></i>';
        }
        if (m.status === 'recebida') {
            return '<i class="bi bi-check-all msg-status" title="Entregue"></i>';
        }
        return '<i class="bi bi-clock msg-status pendente" title="Enviando..."></i>';
    }

    function renderBubble(m, isMeu) {
        const div = document.createElement('div');
        div.className = 'chat-msg-row ' + (isMeu ? 'mine' : 'theirs');
        div.dataset.id = String(m.id || '');

        const avatar = !isMeu && m.remetente_nome
            ? `<div class="chat-msg-avatar">${escapeHtml(m.remetente_nome.substring(0, 2).toUpperCase())}</div>`
            : '';

        div.innerHTML = `
            ${avatar}
            <div class="chat-msg-bubble-wrap">
                <div class="chat-msg-bubble">${escapeHtml(m.mensagem).replace(/\n/g, '<br>')}</div>
                <div class="chat-msg-meta">
                    <span>${m.hora || ''}</span>
                    ${isMeu ? statusIcon(m, true) : ''}
                </div>
            </div>
        `;
        return div;
    }

    function registrarId(id) {
        if (!id) return;
        idsConhecidos.add(String(id));
    }

    function mensagemJaExiste(id) {
        if (!id) return false;
        const sid = String(id);
        if (idsConhecidos.has(sid)) return true;
        const container = document.getElementById('chatMensagens');
        return !!(container && container.querySelector(`[data-id="${sid}"]`));
    }

    function adicionarMensagem(m, isMeu) {
        const container = document.getElementById('chatMensagens');
        if (!container || !m.id) return false;

        if (mensagemJaExiste(m.id)) return false;

        const empty = container.querySelector('.chat-empty-state');
        if (empty) empty.remove();

        container.appendChild(renderBubble(m, isMeu));
        registrarId(m.id);
        scrollBottom(true);
        return true;
    }

    function atualizarMensagemExistente(id, dados) {
        const row = document.querySelector(`[data-id="${id}"]`);
        if (!row) return;
        if (dados.mensagem) {
            const bubble = row.querySelector('.chat-msg-bubble');
            if (bubble) bubble.innerHTML = escapeHtml(dados.mensagem).replace(/\n/g, '<br>');
        }
        if (dados.hora || dados.status !== undefined || dados.lida !== undefined) {
            const meta = row.querySelector('.chat-msg-meta');
            if (meta) {
                const hora = dados.hora || meta.querySelector('span')?.textContent || '';
                meta.innerHTML = `<span>${hora}</span>${statusIcon(dados, true)}`;
            }
        }
    }

    function confirmarEnvio(tempId, msg) {
        const row = document.querySelector(`[data-id="${tempId}"]`);
        if (!row) {
            adicionarMensagem(msg, true);
            return;
        }
        const oldId = String(tempId);
        idsConhecidos.delete(oldId);
        row.dataset.id = String(msg.id);
        registrarId(msg.id);
        atualizarMensagemExistente(msg.id, {
            mensagem: msg.mensagem,
            hora: msg.hora,
            status: 'enviada',
            lida: 0,
        });
        ultimaMensagemId = Math.max(ultimaMensagemId, parseInt(msg.id, 10) || 0);
    }

    async function apiFetch(url, options) {
        const res = await fetch(baseUrl + url, {
            credentials: 'same-origin',
            ...options,
        });
        const text = await res.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            throw new Error('Resposta inválida do servidor.');
        }
        if (!res.ok && data.erro) throw new Error(data.erro);
        return data;
    }

    async function enviarMensagemApi(texto) {
        const data = await apiFetch('api/chat_enviar.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ conversa_id: conversaId, mensagem: texto }),
        });
        if (data.sucesso && data.mensagem) return data.mensagem;
        throw new Error(data.erro || 'Falha ao enviar.');
    }

    function processarNovasMensagens(mensagens) {
        if (!mensagens || !mensagens.length) return;
        mensagens.forEach((m) => {
            const isMeu = m.remetente_id === userId;
            const mid = parseInt(m.id, 10) || 0;
            ultimaMensagemId = Math.max(ultimaMensagemId, mid);

            if (isMeu) {
                if (mensagemJaExiste(m.id)) {
                    atualizarMensagemExistente(m.id, m);
                }
                return;
            }
            adicionarMensagem(m, false);
        });
    }

    function processarStatusLeitura(atualizacoes) {
        if (!atualizacoes || !atualizacoes.length) return;
        atualizacoes.forEach((s) => {
            atualizarMensagemExistente(s.id, { status: 'lida', lida: 1 });
        });
    }

    async function pollNovas() {
        if (!conversaId || pollEmAndamento) return;
        pollEmAndamento = true;
        try {
            const d = await apiFetch(
                `api/chat_novas.php?conversa_id=${conversaId}&ultima_id=${ultimaMensagemId}`
            );
            processarNovasMensagens(d.mensagens);
            processarStatusLeitura(d.status_lidas);
        } catch (e) { /* silencioso */ }
        finally {
            pollEmAndamento = false;
        }
    }

    function iniciarPolling() {
        if (!conversaId) return;
        if (pollTimer) clearInterval(pollTimer);
        pollTimer = setInterval(pollNovas, 2500);
        pollNovas();
    }

    function pararPolling() {
        if (pollTimer) {
            clearInterval(pollTimer);
            pollTimer = null;
        }
    }

    async function atualizarListaConversas() {
        const el = document.getElementById('listaConversas');
        if (!el || listaEmAndamento) return;
        listaEmAndamento = true;
        try {
            const d = await apiFetch('api/chat_conversas.php');
            if (!d.conversas) return;
            const q = (document.getElementById('buscaConversa')?.value || '').toLowerCase();
            el.innerHTML = d.conversas.length ? d.conversas.map((c) => {
                const active = c.id === conversaId ? ' active' : '';
                const nome = escapeHtml(c.outro_nome.split(' ')[0]);
                const ini = escapeHtml(c.outro_nome.substring(0, 2).toUpperCase());
                const badge = c.nao_lidas > 0 ? `<span class="chat-unread">${c.nao_lidas}</span>` : '';
                const foto = c.outro_foto
                    ? `<img src="${escapeHtml(c.outro_foto)}" alt="">`
                    : ini;
                return `<a href="${baseUrl}chat.php?conversa=${c.id}" class="chat-item${active}" data-nome="${nome.toLowerCase()}">
                    <div class="chat-item-avatar"><span>${foto}</span><i class="online-dot ${c.outro_online ? 'on' : ''}"></i></div>
                    <div class="chat-item-body">
                        <div class="chat-item-top"><strong>${nome}</strong><span>${c.hora}</span></div>
                        <div class="chat-item-preview">${escapeHtml(c.ultima_mensagem || 'Iniciar conversa')}${badge}</div>
                    </div>
                </a>`;
            }).join('') : `<div class="chat-empty-side"><i class="bi bi-chat-dots"></i><p>Nenhuma conversa</p></div>`;
            if (q) {
                el.querySelectorAll('.chat-item').forEach((item) => {
                    item.style.display = item.textContent.toLowerCase().includes(q) ? '' : 'none';
                });
            }
        } catch (e) { /* ignore */ }
        finally {
            listaEmAndamento = false;
        }
    }

    const form = document.getElementById('formMensagem');
    const input = document.getElementById('inputMensagem');
    const btnSend = document.getElementById('btnEnviarMsg');

    if (form && input) {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();
            e.stopImmediatePropagation();

            const msg = input.value.trim();
            if (!msg || !conversaId || enviando) return;

            enviando = true;
            if (btnSend) btnSend.disabled = true;

            const tempId = 'temp-' + Date.now();
            adicionarMensagem({
                id: tempId,
                mensagem: msg,
                hora: '...',
                status: 'pendente',
            }, true);
            input.value = '';
            input.style.height = 'auto';

            try {
                const resposta = await enviarMensagemApi(msg);
                confirmarEnvio(tempId, resposta);
            } catch (err) {
                document.querySelector(`[data-id="${tempId}"]`)?.remove();
                idsConhecidos.delete(tempId);
                input.value = msg;
                alert(err.message || 'Erro ao enviar mensagem.');
            } finally {
                enviando = false;
                if (btnSend) btnSend.disabled = false;
                input.focus();
            }
        }, true);

        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                if (!enviando) form.requestSubmit();
            }
        });

        input.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 120) + 'px';
        });
    }

    document.getElementById('buscaConversa')?.addEventListener('input', function () {
        const q = this.value.toLowerCase();
        document.querySelectorAll('.chat-item').forEach((el) => {
            el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });

    document.getElementById('buscaUsuario')?.addEventListener('input', function () {
        const q = this.value.toLowerCase();
        document.querySelectorAll('#listaUsuarios a').forEach((el) => {
            el.style.display = el.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });

    document.querySelectorAll('#chatMensagens [data-id]').forEach((row) => {
        registrarId(row.dataset.id);
    });

    scrollBottom(false);
    iniciarPolling();
    setInterval(atualizarListaConversas, 6000);
    atualizarListaConversas();

    window.addEventListener('beforeunload', pararPolling);
})();
