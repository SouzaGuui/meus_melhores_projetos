(function () {
    const cfg = window.CAL_CONFIG || {};
    const base = cfg.baseUrl || '';
    const el = document.getElementById('calendario');
    const painelEquipe = document.getElementById('painelEquipe');
    const painelCalendario = document.getElementById('painelCalendario');

    const modalEl = document.getElementById('modalEvento');
    const modal = modalEl ? new bootstrap.Modal(modalEl) : null;
    const modalDetalhe = document.getElementById('modalDetalhe');
    const modalDetalheBs = modalDetalhe ? new bootstrap.Modal(modalDetalhe) : null;
    const btnRemoverDetalhe = document.getElementById('btnRemoverEventoDetalhe');
    let eventoDetalheAtual = null;

    async function api(url, opts) {
        const r = await fetch(base + url, { credentials: 'same-origin', ...opts });
        const data = await r.json();
        if (data.erro) throw new Error(data.erro);
        return data;
    }

    function filtrosQuery() {
        const s = document.getElementById('filtroSetor');
        const u = document.getElementById('filtroUsuario');
        const busca = document.getElementById('filtroBusca');
        let q = '';
        if (s && s.value) q += '&setor=' + encodeURIComponent(s.value);
        if (u && u.value) q += '&usuario_id=' + encodeURIComponent(u.value);
        if (busca && busca.value.trim()) q += '&busca=' + encodeURIComponent(busca.value.trim());
        return q;
    }

    function escapeHtml(t) {
        const d = document.createElement('div');
        d.textContent = t ?? '';
        return d.innerHTML;
    }

    function debounce(fn, ms) {
        let t;
        return function () {
            clearTimeout(t);
            t = setTimeout(fn, ms);
        };
    }

    // ——— Painéis Equipe / Calendário ———
    document.querySelectorAll('[data-cal-panel]').forEach((btn) => {
        btn.addEventListener('click', function () {
            const panel = this.dataset.calPanel;
            document.querySelectorAll('[data-cal-panel]').forEach((b) => {
                b.classList.toggle('active', b === this);
                b.classList.toggle('btn-primary', b === this);
                b.classList.toggle('btn-outline', b !== this);
            });
            if (panel === 'equipe') {
                painelEquipe?.classList.remove('d-none');
                painelCalendario?.classList.add('d-none');
                carregarEquipe();
            } else {
                painelEquipe?.classList.add('d-none');
                painelCalendario?.classList.remove('d-none');
                calendar?.updateSize();
            }
        });
    });

    // ——— Equipe ———
    async function carregarEquipe() {
        const grid = document.getElementById('equipeGrid');
        const contador = document.getElementById('equipeContador');
        if (!grid) return;
        const busca = document.getElementById('equipeBusca')?.value.trim() || '';
        try {
            const d = await api('api/calendario_equipe.php?busca=' + encodeURIComponent(busca));
            const membros = d.membros || [];
            if (contador) contador.textContent = membros.length + ' colaborador(es)';
            if (!membros.length) {
                grid.innerHTML = '<div class="col-12 text-center text-muted py-5">Nenhum membro encontrado.</div>';
                return;
            }
            grid.innerHTML = membros.map((m) => renderCardEquipe(m)).join('');
        } catch (e) {
            grid.innerHTML = '<div class="col-12 text-danger">' + escapeHtml(e.message) + '</div>';
        }
    }

    function renderCardEquipe(m) {
        const foto = m.foto
            ? `<img src="${escapeHtml(m.foto)}" alt="">`
            : `<span>${escapeHtml(m.inicial)}</span>`;
        const statusClass = {
            Presente: 'green',
            Atrasado: 'yellow',
            Falta: 'red',
            Ausente: 'muted',
        }[m.status_atual] || 'blue';

        return `<div class="col-12 col-md-6 col-xl-4">
            <div class="equipe-card fade-in">
                <div class="equipe-card-head">
                    <div class="equipe-avatar">${foto}</div>
                    <div class="equipe-info min-w-0">
                        <div class="equipe-nome">${escapeHtml(m.nome)}</div>
                        <div class="equipe-cargo">${escapeHtml(m.cargo)}</div>
                        <div class="equipe-setor">${escapeHtml(m.setor)}</div>
                        <span class="equipe-codigo">${escapeHtml(m.codigo)}</span>
                    </div>
                    <span class="equipe-status equipe-status-${statusClass}">${escapeHtml(m.status_atual)}</span>
                </div>
                <div class="equipe-stats">
                    <div class="equipe-stat green"><strong>${m.stats_hoje.corretos}</strong><span>Corretos</span></div>
                    <div class="equipe-stat yellow"><strong>${m.stats_hoje.irregulares}</strong><span>Irreg.</span></div>
                    <div class="equipe-stat red"><strong>${m.stats_hoje.faltas}</strong><span>Faltas</span></div>
                    <div class="equipe-stat blue"><strong>${m.stats_hoje.horas}h</strong><span>Horas</span></div>
                </div>
                <div class="equipe-freq">
                    <span>Frequência (30 dias)</span>
                    <strong style="color:${m.frequencia >= 80 ? 'var(--verde)' : 'var(--vermelho)'}">${m.frequencia}%</strong>
                </div>
                <div class="equipe-actions">
                    <a href="${base}calendario_funcionario.php?id=${m.id}&mes=${new Date().getMonth() + 1}&ano=${new Date().getFullYear()}" class="btn btn-primary btn-sm flex-fill">
                        <i class="bi bi-calendar3"></i> Ver Calendário
                    </a>
                    <a href="${base}relatorios.php?tipo=presenca" class="btn btn-outline btn-sm" title="Relatório"><i class="bi bi-file-text" style="color:var(--verde)"></i></a>
                    <a href="${cfg.chatUrl || base + 'chat.php'}" class="btn btn-outline btn-sm" title="Chat"><i class="bi bi-chat-dots"></i></a>
                </div>
            </div>
        </div>`;
    }

    document.getElementById('equipeBusca')?.addEventListener('input', debounce(carregarEquipe, 350));
    carregarEquipe();

    // ——— FullCalendar ———
    let calendar = null;
    if (el && typeof FullCalendar !== 'undefined') {
        calendar = new FullCalendar.Calendar(el, {
            locale: 'pt-br',
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek',
            },
            buttonText: { today: 'Hoje', month: 'Mês', week: 'Semana', day: 'Dia', list: 'Lista' },
            height: 'auto',
            navLinks: true,
            editable: false,
            dayMaxEvents: 3,
            moreLinkText: (n) => 'Ver mais (+' + n + ')',
            events: async (info, success, failure) => {
                try {
                    const d = await api(
                        'api/calendario.php?start=' + info.startStr.slice(0, 10) +
                        '&end=' + info.endStr.slice(0, 10) + filtrosQuery()
                    );
                    success(d.eventos || []);
                } catch (e) {
                    failure(e);
                }
            },
            eventClick: (arg) => {
                const p = arg.event.extendedProps || {};
                if (p.integrado || !cfg.podeGerenciar) {
                    mostrarDetalhe(arg.event);
                    return;
                }
                editarEvento(arg.event);
            },
            dateClick: (info) => {
                if (!cfg.podeGerenciar) return;
                novoEvento(info.dateStr);
            },
            moreLinkClick: (info) => {
                info.jsEvent.preventDefault();
                abrirModalVerMais(info.allSegs.map((s) => s.event), info.date);
            },
        });
        calendar.render();
    }

    function mostrarDetalhe(ev) {
        eventoDetalheAtual = ev;
        const p = ev.extendedProps || {};
        const titulo = document.getElementById('detalheTitulo');
        const corpo = document.getElementById('detalheCorpo');
        if (!titulo || !corpo) return;

        titulo.textContent = ev.title.replace(/^[^\s]+\s*/, '').trim() || ev.title;
        let html = '';
        if (p.tipo) html += `<p><strong>Tipo:</strong> ${escapeHtml(p.tipo)}</p>`;
        if (p.usuario_nome) html += `<p><strong>Responsável:</strong> ${escapeHtml(p.usuario_nome)}</p>`;
        if (p.status) html += `<p><strong>Status:</strong> ${escapeHtml(p.status)}</p>`;
        if (p.descricao) html += `<p>${escapeHtml(p.descricao)}</p>`;
        if (p.entrada !== undefined) {
            html += `<p><strong>Entrada:</strong> ${p.entrada || '—'} | <strong>Saída:</strong> ${p.saida || '—'}</p>`;
        }
        const uid = p.usuario_id;
        if (uid) {
            html += `<a href="${base}calendario_funcionario.php?id=${uid}" class="btn btn-outline btn-sm mt-2"><i class="bi bi-person-badge"></i> Calendário individual</a>`;
        }
        corpo.innerHTML = html || '<p class="text-muted">Sem detalhes.</p>';

        if (btnRemoverDetalhe) {
            const pode = cfg.podeRemover && (p.pode_remover !== false);
            btnRemoverDetalhe.classList.toggle('d-none', !pode);
        }
        modalDetalheBs?.show();
    }

    btnRemoverDetalhe?.addEventListener('click', async () => {
        if (!eventoDetalheAtual || !confirm('Remover este evento do calendário? Esta ação não pode ser desfeita.')) return;
        try {
            await api('api/calendario_remover.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: eventoDetalheAtual.id }),
            });
            modalDetalheBs?.hide();
            calendar?.refetchEvents();
            carregarStats();
            showToast?.('Evento removido.', 'success');
        } catch (err) {
            alert(err.message);
        }
    });

    const modalVerMais = document.getElementById('modalVerMais');
    const modalVerMaisBs = modalVerMais ? new bootstrap.Modal(modalVerMais) : null;
    let eventosVerMais = [];

    function abrirModalVerMais(eventos, data) {
        eventosVerMais = eventos || [];
        const titulo = document.getElementById('verMaisTitulo');
        if (titulo) {
            titulo.textContent = 'Eventos — ' + data.toLocaleDateString('pt-BR', {
                weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
            });
        }
        renderVerMaisLista();
        modalVerMaisBs?.show();
    }

    function renderVerMaisLista() {
        const lista = document.getElementById('verMaisLista');
        const busca = (document.getElementById('verMaisBusca')?.value || '').toLowerCase();
        const filtro = document.querySelector('#verMaisFiltros .active')?.dataset.filtro || 'todos';
        if (!lista) return;

        let items = [...eventosVerMais].sort((a, b) => (a.start || 0) - (b.start || 0));
        if (filtro !== 'todos') {
            items = items.filter((ev) => {
                const t = ev.extendedProps?.tipo || '';
                if (filtro === 'falta') return t === 'falta' || ev.title.includes('Falta');
                if (filtro === 'presenca') return t === 'presenca';
                return t === filtro;
            });
        }
        if (busca) items = items.filter((ev) => ev.title.toLowerCase().includes(busca));

        if (!items.length) {
            lista.innerHTML = '<p class="text-muted mb-0">Nenhum evento.</p>';
            return;
        }

        lista.innerHTML = items.map((ev) => {
            const p = ev.extendedProps || {};
            const cor = ev.backgroundColor || '#2563EB';
            const hora = ev.allDay ? 'Dia inteiro' : ev.start?.toLocaleTimeString?.('pt-BR', { hour: '2-digit', minute: '2-digit' }) || '';
            return `<div class="cal-ver-mais-item" style="border-left-color:${cor}">
                <strong>${escapeHtml(ev.title)}</strong>
                <div class="meta">${escapeHtml(p.tipo || '')} · ${hora}${p.usuario_nome ? ' · ' + escapeHtml(p.usuario_nome) : ''}</div>
            </div>`;
        }).join('');
    }

    document.getElementById('verMaisBusca')?.addEventListener('input', renderVerMaisLista);
    document.querySelectorAll('#verMaisFiltros [data-filtro]').forEach((btn) => {
        btn.addEventListener('click', function () {
            document.querySelectorAll('#verMaisFiltros [data-filtro]').forEach((b) => b.classList.remove('active'));
            this.classList.add('active');
            renderVerMaisLista();
        });
    });

    document.getElementById('filtroSetor')?.addEventListener('change', () => calendar?.refetchEvents());
    document.getElementById('filtroUsuario')?.addEventListener('change', () => calendar?.refetchEvents());
    document.getElementById('filtroBusca')?.addEventListener('input', debounce(() => calendar?.refetchEvents(), 400));

    async function carregarStats() {
        const wrap = document.getElementById('calStatsRow');
        if (!wrap) return;
        try {
            const s = await api('api/calendario_stats.php');
            const map = {
                presentes_hoje: s.presentes_hoje,
                atrasados_hoje: s.atrasados_hoje,
                faltas_hoje: s.faltas_hoje,
                ausentes_hoje: s.ausentes_hoje,
                taxa_presenca: s.taxa_presenca + '%',
            };
            wrap.querySelectorAll('[data-stat]').forEach((elStat) => {
                const k = elStat.dataset.stat;
                if (map[k] !== undefined && elStat.textContent !== String(map[k])) {
                    elStat.textContent = map[k];
                    elStat.closest('.cal-stat-animate')?.classList.add('cal-stat-pulse');
                    setTimeout(() => elStat.closest('.cal-stat-animate')?.classList.remove('cal-stat-pulse'), 600);
                }
            });
            const lista = document.getElementById('calProximosEventos');
            if (lista && s.proximos_eventos) {
                lista.innerHTML = s.proximos_eventos.length
                    ? s.proximos_eventos.slice(0, 5).map((e) => `
                        <div class="cal-proximo-item">
                            <strong>${escapeHtml(e.titulo)}</strong>
                            <small>${new Date(e.data_inicio).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</small>
                        </div>`).join('')
                    : '<p class="text-muted small mb-0">Nenhum evento nos próximos 7 dias.</p>';
            }
        } catch (e) { /* ignore */ }
    }

    window.novoEvento = function (dataStr) {
        document.getElementById('formEvento')?.reset();
        document.getElementById('evId').value = '0';
        document.getElementById('modalEventoTitulo').textContent = 'Novo Evento';
        document.getElementById('btnExcluirEv')?.classList.add('d-none');
        if (dataStr) {
            document.getElementById('evInicio').value =
                dataStr.length <= 10 ? dataStr + 'T09:00' : dataStr.slice(0, 16);
        }
        modal?.show();
    };

    function editarEvento(ev) {
        document.getElementById('evId').value = ev.id;
        document.getElementById('evTitulo').value = ev.title.replace(/^[^\s]+\s*/, '').trim();
        document.getElementById('evTipo').value = ev.extendedProps.tipo || 'evento';
        document.getElementById('evVisibilidade').value = ev.extendedProps.visibilidade || 'empresa';
        document.getElementById('evDescricao').value = ev.extendedProps.descricao || '';
        const start = ev.startStr || '';
        document.getElementById('evInicio').value = start.length <= 10 ? start + 'T09:00' : start.slice(0, 16);
        if (ev.endStr) {
            document.getElementById('evFim').value =
                ev.endStr.length <= 10 ? ev.endStr + 'T18:00' : ev.endStr.slice(0, 16);
        }
        document.getElementById('modalEventoTitulo').textContent = 'Editar Evento';
        document.getElementById('btnExcluirEv')?.classList.remove('d-none');
        modal?.show();
    }

    document.getElementById('formEvento')?.addEventListener('submit', async function (e) {
        e.preventDefault();
        const fd = new FormData(this);
        const body = Object.fromEntries(fd.entries());
        body.dia_inteiro = document.getElementById('evDiaInteiro').checked ? 1 : 0;
        try {
            await api('api/calendario.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            modal?.hide();
            calendar?.refetchEvents();
            carregarStats();
        } catch (err) {
            alert(err.message);
        }
    });

    document.getElementById('btnExcluirEv')?.addEventListener('click', async function () {
        if (!confirm('Excluir este evento?')) return;
        const id = document.getElementById('evId').value;
        try {
            await api('api/calendario.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ acao: 'excluir', id }),
            });
            modal?.hide();
            calendar?.refetchEvents();
            carregarStats();
        } catch (err) {
            alert(err.message);
        }
    });

    carregarStats();
    setInterval(carregarStats, 60000);
})();
