// ============================================
// OS TRÊS M - JavaScript Principal
// ============================================

document.addEventListener('DOMContentLoaded', function () {

    // ============================================
    // TEMA (Modo Escuro/Claro)
    // ============================================
    const themeToggle = document.getElementById('themeToggle');
    const themeIcon = document.getElementById('themeIcon');
    const html = document.documentElement;

    const savedTheme = localStorage.getItem('theme') || 'dark';
    html.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);

    themeToggle?.addEventListener('click', function () {
        const current = html.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('theme', next);
        updateThemeIcon(next);
    });

    function updateThemeIcon(theme) {
        if (themeIcon) {
            themeIcon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-fill';
        }
    }

    // ============================================
    // SIDEBAR TOGGLE
    // ============================================
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');

    function openSidebar() {
        sidebar?.classList.add('open');
        overlay?.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    function closeSidebar() {
        sidebar?.classList.remove('open');
        overlay?.classList.remove('show');
        document.body.style.overflow = '';
    }

    sidebarToggle?.addEventListener('click', function () {
        if (window.innerWidth < 992) {
            sidebar?.classList.contains('open') ? closeSidebar() : openSidebar();
        } else {
            // Desktop: colapsar sidebar
            const mainContent = document.querySelector('.main-content');
            const topbar = document.querySelector('.topbar');
            if (sidebar?.classList.contains('collapsed')) {
                sidebar.classList.remove('collapsed');
                if (mainContent) mainContent.style.marginLeft = 'var(--sidebar-width)';
                if (topbar) topbar.style.left = 'var(--sidebar-width)';
            } else {
                sidebar?.classList.add('collapsed');
                if (mainContent) mainContent.style.marginLeft = '0';
                if (topbar) topbar.style.left = '0';
            }
        }
    });

    sidebarClose?.addEventListener('click', closeSidebar);
    overlay?.addEventListener('click', closeSidebar);

    // ============================================
    // NOTIFICAÇÕES
    // ============================================
    document.querySelectorAll('.notif-item').forEach(item => {
        item.addEventListener('click', function () {
            const id = this.dataset.id;
            if (id) {
                fetch('api/notificacoes.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: `acao=marcar_lida&id=${id}`
                }).catch(() => {});
                this.classList.remove('unread');
            }
        });
    });

    document.querySelector('.mark-all-read')?.addEventListener('click', function (e) {
        e.preventDefault();
        fetch('api/notificacoes.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'acao=marcar_todas'
        }).then(() => {
            document.querySelectorAll('.notif-item.unread').forEach(el => el.classList.remove('unread'));
            const badge = document.querySelector('.notif-badge');
            if (badge) badge.remove();
            this.style.display = 'none';
        }).catch(() => {});
    });

    // Polling de notificações
    let notifCount = parseInt(document.querySelector('.notif-badge')?.textContent) || 0;
    setInterval(() => {
        fetch('api/notificacoes.php?acao=contar')
            .then(r => {
                if (!r.ok) throw new Error('Erro na API');
                return r.json();
            })
            .then(d => {
                const badge = document.querySelector('.notif-badge');
                if (d.total > 0) {
                    if (!badge) {
                        const btn = document.getElementById('notifBtn');
                        if (btn) {
                            const span = document.createElement('span');
                            span.className = 'notif-badge';
                            span.textContent = d.total > 9 ? '9+' : d.total;
                            btn.appendChild(span);
                        }
                    } else {
                        badge.textContent = d.total > 9 ? '9+' : d.total;
                    }
                } else if (badge) {
                    badge.remove();
                }
            }).catch(() => {});
    }, 30000);

    // ============================================
    // TOAST NOTIFICATIONS
    // ============================================
    window.showToast = function (message, type = 'success', duration = 3500) {
        const container = getOrCreateToastContainer();
        const toast = document.createElement('div');
        const icons = { success: 'check-circle-fill', danger: 'exclamation-circle-fill', warning: 'exclamation-triangle-fill', info: 'info-circle-fill' };
        const colors = { success: 'var(--verde)', danger: 'var(--vermelho)', warning: 'var(--amarelo)', info: 'var(--azul-claro)' };

        toast.style.cssText = `
            display: flex; align-items: center; gap: 10px;
            background: var(--bg-card); border: 1px solid var(--border-color);
            border-left: 4px solid ${colors[type] || colors.info};
            border-radius: 10px; padding: 12px 16px;
            box-shadow: var(--shadow-lg); min-width: 280px; max-width: 380px;
            animation: slideInRight 0.3s ease; font-size: 13.5px;
            color: var(--text-primary);
        `;

        toast.innerHTML = `
            <i class="bi bi-${icons[type] || icons.info}" style="color:${colors[type]};font-size:18px;flex-shrink:0"></i>
            <span style="flex:1">${message}</span>
            <button onclick="this.parentElement.remove()" style="background:none;border:none;color:var(--text-muted);cursor:pointer;font-size:16px;padding:0;line-height:1">×</button>
        `;

        container.appendChild(toast);
        setTimeout(() => {
            toast.style.animation = 'slideOutRight 0.3s ease forwards';
            setTimeout(() => toast.remove(), 300);
        }, duration);
    };

    function getOrCreateToastContainer() {
        let container = document.getElementById('toastContainer');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toastContainer';
            container.style.cssText = 'position:fixed;top:80px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px';
            document.body.appendChild(container);
        }
        return container;
    }

    // Adicionar animações CSS para toast
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight { from { opacity:0; transform:translateX(100%); } to { opacity:1; transform:translateX(0); } }
        @keyframes slideOutRight { from { opacity:1; transform:translateX(0); } to { opacity:0; transform:translateX(100%); } }
        .sidebar.collapsed { width: 64px; }
        .sidebar.collapsed .brand-text,
        .sidebar.collapsed .user-info,
        .sidebar.collapsed .nav-item span,
        .sidebar.collapsed .nav-label,
        .sidebar.collapsed .nav-badge { display: none !important; }
        .sidebar.collapsed .nav-item { justify-content: center; padding: 10px; }
        .sidebar.collapsed .brand-logo { margin: 0 auto; }
        .sidebar.collapsed .sidebar-user { justify-content: center; }
    `;
    document.head.appendChild(style);

    // ============================================
    // PESQUISA GLOBAL
    // ============================================
    const globalSearch = document.getElementById('globalSearch');
    let searchTimeout;

    globalSearch?.addEventListener('input', function () {
        clearTimeout(searchTimeout);
        const q = this.value.trim();
        if (q.length < 2) return;
        searchTimeout = setTimeout(() => {
            // Implementar pesquisa global
        }, 500);
    });

    // ============================================
    // AUTO-RESIZE TEXTAREA
    // ============================================
    document.querySelectorAll('textarea').forEach(ta => {
        ta.addEventListener('input', function () {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 200) + 'px';
        });
    });

    // ============================================
    // TOOLTIPS
    // ============================================
    const tooltipEls = document.querySelectorAll('[title]');
    tooltipEls.forEach(el => {
        if (!el.dataset.bsToggle) {
            new bootstrap.Tooltip(el, { trigger: 'hover', placement: 'top' });
        }
    });

    // ============================================
    // LOADING em formulários
    // ============================================
    document.querySelectorAll('form').forEach(form => {
        form.addEventListener('submit', function () {
            const btn = this.querySelector('[type="submit"]');
            if (btn && !btn.dataset.noLoading) {
                const original = btn.innerHTML;
                btn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Aguarde...';
                btn.disabled = true;
                // Restaurar após 10s (fallback)
                setTimeout(() => {
                    btn.innerHTML = original;
                    btn.disabled = false;
                }, 10000);
            }
        });
    });

    // ============================================
    // CONFIRMAR AÇÕES DESTRUTIVAS
    // ============================================
    document.querySelectorAll('[data-confirm]').forEach(el => {
        el.addEventListener('click', function (e) {
            if (!confirm(this.dataset.confirm)) {
                e.preventDefault();
                e.stopPropagation();
            }
        });
    });

    // ============================================
    // ATUALIZAR STATUS ONLINE
    // ============================================
    setInterval(() => {
        fetch('api/online.php', { method: 'POST' }).catch(() => {});
    }, 60000);

    // ============================================
    // ANIMAÇÕES DE ENTRADA
    // ============================================
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });

    document.querySelectorAll('.card, .stat-card').forEach(el => {
        observer.observe(el);
    });

});
