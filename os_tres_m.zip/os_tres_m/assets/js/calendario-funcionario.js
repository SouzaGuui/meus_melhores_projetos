(function () {
    const cfg = window.CAL_FUNC_CONFIG || {};
    const base = cfg.baseUrl || '';
    let dadosCache = null;
    let chartPresenca = null;

    async function api(url) {
        const r = await fetch(base + url, { credentials: 'same-origin' });
        const d = await r.json();
        if (d.erro) throw new Error(d.erro);
        return d;
    }

    function escapeHtml(t) {
        const d = document.createElement('div');
        d.textContent = t ?? '';
        return d.innerHTML;
    }

    const statusColors = {
        Presente: 'var(--verde)',
        Atrasado: 'var(--amarelo)',
        Falta: 'var(--vermelho)',
        Ausente: 'var(--text-muted)',
    };

    async function carregar() {
        const d = await api(
            `api/calendario_funcionario.php?usuario_id=${cfg.usuarioId}&mes=${cfg.mes}&ano=${cfg.ano}`
        );
        dadosCache = d;
        renderHero(d);
        renderResumo(d.resumo);
        renderMiniCal(d);
        renderSemanal(d.semanal);
        renderTarefas(d.tarefas);
        renderHE(d.horas_extras_lista);
        renderChart(d.grafico_presenca);
    }

    function renderHero(d) {
        const st = document.getElementById('calStatusAtual');
        if (st) {
            const label = d.status_atual || '—';
            st.textContent = label;
            st.style.background = (statusColors[label] || 'var(--text-muted)') + '22';
            st.style.color = statusColors[label] || 'var(--text-muted)';
        }
        const prod = document.getElementById('calProdutividade');
        if (prod) prod.textContent = (d.produtividade ?? 0) + '%';
        const tc = document.getElementById('calTarefasConcluidas');
        if (tc) tc.textContent = d.resumo?.tarefas_concluidas ?? 0;
        const ht = document.getElementById('calHorasTrab');
        if (ht) ht.textContent = (d.resumo?.horas_trabalhadas ?? 0) + 'h';
        const fer = document.getElementById('calFerias');
        if (fer) fer.textContent = d.resumo?.ferias ?? 0;
    }

    function renderResumo(resumo) {
        if (!resumo) return;
        document.querySelectorAll('[data-k]').forEach((el) => {
            const k = el.dataset.k;
            if (resumo[k] === undefined) return;
            if (k === 'taxa_presenca') {
                el.textContent = resumo[k] + '%';
            } else if (k === 'horas_extras' || k === 'banco_horas') {
                el.textContent = resumo[k] + 'h';
            } else {
                el.textContent = resumo[k];
            }
        });
    }

    function renderMiniCal(d) {
        const grid = document.getElementById('calMiniGrid');
        if (!grid) return;
        const primeiro = new Date(cfg.ano, cfg.mes - 1, 1);
        const ultimo = new Date(cfg.ano, cfg.mes, 0).getDate();
        const startPad = primeiro.getDay();
        const diasMap = {};
        (d.dias || []).forEach((dia) => { diasMap[dia.data] = dia; });

        const semanas = ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'];
        let html = '<div class="cal-mini-weekdays">' + semanas.map((s) => `<span>${s}</span>`).join('') + '</div><div class="cal-mini-days">';
        for (let i = 0; i < startPad; i++) html += '<span class="cal-mini-day empty"></span>';
        const hoje = new Date().toISOString().slice(0, 10);
        for (let dia = 1; dia <= ultimo; dia++) {
            const dataStr = `${cfg.ano}-${String(cfg.mes).padStart(2, '0')}-${String(dia).padStart(2, '0')}`;
            const info = diasMap[dataStr];
            const cor = info?.cor || '';
            const cls = ['cal-mini-day', dataStr === hoje ? 'today' : '', cor ? 'has-status' : ''].filter(Boolean).join(' ');
            const title = info?.tipo_dia ? info.tipo_dia + (info.status ? ' — ' + info.status : '') : '';
            html += `<button type="button" class="${cls}" data-data="${dataStr}" style="${cor ? '--day-color:' + cor : ''}" title="${escapeHtml(title)}">${dia}</button>`;
        }
        html += '</div>';
        grid.innerHTML = html;
        grid.querySelectorAll('.cal-mini-day[data-data]').forEach((btn) => {
            btn.addEventListener('click', () => mostrarDia(btn.dataset.data));
        });
    }

    function renderSemanal(semanal) {
        const el = document.getElementById('calResumoSemanal');
        if (!el) return;
        if (!semanal?.length) {
            el.innerHTML = '<p class="text-muted small mb-0">Sem dados semanais.</p>';
            return;
        }
        el.innerHTML = semanal.map((sem, i) => `
            <div class="mb-3 pb-3" style="border-bottom:1px solid var(--border-color)">
                <div class="d-flex justify-content-between mb-2">
                    <strong style="font-size:13px">Semana ${i + 1}</strong>
                    <span style="font-size:12px;color:var(--text-muted)">
                        <span style="color:var(--verde)">${sem.presentes} pres.</span> ·
                        <span style="color:var(--vermelho)">${sem.faltas} faltas</span>
                    </span>
                </div>
                <div class="d-flex flex-wrap gap-1">
                    ${(sem.dias || []).map((sd) => `
                        <span class="badge rounded-pill" style="font-size:10px;background:${sd.cor || 'var(--bg-secondary)'};color:var(--text-primary);min-width:28px">${sd.dia}</span>
                    `).join('')}
                </div>
            </div>
        `).join('');
    }

    function mostrarDia(dataStr) {
        const el = document.getElementById('calDiaDetalhe');
        if (!el || !dadosCache) return;
        document.querySelectorAll('.cal-mini-day').forEach((b) => b.classList.remove('selected'));
        document.querySelector(`.cal-mini-day[data-data="${dataStr}"]`)?.classList.add('selected');

        const dia = (dadosCache.dias || []).find((x) => x.data === dataStr);
        const tarefasDia = (dadosCache.tarefas || []).filter((t) => (t.prazo || '').slice(0, 10) === dataStr);

        let html = `<p style="font-weight:700;margin-bottom:10px">${new Date(dataStr + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}</p>`;

        if (dia) {
            html += `<ul class="cal-dia-list">
                <li><strong>Status:</strong> ${escapeHtml(dia.status || dia.tipo_dia || '—')}</li>
                <li><strong>Entrada:</strong> ${dia.entrada || '—'}</li>
                <li><strong>Saída:</strong> ${dia.saida || '—'}</li>
                <li><strong>Atraso:</strong> ${dia.atraso ? dia.atraso + ' min' : '—'}</li>
                <li><strong>Horas:</strong> ${dia.horas !== undefined ? dia.horas + 'h' : '—'}</li>
                <li><strong>H. extras:</strong> ${dia.horas_extras ? dia.horas_extras + 'h' : '—'}</li>
            </ul>`;
            if (dia.ausencia) {
                html += `<p class="mt-2" style="font-size:12px;color:var(--vermelho)"><strong>Falta informada:</strong> ${escapeHtml(dia.ausencia.justificativa || '')} (${dia.ausencia.status})</p>`;
            }
            if (dia.horas_extra_sol) {
                html += `<p style="font-size:12px;color:#F97316"><strong>HE:</strong> ${dia.horas_extra_sol.horas_extras}h — ${escapeHtml(dia.horas_extra_sol.motivo || '')} (${dia.horas_extra_sol.status})</p>`;
            }
            if (dia.eventos?.length) {
                html += '<p style="font-weight:600;margin-top:12px">Eventos</p><ul class="cal-dia-list">';
                dia.eventos.forEach((ev) => {
                    html += `<li>${escapeHtml(ev.titulo)} <small>(${ev.tipo})</small></li>`;
                });
                html += '</ul>';
            }
        } else {
            html += '<p class="text-muted small">Sem registro de ponto neste dia.</p>';
        }

        if (tarefasDia.length) {
            html += '<p style="font-weight:600;margin-top:12px">Tarefas</p><ul class="cal-dia-list">';
            tarefasDia.forEach((t) => {
                html += `<li>${escapeHtml(t.titulo)} — <span class="badge-status status-${t.status}">${t.status.replace('_', ' ')}</span></li>`;
            });
            html += '</ul>';
        }

        el.innerHTML = html;
    }

    function renderTarefas(tarefas) {
        const el = document.getElementById('calListaTarefas');
        if (!el) return;
        if (!tarefas?.length) {
            el.innerHTML = '<p class="p-3 text-muted small mb-0">Nenhuma tarefa com prazo neste mês.</p>';
            return;
        }
        el.innerHTML = tarefas.map((t) => `
            <div class="cal-tarefa-item">
                <strong>${escapeHtml(t.titulo)}</strong>
                <small>${(t.prazo || '').slice(0, 10).split('-').reverse().join('/')}</small>
                <span class="badge-status status-${t.status}">${t.status.replace('_', ' ')}</span>
            </div>
        `).join('');
    }

    function renderHE(lista) {
        const el = document.getElementById('calListaHE');
        if (!el) return;
        if (!lista?.length) {
            el.innerHTML = '<p class="p-3 text-muted small mb-0">Nenhuma solicitação de HE neste mês.</p>';
            return;
        }
        el.innerHTML = lista.map((h) => `
            <div class="cal-tarefa-item">
                <strong>${h.data_trabalhada.split('-').reverse().join('/')} — ${parseFloat(h.horas_extras).toFixed(1)}h</strong>
                <small>${escapeHtml(h.motivo || '').slice(0, 60)}</small>
                <span class="badge-status status-${h.status === 'aprovada' ? 'concluida' : (h.status === 'recusada' ? 'cancelada' : 'pendente')}">${h.status}</span>
            </div>
        `).join('');
    }

    function renderChart(grafico) {
        const canvas = document.getElementById('chartPresencaMes');
        if (!canvas || typeof Chart === 'undefined' || !grafico) return;
        if (chartPresenca) chartPresenca.destroy();
        chartPresenca = new Chart(canvas, {
            type: 'doughnut',
            data: {
                labels: grafico.labels,
                datasets: [{
                    data: grafico.valores,
                    backgroundColor: grafico.cores,
                    borderWidth: 0,
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: '#94a3b8', boxWidth: 12, font: { size: 11 } } },
                },
            },
        });
    }

    carregar().catch((e) => {
        const grid = document.getElementById('calMiniGrid');
        if (grid) grid.innerHTML = '<p class="text-danger">' + escapeHtml(e.message) + '</p>';
    });
})();
