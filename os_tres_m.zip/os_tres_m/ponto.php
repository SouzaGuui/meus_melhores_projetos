<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Folha de Ponto';
$breadcrumb = 'Ponto';
$user = currentUser();
$pdo = db();

// Filtros
$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$usuarioFiltro = hasPermission(['rh','admin','gerente','coordenacao']) ? (int)($_GET['usuario_id'] ?? $user['id']) : (int)$user['id'];

// Registrar ponto via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $acao = $_POST['acao'];
    $uid = (int)$user['id'];
    $hoje = date('Y-m-d');
    $agora = date('H:i:s');

    if ($acao === 'entrada') {
        $ponto = getPontoHoje($uid);
        if ($ponto) {
            jsonResponse(['erro' => 'Entrada já registrada hoje.']);
        }
        $pdo->prepare("INSERT INTO ponto (usuario_id, data, entrada, status) VALUES (?,?,?,'presente')")->execute([$uid,$hoje,$agora]);
        registrarLog('ponto_entrada', "Entrada registrada: $agora");
        jsonResponse(['sucesso' => true, 'hora' => substr($agora,0,5), 'mensagem' => 'Entrada registrada!']);
    }

    if ($acao === 'saida') {
        $ponto = getPontoHoje($uid);
        if (!$ponto || !$ponto['entrada']) {
            jsonResponse(['erro' => 'Registre a entrada primeiro.']);
        }
        if ($ponto['saida']) {
            jsonResponse(['erro' => 'Saída já registrada hoje.']);
        }
        $horas = calcularHoras($ponto['entrada'], $agora);
        $horasExtras = max(0, $horas - 8);
        $pdo->prepare("UPDATE ponto SET saida=?, horas_trabalhadas=?, horas_extras=? WHERE id=?")->execute([$agora, $horas, $horasExtras, $ponto['id']]);
        registrarLog('ponto_saida', "Saída registrada: $agora");
        jsonResponse(['sucesso' => true, 'hora' => substr($agora,0,5), 'horas' => number_format($horas,1), 'mensagem' => 'Saída registrada!']);
    }
}

// Buscar ponto do mês
$pontoHoje = getPontoHoje($usuarioFiltro);

$stmt = $pdo->prepare("
    SELECT p.*, u.nome as funcionario_nome
    FROM ponto p
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.usuario_id = ? AND MONTH(p.data) = ? AND YEAR(p.data) = ?
    ORDER BY p.data DESC
");
$stmt->execute([$usuarioFiltro, $mes, $ano]);
$registros = $stmt->fetchAll();

// Estatísticas do mês
$totalPresentes = 0; $totalFaltas = 0; $totalHoras = 0; $totalExtras = 0; $totalAtrasos = 0;
foreach ($registros as $r) {
    if ($r['status'] === 'presente') $totalPresentes++;
    if ($r['status'] === 'falta') $totalFaltas++;
    $totalHoras += $r['horas_trabalhadas'];
    $totalExtras += $r['horas_extras'];
    $totalAtrasos += $r['atraso'];
}

// Lista de funcionários para filtro
$funcionarios = [];
if (hasPermission(['rh','admin','gerente','coordenacao'])) {
    $funcionarios = getUsuarios('ativo');
}

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <!-- Registro de Ponto (apenas próprio usuário) -->
            <?php if ($usuarioFiltro == $user['id']): ?>
            <div class="card mb-4 fade-in" style="background:linear-gradient(135deg,rgba(37,99,235,0.1),rgba(124,58,237,0.1));border-color:rgba(37,99,235,0.2)">
                <div class="card-body">
                    <div class="row align-items-center g-3">
                        <div class="col-12 col-md-4">
                            <div class="d-flex align-items-center gap-3">
                                <div style="width:56px;height:56px;background:linear-gradient(135deg,#2563EB,#7C3AED);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;color:white">
                                    <i class="bi bi-clock-fill"></i>
                                </div>
                                <div>
                                    <div style="font-size:28px;font-weight:800;color:var(--text-primary)" id="relogioAtual">--:--:--</div>
                                    <div style="font-size:13px;color:var(--text-muted)"><?= date('d/m/Y') ?> — <?= date('l') ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="row g-2 text-center">
                                <div class="col-6">
                                    <div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);border-radius:10px;padding:12px">
                                        <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">ENTRADA</div>
                                        <div style="font-size:20px;font-weight:700;color:var(--verde)" id="horaEntrada">
                                            <?= $pontoHoje && $pontoHoje['entrada'] ? formatarHora($pontoHoje['entrada']) : '--:--' ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:12px">
                                        <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">SAÍDA</div>
                                        <div style="font-size:20px;font-weight:700;color:var(--vermelho)" id="horaSaida">
                                            <?= $pontoHoje && $pontoHoje['saida'] ? formatarHora($pontoHoje['saida']) : '--:--' ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="d-flex gap-2 justify-content-md-end">
                                <?php if (!$pontoHoje || !$pontoHoje['entrada']): ?>
                                <button class="btn btn-success" id="btnEntrada" onclick="registrarPonto('entrada')">
                                    <i class="bi bi-box-arrow-in-right"></i> Registrar Entrada
                                </button>
                                <?php elseif (!$pontoHoje['saida']): ?>
                                <button class="btn btn-danger" id="btnSaida" onclick="registrarPonto('saida')">
                                    <i class="bi bi-box-arrow-right"></i> Registrar Saída
                                </button>
                                <?php else: ?>
                                <div class="btn btn-outline" style="cursor:default">
                                    <i class="bi bi-check-circle-fill" style="color:var(--verde)"></i> Ponto Completo
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats do Mês -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="stat-card green">
                        <div class="stat-icon green"><i class="bi bi-calendar-check"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $totalPresentes ?></div>
                            <div class="stat-label">Presenças</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card red">
                        <div class="stat-icon red"><i class="bi bi-calendar-x"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $totalFaltas ?></div>
                            <div class="stat-label">Faltas</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card blue">
                        <div class="stat-icon blue"><i class="bi bi-clock"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= number_format($totalHoras,1) ?>h</div>
                            <div class="stat-label">Horas Trabalhadas</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card purple">
                        <div class="stat-icon purple"><i class="bi bi-plus-circle"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= number_format($totalExtras,1) ?>h</div>
                            <div class="stat-label">Horas Extras</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <?php if (hasPermission(['rh','admin','gerente','coordenacao'])): ?>
                        <div class="col-12 col-md-4">
                            <label class="form-label">Funcionário</label>
                            <select name="usuario_id" class="form-select">
                                <?php foreach ($funcionarios as $f): ?>
                                <option value="<?= $f['id'] ?>" <?= $f['id']==$usuarioFiltro?'selected':'' ?>><?= htmlspecialchars($f['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Mês</label>
                            <select name="mes" class="form-select">
                                <?php for ($m=1;$m<=12;$m++): ?>
                                <option value="<?= $m ?>" <?= $m==$mes?'selected':'' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Ano</label>
                            <select name="ano" class="form-select">
                                <?php for ($a=date('Y');$a>=date('Y')-3;$a--): ?>
                                <option value="<?= $a ?>" <?= $a==$ano?'selected':'' ?>><?= $a ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-2">
                            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Filtrar</button>
                        </div>
                        <div class="col-12 col-md-2">
                            <a href="relatorios.php?tipo=ponto&usuario_id=<?= $usuarioFiltro ?>&mes=<?= $mes ?>&ano=<?= $ano ?>" class="btn btn-outline w-100">
                                <i class="bi bi-file-pdf"></i> Exportar
                            </a>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Tabela de Registros -->
            <div class="table-wrapper">
                <div class="card-header">
                    <h5 class="card-title"><i class="bi bi-calendar3 me-2"></i>Registros — <?= date('F/Y', mktime(0,0,0,$mes,1,$ano)) ?></h5>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Dia</th>
                                <th>Entrada</th>
                                <th>Saída</th>
                                <th>Horas</th>
                                <th>Extras</th>
                                <th>Atraso</th>
                                <th>Status</th>
                                <?php if (hasPermission(['rh','admin'])): ?>
                                <th>Ações</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($registros)): ?>
                            <tr>
                                <td colspan="9" class="text-center" style="padding:40px;color:var(--text-muted)">
                                    <i class="bi bi-calendar-x" style="font-size:32px;display:block;margin-bottom:8px"></i>
                                    Nenhum registro neste período
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($registros as $r): ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= formatarData($r['data']) ?></td>
                                <td style="font-size:12px;color:var(--text-muted)"><?= date('D', strtotime($r['data'])) ?></td>
                                <td style="color:var(--verde);font-weight:600"><?= formatarHora($r['entrada']) ?></td>
                                <td style="color:var(--vermelho);font-weight:600"><?= formatarHora($r['saida']) ?></td>
                                <td><?= $r['horas_trabalhadas'] > 0 ? number_format($r['horas_trabalhadas'],1).'h' : '-' ?></td>
                                <td style="color:var(--roxo-claro)"><?= $r['horas_extras'] > 0 ? '+'.number_format($r['horas_extras'],1).'h' : '-' ?></td>
                                <td style="color:var(--amarelo)"><?= $r['atraso'] > 0 ? number_format($r['atraso'],0).'min' : '-' ?></td>
                                <td><span class="badge-status status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                                <?php if (hasPermission(['rh','admin'])): ?>
                                <td>
                                    <button class="btn btn-outline btn-icon btn-sm" onclick="editarPonto(<?= htmlspecialchars(json_encode($r)) ?>)" title="Editar">
                                        <i class="bi bi-pencil-fill" style="color:var(--azul-claro)"></i>
                                    </button>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal Editar Ponto (RH/Admin) -->
<?php if (hasPermission(['rh','admin'])): ?>
<div class="modal fade" id="modalPonto" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Editar Registro de Ponto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="api/ponto_editar.php">
                <input type="hidden" name="id" id="pontoId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label">Entrada</label>
                            <input type="time" name="entrada" id="pontoEntrada" class="form-control">
                        </div>
                        <div class="col-6">
                            <label class="form-label">Saída</label>
                            <input type="time" name="saida" id="pontoSaida" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Status</label>
                            <select name="status" id="pontoStatus" class="form-select">
                                <option value="presente">Presente</option>
                                <option value="ausente">Ausente</option>
                                <option value="falta">Falta</option>
                                <option value="ferias">Férias</option>
                                <option value="licenca">Licença</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observação</label>
                            <textarea name="observacao" id="pontoObs" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $extraJS = '<script>
// Relógio em tempo real
function atualizarRelogio() {
    const agora = new Date();
    const h = String(agora.getHours()).padStart(2,"0");
    const m = String(agora.getMinutes()).padStart(2,"0");
    const s = String(agora.getSeconds()).padStart(2,"0");
    const el = document.getElementById("relogioAtual");
    if (el) el.textContent = `${h}:${m}:${s}`;
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

function registrarPonto(tipo) {
    const btn = document.getElementById(tipo === "entrada" ? "btnEntrada" : "btnSaida");
    if (btn) { btn.disabled = true; btn.innerHTML = \'<span class="spinner-border spinner-border-sm"></span> Registrando...\'; }

    fetch("ponto.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: "acao=" + tipo
    })
    .then(r => r.json())
    .then(d => {
        if (d.sucesso) {
            if (tipo === "entrada") {
                document.getElementById("horaEntrada").textContent = d.hora;
                if (btn) { btn.outerHTML = \'<button class="btn btn-danger" id="btnSaida" onclick="registrarPonto(\\\'saida\\\')"><i class="bi bi-box-arrow-right"></i> Registrar Saída</button>\'; }
            } else {
                document.getElementById("horaSaida").textContent = d.hora;
                if (btn) { btn.outerHTML = \'<div class="btn btn-outline" style="cursor:default"><i class="bi bi-check-circle-fill" style="color:var(--verde)"></i> Ponto Completo</div>\'; }
            }
            showToast(d.mensagem, "success");
        } else {
            showToast(d.erro, "danger");
            if (btn) { btn.disabled = false; btn.innerHTML = tipo === "entrada" ? \'<i class="bi bi-box-arrow-in-right"></i> Registrar Entrada\' : \'<i class="bi bi-box-arrow-right"></i> Registrar Saída\'; }
        }
    });
}

function editarPonto(r) {
    document.getElementById("pontoId").value = r.id;
    document.getElementById("pontoEntrada").value = r.entrada ? r.entrada.substring(0,5) : "";
    document.getElementById("pontoSaida").value = r.saida ? r.saida.substring(0,5) : "";
    document.getElementById("pontoStatus").value = r.status;
    document.getElementById("pontoObs").value = r.observacao || "";
    new bootstrap.Modal(document.getElementById("modalPonto")).show();
}
</script>'; ?>

<?php include 'includes/footer.php'; ?>
