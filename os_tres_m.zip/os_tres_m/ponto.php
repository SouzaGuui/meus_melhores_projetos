<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Folha de Ponto';
$breadcrumb = 'Ponto';
$user = currentUser();
$pdo = db();
garantirTabelaPontoAusencias();
garantirTabelaHorasExtras();

// Filtros
$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$usuarioFiltro = podeVerPontoDeOutros() ? (int)($_GET['usuario_id'] ?? $user['id']) : (int)$user['id'];

// Registrar ponto via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $acao = $_POST['acao'];
    $uid = (int)$user['id'];
    $hoje = date('Y-m-d');
    $agora = date('H:i:s');

    if ($acao === 'entrada') {
        $ponto = getPontoHoje($uid);
        if ($ponto) {
            jsonResponse(['erro' => 'Entrada já registrada hoje.']);
        }
        $pdo->prepare("INSERT INTO ponto (usuario_id, data, entrada, status) VALUES (?,?,?,'presente')")->execute([$uid,$hoje,$agora]);
        registrarLog('ponto_entrada', "Entrada registrada: $agora");
        jsonResponse(['sucesso' => true, 'hora' => substr($agora,0,5), 'mensagem' => 'Entrada registrada!']);
    }

    if ($acao === 'saida') {
        $ponto = getPontoHoje($uid);
        if (!$ponto || !$ponto['entrada']) {
            jsonResponse(['erro' => 'Registre a entrada primeiro.']);
        }
        if ($ponto['saida']) {
            jsonResponse(['erro' => 'Saída já registrada hoje.']);
        }
        $horas = calcularHoras($ponto['entrada'], $agora);
        $horasExtras = max(0, $horas - 8);
        $pdo->prepare("UPDATE ponto SET saida=?, horas_trabalhadas=?, horas_extras=? WHERE id=?")->execute([$agora, $horas, $horasExtras, $ponto['id']]);
        registrarLog('ponto_saida', "Saída registrada: $agora");
        jsonResponse(['sucesso' => true, 'hora' => substr($agora,0,5), 'horas' => number_format($horas,1), 'mensagem' => 'Saída registrada!']);
    }
}

// Buscar ponto do mês
$pontoHoje = getPontoHoje($usuarioFiltro);

$stmt = $pdo->prepare("
    SELECT p.*, u.nome as funcionario_nome
    FROM ponto p
    JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.usuario_id = ? AND MONTH(p.data) = ? AND YEAR(p.data) = ?
    ORDER BY p.data DESC
");
$stmt->execute([$usuarioFiltro, $mes, $ano]);
$registros = $stmt->fetchAll();

// Estatísticas do mês
$totalPresentes = 0; $totalFaltas = 0; $totalHoras = 0; $totalExtras = 0; $totalAtrasos = 0;
foreach ($registros as $r) {
    if ($r['status'] === 'presente') $totalPresentes++;
    if ($r['status'] === 'falta') $totalFaltas++;
    $totalHoras += $r['horas_trabalhadas'];
    $totalExtras += $r['horas_extras'];
    $totalAtrasos += $r['atraso'];
}

// Lista de funcionários para filtro
$funcionarios = [];
if (podeVerPontoDeOutros()) {
    $funcionarios = getUsuarios('ativo');
}

$solicitacoesAusencia = [];
$stAus = $pdo->prepare("SELECT a.*, u.nome as usuario_nome FROM ponto_ausencias a JOIN usuarios u ON a.usuario_id = u.id WHERE a.usuario_id = ? AND MONTH(a.data_falta) = ? AND YEAR(a.data_falta) = ? ORDER BY a.criado_em DESC");
$stAus->execute([$usuarioFiltro, $mes, $ano]);
$solicitacoesAusencia = $stAus->fetchAll();

$pendentesEquipe = [];
if (podeAprovarFalta()) {
    $sqlPend = "SELECT a.*, u.nome as usuario_nome FROM ponto_ausencias a JOIN usuarios u ON a.usuario_id = u.id WHERE a.status = 'pendente'" . sqlOcultarAdmin('u');
    if (in_array(getNivelAcesso(), ['gerente', 'coordenacao'], true) && !empty($user['setor'])) {
        $sqlPend .= ' AND u.setor = ?';
        $stP = $pdo->prepare($sqlPend . ' ORDER BY a.data_falta ASC LIMIT 20');
        $stP->execute([$user['setor']]);
    } else {
        $stP = $pdo->query($sqlPend . ' ORDER BY a.data_falta ASC LIMIT 20');
    }
    $pendentesEquipe = $stP->fetchAll();
}

$solicitacoesHE = [];
$stHe = $pdo->prepare("SELECT h.*, u.nome as usuario_nome FROM horas_extras_solicitacoes h JOIN usuarios u ON h.usuario_id = u.id WHERE h.usuario_id = ? AND MONTH(h.data_trabalhada) = ? AND YEAR(h.data_trabalhada) = ? ORDER BY h.criado_em DESC");
$stHe->execute([$usuarioFiltro, $mes, $ano]);
$solicitacoesHE = $stHe->fetchAll();

$pendentesHE = [];
if (podeAprovarHorasExtras()) {
    $sqlHeP = "SELECT h.*, u.nome as usuario_nome FROM horas_extras_solicitacoes h JOIN usuarios u ON h.usuario_id = u.id WHERE h.status = 'pendente'" . sqlOcultarAdmin('u');
    if (in_array(getNivelAcesso(), ['gerente', 'coordenacao'], true) && !empty($user['setor'])) {
        $stHeP = $pdo->prepare($sqlHeP . ' AND u.setor = ? ORDER BY h.data_trabalhada ASC LIMIT 20');
        $stHeP->execute([$user['setor']]);
    } else {
        $stHeP = $pdo->query($sqlHeP . ' ORDER BY h.data_trabalhada ASC LIMIT 20');
    }
    $pendentesHE = $stHeP->fetchAll();
}

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <!-- Registro de Ponto (apenas próprio usuário) -->
            <?php if ($usuarioFiltro == $user['id']): ?>
            <div class="card mb-4 fade-in" style="background:linear-gradient(135deg,rgba(37,99,235,0.1),rgba(124,58,237,0.1));border-color:rgba(37,99,235,0.2)">
                <div class="card-body">
                    <div class="row align-items-center g-3">
                        <div class="col-12 col-md-4">
                            <div class="d-flex align-items-center gap-3">
                                <div style="width:56px;height:56px;background:linear-gradient(135deg,#2563EB,#7C3AED);border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;color:white">
                                    <i class="bi bi-clock-fill"></i>
                                </div>
                                <div>
                                    <div style="font-size:28px;font-weight:800;color:var(--text-primary)" id="relogioAtual">--:--:--</div>
                                    <div style="font-size:13px;color:var(--text-muted)"><?= date('d/m/Y') ?> — <?= date('l') ?></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="row g-2 text-center">
                                <div class="col-6">
                                    <div style="background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.2);border-radius:10px;padding:12px">
                                        <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">ENTRADA</div>
                                        <div style="font-size:20px;font-weight:700;color:var(--verde)" id="horaEntrada">
                                            <?= $pontoHoje && $pontoHoje['entrada'] ? formatarHora($pontoHoje['entrada']) : '--:--' ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);border-radius:10px;padding:12px">
                                        <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px">SAÍDA</div>
                                        <div style="font-size:20px;font-weight:700;color:var(--vermelho)" id="horaSaida">
                                            <?= $pontoHoje && $pontoHoje['saida'] ? formatarHora($pontoHoje['saida']) : '--:--' ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-4">
                            <div class="d-flex gap-2 justify-content-md-end">
                                <?php if (!$pontoHoje || !$pontoHoje['entrada']): ?>
                                <button class="btn btn-success" id="btnEntrada" onclick="registrarPonto('entrada')">
                                    <i class="bi bi-box-arrow-in-right"></i> Registrar Entrada
                                </button>
                                <?php elseif (!$pontoHoje['saida']): ?>
                                <button class="btn btn-danger" id="btnSaida" onclick="registrarPonto('saida')">
                                    <i class="bi bi-box-arrow-right"></i> Registrar Saída
                                </button>
                                <?php else: ?>
                                <div class="btn btn-outline" style="cursor:default">
                                    <i class="bi bi-check-circle-fill" style="color:var(--verde)"></i> Ponto Completo
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if (podeInformarFalta() && $usuarioFiltro == $user['id']): ?>
            <div class="card mb-4 fade-in">
                <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div>
                        <h5 class="card-title mb-1"><i class="bi bi-calendar-x me-2" style="color:var(--vermelho)"></i>Informar falta ou ausência</h5>
                        <p class="mb-0" style="font-size:13px;color:var(--text-muted)">Registre ausências com justificativa para análise da equipe/RH.</p>
                    </div>
                    <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalFalta">
                        <i class="bi bi-plus-circle"></i> Informar Falta
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($pendentesEquipe) && podeAprovarFalta()): ?>
            <div class="card mb-4">
                <div class="card-header"><h5 class="card-title mb-0">Solicitações pendentes da equipe</h5></div>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead><tr><th>Funcionário</th><th>Data</th><th>Período</th><th>Justificativa</th><th>Ações</th></tr></thead>
                        <tbody>
                        <?php foreach ($pendentesEquipe as $s): ?>
                        <tr>
                            <td><?= htmlspecialchars($s['usuario_nome']) ?></td>
                            <td><?= formatarData($s['data_falta']) ?></td>
                            <td><?= str_replace('_', ' ', ucfirst($s['tipo_periodo'])) ?></td>
                            <td style="max-width:200px;font-size:12px"><?= htmlspecialchars(mb_substr($s['justificativa'], 0, 80)) ?>...</td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" onclick="aprovarFalta(<?= (int)$s['id'] ?>, true)"><i class="bi bi-check"></i></button>
                                <button type="button" class="btn btn-danger btn-sm" onclick="aprovarFalta(<?= (int)$s['id'] ?>, false)"><i class="bi bi-x"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <?php if (podeRegistrarHorasExtras() && $usuarioFiltro == $user['id']): ?>
            <div class="card mb-4 fade-in">
                <div class="card-body d-flex flex-wrap align-items-center justify-content-between gap-3">
                    <div>
                        <h5 class="card-title mb-1"><i class="bi bi-clock-history me-2" style="color:var(--roxo-claro)"></i>Registrar horas extras</h5>
                        <p class="mb-0" style="font-size:13px;color:var(--text-muted)">Informe dia, horários, setor e motivo para aprovação.</p>
                    </div>
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalHorasExtras">
                        <i class="bi bi-plus-circle"></i> Registrar HE
                    </button>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($pendentesHE) && podeAprovarHorasExtras()): ?>
            <div class="card mb-4">
                <div class="card-header"><h5 class="card-title mb-0">Horas extras pendentes</h5></div>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead><tr><th>Funcionário</th><th>Data</th><th>Horas</th><th>Setor</th><th>Motivo</th><th>Ações</th></tr></thead>
                        <tbody>
                        <?php foreach ($pendentesHE as $h): ?>
                        <tr>
                            <td><?= htmlspecialchars($h['usuario_nome']) ?></td>
                            <td><?= formatarData($h['data_trabalhada']) ?></td>
                            <td><?= number_format((float)$h['horas_extras'], 1) ?>h</td>
                            <td><?= htmlspecialchars($h['setor'] ?: '—') ?></td>
                            <td style="max-width:180px;font-size:12px"><?= htmlspecialchars(mb_substr($h['motivo'], 0, 60)) ?>...</td>
                            <td>
                                <button type="button" class="btn btn-success btn-sm" onclick="aprovarHE(<?= (int)$h['id'] ?>, true)"><i class="bi bi-check"></i></button>
                                <button type="button" class="btn btn-danger btn-sm" onclick="aprovarHE(<?= (int)$h['id'] ?>, false)"><i class="bi bi-x"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats do Mês -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-3">
                    <div class="stat-card green">
                        <div class="stat-icon green"><i class="bi bi-calendar-check"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $totalPresentes ?></div>
                            <div class="stat-label">Presenças</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card red">
                        <div class="stat-icon red"><i class="bi bi-calendar-x"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $totalFaltas ?></div>
                            <div class="stat-label">Faltas</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card blue">
                        <div class="stat-icon blue"><i class="bi bi-clock"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= number_format($totalHoras,1) ?>h</div>
                            <div class="stat-label">Horas Trabalhadas</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-3">
                    <div class="stat-card purple">
                        <div class="stat-icon purple"><i class="bi bi-plus-circle"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= number_format($totalExtras,1) ?>h</div>
                            <div class="stat-label">Horas Extras</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-3 align-items-end">
                        <?php if (podeVerPontoDeOutros()): ?>
                        <div class="col-12 col-md-4">
                            <label class="form-label">Funcionário</label>
                            <select name="usuario_id" class="form-select">
                                <?php foreach ($funcionarios as $f): ?>
                                <option value="<?= $f['id'] ?>" <?= $f['id']==$usuarioFiltro?'selected':'' ?>><?= htmlspecialchars($f['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php endif; ?>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Mês</label>
                            <select name="mes" class="form-select">
                                <?php for ($m=1;$m<=12;$m++): ?>
                                <option value="<?= $m ?>" <?= $m==$mes?'selected':'' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-6 col-md-2">
                            <label class="form-label">Ano</label>
                            <select name="ano" class="form-select">
                                <?php for ($a=date('Y');$a>=date('Y')-3;$a--): ?>
                                <option value="<?= $a ?>" <?= $a==$ano?'selected':'' ?>><?= $a ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-12 col-md-2">
                            <button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Filtrar</button>
                        </div>
                        <?php if (podeExportar()): ?>
                        <div class="col-12 col-md-2">
                            <a href="relatorios.php?tipo=ponto&usuario_id=<?= $usuarioFiltro ?>&mes=<?= $mes ?>&ano=<?= $ano ?>" class="btn btn-outline w-100">
                                <i class="bi bi-file-pdf"></i> Exportar
                            </a>
                        </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <?php if (!empty($solicitacoesAusencia)): ?>
            <div class="card mb-4">
                <div class="card-header"><h5 class="card-title mb-0">Minhas solicitações de falta</h5></div>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead><tr><th>Data</th><th>Período</th><th>Status</th><th>Justificativa</th></tr></thead>
                        <tbody>
                        <?php foreach ($solicitacoesAusencia as $s): ?>
                        <tr>
                            <td><?= formatarData($s['data_falta']) ?></td>
                            <td><?= str_replace('_', ' ', ucfirst($s['tipo_periodo'])) ?></td>
                            <td><span class="badge-status status-<?= $s['status'] === 'aprovada' ? 'concluida' : ($s['status'] === 'recusada' ? 'cancelada' : 'pendente') ?>"><?= ucfirst($s['status']) ?></span></td>
                            <td style="font-size:12px"><?= htmlspecialchars(mb_substr($s['justificativa'], 0, 100)) ?></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($solicitacoesHE)): ?>
            <div class="card mb-4">
                <div class="card-header"><h5 class="card-title mb-0">Minhas horas extras</h5></div>
                <div class="table-responsive">
                    <table class="table mb-0">
                        <thead><tr><th>Data</th><th>Horário</th><th>Horas</th><th>Setor</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($solicitacoesHE as $h): ?>
                        <tr>
                            <td><?= formatarData($h['data_trabalhada']) ?></td>
                            <td><?= formatarHora($h['hora_entrada']) ?> – <?= formatarHora($h['hora_saida']) ?></td>
                            <td><?= number_format((float)$h['horas_extras'], 1) ?>h</td>
                            <td><?= htmlspecialchars($h['setor'] ?: '—') ?></td>
                            <td><span class="badge-status status-<?= $h['status'] === 'aprovada' ? 'concluida' : ($h['status'] === 'recusada' ? 'cancelada' : 'pendente') ?>"><?= ucfirst($h['status']) ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- Tabela de Registros -->
            <div class="table-wrapper">
                <div class="card-header">
                    <h5 class="card-title"><i class="bi bi-calendar3 me-2"></i>Registros — <?= date('F/Y', mktime(0,0,0,$mes,1,$ano)) ?></h5>
                </div>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Dia</th>
                                <th>Entrada</th>
                                <th>Saída</th>
                                <th>Horas</th>
                                <th>Extras</th>
                                <th>Atraso</th>
                                <th>Status</th>
                                <?php if (can('funcionarios.edit') || getNivelAcesso() === 'admin'): ?>
                                <th>Ações</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($registros)): ?>
                            <tr>
                                <td colspan="9" class="text-center" style="padding:40px;color:var(--text-muted)">
                                    <i class="bi bi-calendar-x" style="font-size:32px;display:block;margin-bottom:8px"></i>
                                    Nenhum registro neste período
                                </td>
                            </tr>
                            <?php else: ?>
                            <?php foreach ($registros as $r): ?>
                            <tr>
                                <td style="font-weight:600;color:var(--text-primary)"><?= formatarData($r['data']) ?></td>
                                <td style="font-size:12px;color:var(--text-muted)"><?= date('D', strtotime($r['data'])) ?></td>
                                <td style="color:var(--verde);font-weight:600"><?= formatarHora($r['entrada']) ?></td>
                                <td style="color:var(--vermelho);font-weight:600"><?= formatarHora($r['saida']) ?></td>
                                <td><?= $r['horas_trabalhadas'] > 0 ? number_format($r['horas_trabalhadas'],1).'h' : '-' ?></td>
                                <td style="color:var(--roxo-claro)"><?= $r['horas_extras'] > 0 ? '+'.number_format($r['horas_extras'],1).'h' : '-' ?></td>
                                <td style="color:var(--amarelo)"><?= $r['atraso'] > 0 ? number_format($r['atraso'],0).'min' : '-' ?></td>
                                <td><span class="badge-status status-<?= $r['status'] ?>"><?= ucfirst($r['status']) ?></span></td>
                                <?php if (can('funcionarios.edit') || getNivelAcesso() === 'admin'): ?>
                                <td>
                                    <button class="btn btn-outline btn-icon btn-sm" onclick="editarPonto(<?= htmlspecialchars(json_encode($r)) ?>)" title="Editar">
                                        <i class="bi bi-pencil-fill" style="color:var(--azul-claro)"></i>
                                    </button>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>

<!-- Modal Editar Ponto (RH/Admin) -->
<?php if (can('funcionarios.edit') || getNivelAcesso() === 'admin'): ?>
<div class="modal fade" id="modalPonto" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Editar Registro de Ponto</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" action="api/ponto_editar.php">
                <input type="hidden" name="id" id="pontoId">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label">Entrada</label>
                            <input type="time" name="entrada" id="pontoEntrada" class="form-control">
                        </div>
                        <div class="col-6">
                            <label class="form-label">Saída</label>
                            <input type="time" name="saida" id="pontoSaida" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Status</label>
                            <select name="status" id="pontoStatus" class="form-select">
                                <option value="presente">Presente</option>
                                <option value="ausente">Ausente</option>
                                <option value="falta">Falta</option>
                                <option value="ferias">Férias</option>
                                <option value="licenca">Licença</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observação</label>
                            <textarea name="observacao" id="pontoObs" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-check-lg"></i> Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (podeInformarFalta()): ?>
<div class="modal fade" id="modalFalta" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable modal-falta-dialog">
        <div class="modal-content modal-falta-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-calendar-x me-2"></i>Informar Falta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formFalta" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label">Data da falta *</label>
                            <input type="date" name="data_falta" id="faltaData" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Período *</label>
                            <select name="tipo_periodo" id="faltaPeriodo" class="form-select" required>
                                <option value="dia_inteiro">Dia inteiro</option>
                                <option value="meio_periodo">Meio período</option>
                                <option value="horario_especifico">Horário específico</option>
                            </select>
                        </div>
                        <div class="col-6 falta-horario d-none">
                            <label class="form-label">Hora início</label>
                            <input type="time" name="hora_inicio" id="faltaInicio" class="form-control">
                        </div>
                        <div class="col-6 falta-horario d-none">
                            <label class="form-label">Hora fim</label>
                            <input type="time" name="hora_fim" id="faltaFim" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Justificativa *</label>
                            <textarea name="justificativa" id="faltaJustificativa" class="form-control" rows="3" required placeholder="Descreva o motivo da ausência..."></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observações adicionais</label>
                            <textarea name="observacoes" id="faltaObs" class="form-control" rows="2"></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Comprovante (opcional)</label>
                            <input type="file" name="comprovante" id="faltaComprovante" class="form-control" accept=".jpg,.jpeg,.png,.pdf,.webp">
                        </div>
                    </div>
                </div>
                <div class="modal-footer modal-falta-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" data-no-loading="1"><i class="bi bi-send"></i> Enviar solicitação</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if (podeRegistrarHorasExtras()): ?>
<div class="modal fade" id="modalHorasExtras" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable modal-falta-dialog">
        <div class="modal-content modal-falta-content">
            <div class="modal-header">
                <h5 class="modal-title"><i class="bi bi-clock-history me-2"></i>Registrar Horas Extras</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formHorasExtras">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-12 col-md-6">
                            <label class="form-label">Dia trabalhado *</label>
                            <input type="date" name="data_trabalhada" id="heData" class="form-control" required>
                        </div>
                        <div class="col-12 col-md-6">
                            <label class="form-label">Setor *</label>
                            <input type="text" name="setor" id="heSetor" class="form-control" value="<?= htmlspecialchars($user['setor'] ?? '') ?>" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Entrada *</label>
                            <input type="time" name="hora_entrada" id="heEntrada" class="form-control" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Saída *</label>
                            <input type="time" name="hora_saida" id="heSaida" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Motivo / justificativa *</label>
                            <textarea name="motivo" id="heMotivo" class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Observações</label>
                            <textarea name="observacoes" id="heObs" class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer modal-falta-footer">
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" data-no-loading="1"><i class="bi bi-send"></i> Enviar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $extraJS = '<script>
// Relógio em tempo real
function atualizarRelogio() {
    const agora = new Date();
    const h = String(agora.getHours()).padStart(2,"0");
    const m = String(agora.getMinutes()).padStart(2,"0");
    const s = String(agora.getSeconds()).padStart(2,"0");
    const el = document.getElementById("relogioAtual");
    if (el) el.textContent = `${h}:${m}:${s}`;
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

function registrarPonto(tipo) {
    const btn = document.getElementById(tipo === "entrada" ? "btnEntrada" : "btnSaida");
    if (btn) { btn.disabled = true; btn.innerHTML = \'<span class="spinner-border spinner-border-sm"></span> Registrando...\'; }

    fetch("ponto.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
        body: "acao=" + tipo
    })
    .then(r => r.json())
    .then(d => {
        if (d.sucesso) {
            if (tipo === "entrada") {
                document.getElementById("horaEntrada").textContent = d.hora;
                if (btn) { btn.outerHTML = \'<button class="btn btn-danger" id="btnSaida" onclick="registrarPonto(\\\'saida\\\')"><i class="bi bi-box-arrow-right"></i> Registrar Saída</button>\'; }
            } else {
                document.getElementById("horaSaida").textContent = d.hora;
                if (btn) { btn.outerHTML = \'<div class="btn btn-outline" style="cursor:default"><i class="bi bi-check-circle-fill" style="color:var(--verde)"></i> Ponto Completo</div>\'; }
            }
            showToast(d.mensagem, "success");
        } else {
            showToast(d.erro, "danger");
            if (btn) { btn.disabled = false; btn.innerHTML = tipo === "entrada" ? \'<i class="bi bi-box-arrow-in-right"></i> Registrar Entrada\' : \'<i class="bi bi-box-arrow-right"></i> Registrar Saída\'; }
        }
    });
}

function editarPonto(r) {
    document.getElementById("pontoId").value = r.id;
    document.getElementById("pontoEntrada").value = r.entrada ? r.entrada.substring(0,5) : "";
    document.getElementById("pontoSaida").value = r.saida ? r.saida.substring(0,5) : "";
    document.getElementById("pontoStatus").value = r.status;
    document.getElementById("pontoObs").value = r.observacao || "";
    new bootstrap.Modal(document.getElementById("modalPonto")).show();
}

const formFalta = document.getElementById("formFalta");
if (formFalta) {
    document.getElementById("faltaPeriodo")?.addEventListener("change", function() {
        const show = this.value === "horario_especifico";
        document.querySelectorAll(".falta-horario").forEach(el => el.classList.toggle("d-none", !show));
    });
    formFalta.addEventListener("submit", function(e) {
        e.preventDefault();
        const fd = new FormData(formFalta);
        fd.append("acao", "criar");
        fetch("api/ponto_ausencia.php", { method: "POST", body: fd, credentials: "same-origin" })
            .then(r => r.json())
            .then(d => {
                if (d.sucesso) { showToast("Solicitação enviada!", "success"); location.reload(); }
                else showToast(d.erro || "Erro ao enviar.", "danger");
            });
    });
}

const formHE = document.getElementById("formHorasExtras");
if (formHE) {
    formHE.addEventListener("submit", function(e) {
        e.preventDefault();
        const fd = new FormData(formHE);
        fd.append("acao", "criar");
        fetch("api/horas_extras.php", { method: "POST", body: fd, credentials: "same-origin" })
            .then(r => r.json())
            .then(d => {
                if (d.sucesso) { showToast("Horas extras enviadas!", "success"); location.reload(); }
                else showToast(d.erro || "Erro.", "danger");
            });
    });
}

function aprovarHE(id, aprovar) {
    let motivo = "";
    if (!aprovar) motivo = prompt("Motivo da recusa (opcional):") || "";
    fetch("api/horas_extras.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ acao: aprovar ? "aprovar" : "recusar", id, motivo_recusa: motivo })
    })
    .then(r => r.json())
    .then(d => {
        if (d.sucesso) { showToast(aprovar ? "Aprovada!" : "Recusada.", "success"); location.reload(); }
        else showToast(d.erro || "Erro.", "danger");
    });
}

function aprovarFalta(id, aprovar) {
    let motivo = "";
    if (!aprovar) {
        motivo = prompt("Motivo da recusa (opcional):") || "";
    }
    fetch("api/ponto_ausencia.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "same-origin",
        body: JSON.stringify({ acao: aprovar ? "aprovar" : "recusar", id, motivo_recusa: motivo })
    })
    .then(r => r.json())
    .then(d => {
        if (d.sucesso) { showToast(aprovar ? "Aprovada!" : "Recusada.", "success"); location.reload(); }
        else showToast(d.erro || "Erro.", "danger");
    });
}
</script>'; ?>

<?php include 'includes/footer.php'; ?>
