<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Configurações';
$breadcrumb = 'Configurações';
$user = currentUser();
$pdo = db();

$mensagem = '';
$tipoMsg = '';

// Salvar configurações (apenas admin)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && hasPermission(['admin'])) {
    $campos = [
        'empresa_nome', 'empresa_cnpj', 'horario_entrada',
        'horario_saida', 'horas_diarias', 'tolerancia_atraso', 'valor_hora_extra'
    ];
    foreach ($campos as $campo) {
        if (isset($_POST[$campo])) {
            $valor = sanitize($_POST[$campo]);
            $pdo->prepare("UPDATE configuracoes SET valor=? WHERE chave=?")
                ->execute([$valor, $campo]);
        }
    }
    $mensagem = 'Configurações salvas com sucesso!';
    $tipoMsg = 'success';
    registrarLog('configuracoes', 'Configurações do sistema atualizadas');
}

// Buscar configurações
$stmt = $pdo->query("SELECT chave, valor FROM configuracoes");
$configs = [];
while ($row = $stmt->fetch()) {
    $configs[$row['chave']] = $row['valor'];
}

// Estatísticas do sistema
$totalUsers   = $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
$totalPonto   = $pdo->query("SELECT COUNT(*) FROM ponto")->fetchColumn();
$totalTarefas = $pdo->query("SELECT COUNT(*) FROM tarefas")->fetchColumn();
$totalMsgs    = $pdo->query("SELECT COUNT(*) FROM mensagens")->fetchColumn();
$totalLogs    = $pdo->query("SELECT COUNT(*) FROM logs_sistema")->fetchColumn();
$dbSize       = $pdo->query("SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size FROM information_schema.tables WHERE table_schema = 'os_tres_m'")->fetchColumn();

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <?php if ($mensagem): ?>
            <div class="alert alert-<?= $tipoMsg ?> fade-in mb-3">
                <i class="bi bi-check-circle-fill"></i> <?= htmlspecialchars($mensagem) ?>
            </div>
            <?php endif; ?>

            <div class="row g-4">

                <!-- Coluna Esquerda -->
                <div class="col-12 col-lg-8">

                    <!-- Configurações da Empresa -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-building me-2" style="color:var(--azul-claro)"></i>Dados da Empresa</h5>
                        </div>
                        <div class="card-body">
                            <?php if (hasPermission(['admin'])): ?>
                            <form method="POST">
                                <div class="row g-3">
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Nome da Empresa</label>
                                        <input type="text" name="empresa_nome" class="form-control"
                                               value="<?= htmlspecialchars($configs['empresa_nome'] ?? '') ?>">
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">CNPJ</label>
                                        <input type="text" name="empresa_cnpj" class="form-control"
                                               value="<?= htmlspecialchars($configs['empresa_cnpj'] ?? '') ?>"
                                               placeholder="00.000.000/0001-00">
                                    </div>
                                    <div class="col-12"><hr style="border-color:var(--border-color)"></div>
                                    <div class="col-12">
                                        <h6 style="color:var(--text-secondary);font-size:13px;font-weight:700;margin-bottom:12px">
                                            <i class="bi bi-clock me-1"></i> Controle de Ponto
                                        </h6>
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <label class="form-label">Horário Entrada</label>
                                        <input type="time" name="horario_entrada" class="form-control"
                                               value="<?= htmlspecialchars($configs['horario_entrada'] ?? '08:00') ?>">
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <label class="form-label">Horário Saída</label>
                                        <input type="time" name="horario_saida" class="form-control"
                                               value="<?= htmlspecialchars($configs['horario_saida'] ?? '17:00') ?>">
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <label class="form-label">Horas/Dia</label>
                                        <input type="number" name="horas_diarias" class="form-control" min="1" max="24"
                                               value="<?= htmlspecialchars($configs['horas_diarias'] ?? '8') ?>">
                                    </div>
                                    <div class="col-6 col-md-3">
                                        <label class="form-label">Tolerância (min)</label>
                                        <input type="number" name="tolerancia_atraso" class="form-control" min="0" max="60"
                                               value="<?= htmlspecialchars($configs['tolerancia_atraso'] ?? '10') ?>">
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <label class="form-label">Multiplicador Hora Extra</label>
                                        <input type="number" name="valor_hora_extra" class="form-control" step="0.1" min="1" max="3"
                                               value="<?= htmlspecialchars($configs['valor_hora_extra'] ?? '1.5') ?>">
                                        <div class="form-text" style="color:var(--text-muted);font-size:11px">Ex: 1.5 = 50% a mais</div>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-check-lg"></i> Salvar Configurações
                                        </button>
                                    </div>
                                </div>
                            </form>
                            <?php else: ?>
                            <div class="row g-3">
                                <?php foreach ($configs as $k => $v): ?>
                                <div class="col-6 col-md-4">
                                    <div style="background:var(--bg-secondary);border-radius:8px;padding:12px">
                                        <div style="font-size:11px;color:var(--text-muted);margin-bottom:4px;text-transform:uppercase;letter-spacing:0.5px"><?= str_replace('_',' ',ucfirst($k)) ?></div>
                                        <div style="font-size:14px;font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($v) ?></div>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Preferências Pessoais -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-palette me-2" style="color:var(--roxo-claro)"></i>Preferências Visuais</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label">Tema do Sistema</label>
                                    <div class="d-flex gap-3 mt-1">
                                        <label class="d-flex align-items-center gap-2" style="cursor:pointer">
                                            <div style="width:40px;height:40px;background:#0F1117;border-radius:8px;border:2px solid var(--border-color)" id="themeDark" onclick="setTheme('dark')"></div>
                                            <span style="font-size:13px;color:var(--text-secondary)">Escuro</span>
                                        </label>
                                        <label class="d-flex align-items-center gap-2" style="cursor:pointer">
                                            <div style="width:40px;height:40px;background:#F1F5F9;border-radius:8px;border:2px solid var(--border-color)" id="themeLight" onclick="setTheme('light')"></div>
                                            <span style="font-size:13px;color:var(--text-secondary)">Claro</span>
                                        </label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">Notificações no Navegador</label>
                                    <div class="d-flex align-items-center gap-3 mt-1">
                                        <button class="btn btn-outline btn-sm" onclick="solicitarNotificacoes()">
                                            <i class="bi bi-bell"></i> Ativar Notificações
                                        </button>
                                        <span id="notifStatus" style="font-size:12px;color:var(--text-muted)">Status: verificando...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Segurança -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-shield-check me-2" style="color:var(--verde)"></i>Segurança da Conta</h5>
                        </div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-12">
                                    <div class="d-flex align-items-center justify-content-between p-3"
                                         style="background:var(--bg-secondary);border-radius:10px">
                                        <div>
                                            <div style="font-weight:600;color:var(--text-primary);font-size:14px">Sessões Ativas</div>
                                            <div style="font-size:12px;color:var(--text-muted)">Gerencie onde você está conectado</div>
                                        </div>
                                        <a href="api/logout.php" class="btn btn-danger btn-sm">
                                            <i class="bi bi-box-arrow-left"></i> Encerrar Sessão
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="d-flex align-items-center justify-content-between p-3"
                                         style="background:var(--bg-secondary);border-radius:10px">
                                        <div>
                                            <div style="font-weight:600;color:var(--text-primary);font-size:14px">Alterar Senha</div>
                                            <div style="font-size:12px;color:var(--text-muted)">Recomendamos trocar periodicamente</div>
                                        </div>
                                        <a href="perfil.php#senha" class="btn btn-outline btn-sm">
                                            <i class="bi bi-lock"></i> Alterar
                                        </a>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="d-flex align-items-center justify-content-between p-3"
                                         style="background:var(--bg-secondary);border-radius:10px">
                                        <div>
                                            <div style="font-weight:600;color:var(--text-primary);font-size:14px">Último Acesso</div>
                                            <div style="font-size:12px;color:var(--text-muted)">
                                                <?php
                                                $ua = $pdo->prepare("SELECT ultimo_acesso FROM usuarios WHERE id=?");
                                                $ua->execute([$user['id']]);
                                                $ultimo = $ua->fetchColumn();
                                                echo $ultimo ? formatarDataHora($ultimo) : 'Primeiro acesso';
                                                ?>
                                            </div>
                                        </div>
                                        <span class="badge-status status-ativo">Seguro</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Coluna Direita -->
                <div class="col-12 col-lg-4">

                    <!-- Info do Sistema -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-info-circle me-2" style="color:var(--azul-claro)"></i>Informações do Sistema</h5>
                        </div>
                        <div class="card-body" style="padding:0">
                            <?php
                            $infos = [
                                ['label'=>'Versão','value'=>'1.0.0','icon'=>'tag','color'=>'var(--azul-claro)'],
                                ['label'=>'PHP','value'=>phpversion(),'icon'=>'code-slash','color'=>'var(--roxo-claro)'],
                                ['label'=>'Banco de Dados','value'=>'MySQL','icon'=>'database','color'=>'var(--verde)'],
                                ['label'=>'Tamanho do BD','value'=>($dbSize ?? '0').' MB','icon'=>'hdd','color'=>'var(--amarelo)'],
                                ['label'=>'Servidor','value'=>$_SERVER['SERVER_SOFTWARE'] ?? 'Apache/XAMPP','icon'=>'server','color'=>'var(--text-muted)'],
                            ];
                            foreach ($infos as $info):
                            ?>
                            <div class="d-flex align-items-center gap-3 p-3"
                                 style="border-bottom:1px solid var(--border-color)">
                                <div style="width:32px;height:32px;border-radius:8px;background:rgba(255,255,255,0.05);display:flex;align-items:center;justify-content:center;color:<?= $info['color'] ?>;font-size:14px;flex-shrink:0">
                                    <i class="bi bi-<?= $info['icon'] ?>"></i>
                                </div>
                                <div style="flex:1">
                                    <div style="font-size:11px;color:var(--text-muted)"><?= $info['label'] ?></div>
                                    <div style="font-size:13px;font-weight:600;color:var(--text-primary)"><?= htmlspecialchars($info['value']) ?></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Estatísticas do BD -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-bar-chart me-2" style="color:var(--verde)"></i>Estatísticas</h5>
                        </div>
                        <div class="card-body">
                            <?php
                            $stats = [
                                ['label'=>'Usuários','value'=>$totalUsers,'icon'=>'people','color'=>'var(--azul-claro)'],
                                ['label'=>'Registros de Ponto','value'=>$totalPonto,'icon'=>'clock','color'=>'var(--verde)'],
                                ['label'=>'Tarefas','value'=>$totalTarefas,'icon'=>'check2-square','color'=>'var(--amarelo)'],
                                ['label'=>'Mensagens','value'=>$totalMsgs,'icon'=>'chat-dots','color'=>'var(--roxo-claro)'],
                                ['label'=>'Logs do Sistema','value'=>$totalLogs,'icon'=>'journal','color'=>'var(--text-muted)'],
                            ];
                            foreach ($stats as $s):
                            ?>
                            <div class="d-flex align-items-center justify-content-between mb-3">
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-<?= $s['icon'] ?>" style="color:<?= $s['color'] ?>;font-size:15px"></i>
                                    <span style="font-size:13px;color:var(--text-secondary)"><?= $s['label'] ?></span>
                                </div>
                                <span style="font-size:14px;font-weight:700;color:var(--text-primary)"><?= number_format($s['value']) ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Ações Admin -->
                    <?php if (hasPermission(['admin'])): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-tools me-2" style="color:var(--vermelho)"></i>Ferramentas Admin</h5>
                        </div>
                        <div class="card-body d-flex flex-column gap-2">
                            <a href="logs.php" class="btn btn-outline w-100 justify-content-start">
                                <i class="bi bi-journal-text" style="color:var(--azul-claro)"></i> Ver Logs do Sistema
                            </a>
                            <a href="relatorios.php" class="btn btn-outline w-100 justify-content-start">
                                <i class="bi bi-bar-chart" style="color:var(--verde)"></i> Relatórios Completos
                            </a>
                            <button class="btn btn-outline w-100 justify-content-start" onclick="limparOnline()">
                                <i class="bi bi-wifi-off" style="color:var(--amarelo)"></i> Resetar Status Online
                            </button>
                            <button class="btn btn-danger w-100 justify-content-start" onclick="confirmarLimparLogs()"
                                    data-confirm="Tem certeza? Esta ação não pode ser desfeita.">
                                <i class="bi bi-trash"></i> Limpar Logs Antigos
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>

                </div>
            </div>

        </div>
    </div>
</div>

<?php $extraJS = '<script>
function setTheme(theme) {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    const dark = document.getElementById("themeDark");
    const light = document.getElementById("themeLight");
    if (dark) dark.style.borderColor = theme === "dark" ? "var(--azul-principal)" : "var(--border-color)";
    if (light) light.style.borderColor = theme === "light" ? "var(--azul-principal)" : "var(--border-color)";
}

// Marcar tema atual
const currentTheme = localStorage.getItem("theme") || "dark";
setTheme(currentTheme);

function solicitarNotificacoes() {
    if (!("Notification" in window)) {
        document.getElementById("notifStatus").textContent = "Status: não suportado neste navegador";
        return;
    }
    Notification.requestPermission().then(p => {
        document.getElementById("notifStatus").textContent = "Status: " + (p === "granted" ? "✅ Ativado" : "❌ Negado");
    });
}

// Verificar status atual
if ("Notification" in window) {
    const p = Notification.permission;
    document.getElementById("notifStatus").textContent = "Status: " + (p === "granted" ? "✅ Ativado" : p === "denied" ? "❌ Negado" : "⚠️ Pendente");
}

function limparOnline() {
    fetch("api/admin_tools.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({acao: "reset_online"})
    }).then(r => r.json()).then(d => showToast(d.mensagem || "Feito!", "success"));
}

function confirmarLimparLogs() {
    if (!confirm("Limpar logs com mais de 30 dias? Esta ação não pode ser desfeita.")) return;
    fetch("api/admin_tools.php", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({acao: "limpar_logs"})
    }).then(r => r.json()).then(d => showToast(d.mensagem || "Logs limpos!", "success"));
}
</script>'; ?>

<?php include 'includes/footer.php'; ?>
