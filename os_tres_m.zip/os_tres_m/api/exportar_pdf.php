<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['rh','admin','gerente','coordenacao']);

$tipo = sanitize($_GET['tipo'] ?? 'funcionarios');
$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$pdo = db();

$titulos = [
    'funcionarios' => 'Relatório de Funcionários',
    'ponto' => 'Relatório de Ponto',
    'presenca' => 'Relatório de Presença',
    'pagamento' => 'Relatório de Pagamento',
    'tarefas' => 'Relatório de Tarefas',
    'produtividade' => 'Relatório de Produtividade',
];

$titulo = $titulos[$tipo] ?? 'Relatório';
$periodo = date('F/Y', mktime(0,0,0,$mes,1,$ano));

// Gerar HTML para impressão (sem biblioteca externa)
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title><?= $titulo ?></title>
<style>
  body { font-family: Arial, sans-serif; font-size: 12px; color: #333; margin: 20px; }
  h1 { font-size: 18px; color: #1E3A8A; border-bottom: 2px solid #2563EB; padding-bottom: 8px; }
  .header { display: flex; justify-content: space-between; margin-bottom: 20px; }
  .empresa { font-size: 14px; font-weight: bold; color: #1E3A8A; }
  table { width: 100%; border-collapse: collapse; margin-top: 16px; }
  th { background: #1E3A8A; color: white; padding: 8px; text-align: left; font-size: 11px; }
  td { padding: 7px 8px; border-bottom: 1px solid #e5e7eb; }
  tr:nth-child(even) { background: #f9fafb; }
  .footer { margin-top: 24px; font-size: 11px; color: #6b7280; text-align: center; }
  @media print { body { margin: 0; } }
</style>
</head>
<body onload="window.print()">
<div class="header">
  <div>
    <div class="empresa">Os Três M — Sistema Empresarial</div>
    <div><?= $titulo ?> — <?= $periodo ?></div>
  </div>
  <div style="text-align:right">
    <div>Gerado em: <?= date('d/m/Y H:i') ?></div>
    <div>Por: <?= htmlspecialchars(currentUser()['nome']) ?></div>
  </div>
</div>

<?php
switch ($tipo) {
    case 'funcionarios':
        $dados = $pdo->query("SELECT * FROM usuarios ORDER BY nome")->fetchAll();
        echo '<table><thead><tr><th>#</th><th>Nome</th><th>E-mail</th><th>CPF</th><th>Cargo</th><th>Setor</th><th>Status</th></tr></thead><tbody>';
        foreach ($dados as $i=>$d) {
            echo "<tr><td>".($i+1)."</td><td>".htmlspecialchars($d['nome'])."</td><td>".htmlspecialchars($d['email'])."</td><td>".htmlspecialchars($d['cpf'])."</td><td>".htmlspecialchars($d['cargo'])."</td><td>".htmlspecialchars($d['setor'])."</td><td>".ucfirst($d['status'])."</td></tr>";
        }
        echo '</tbody></table>';
        break;
    case 'ponto':
        $dados = $pdo->query("SELECT p.*,u.nome FROM ponto p JOIN usuarios u ON p.usuario_id=u.id WHERE MONTH(p.data)=$mes AND YEAR(p.data)=$ano ORDER BY u.nome,p.data")->fetchAll();
        echo '<table><thead><tr><th>Funcionário</th><th>Data</th><th>Entrada</th><th>Saída</th><th>Horas</th><th>Status</th></tr></thead><tbody>';
        foreach ($dados as $d) {
            echo "<tr><td>".htmlspecialchars($d['nome'])."</td><td>".formatarData($d['data'])."</td><td>".formatarHora($d['entrada'])."</td><td>".formatarHora($d['saida'])."</td><td>".number_format($d['horas_trabalhadas'],1)."h</td><td>".ucfirst($d['status'])."</td></tr>";
        }
        echo '</tbody></table>';
        break;
    case 'pagamento':
        $dados = $pdo->query("SELECT fp.*,u.nome FROM folha_pagamento fp JOIN usuarios u ON fp.usuario_id=u.id WHERE fp.mes=$mes AND fp.ano=$ano ORDER BY u.nome")->fetchAll();
        $total = array_sum(array_column($dados,'valor_final'));
        echo '<table><thead><tr><th>Funcionário</th><th>Salário Base</th><th>H.Extras</th><th>Benefícios</th><th>Descontos</th><th>Valor Final</th><th>Status</th></tr></thead><tbody>';
        foreach ($dados as $d) {
            echo "<tr><td>".htmlspecialchars($d['nome'])."</td><td>".formatarMoeda($d['salario_base'])."</td><td>".formatarMoeda($d['horas_extras_valor'])."</td><td>".formatarMoeda($d['beneficios'])."</td><td>".formatarMoeda($d['descontos'])."</td><td><strong>".formatarMoeda($d['valor_final'])."</strong></td><td>".ucfirst($d['status'])."</td></tr>";
        }
        echo "<tr style='background:#dbeafe'><td colspan='5'><strong>TOTAL</strong></td><td><strong>".formatarMoeda($total)."</strong></td><td></td></tr>";
        echo '</tbody></table>';
        break;
}
?>
<div class="footer">Os Três M — Sistema Empresarial | Documento gerado automaticamente</div>
</body>
</html>
