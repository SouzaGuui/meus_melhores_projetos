<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';

if (isLoggedIn()) {
    atualizarOnline($_SESSION['usuario_id'], 1);
}
http_response_code(204);
exit;
