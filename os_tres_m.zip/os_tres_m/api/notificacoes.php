<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';

// Tratamento de erros
try {
    requireLogin();

    $user = currentUser();
    $pdo = db();
    $acao = $_GET['acao'] ?? $_POST['acao'] ?? '';

    if ($acao === 'marcar_lida') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id > 0) {
            $pdo->prepare("UPDATE notificacoes SET lida=1 WHERE id=? AND usuario_id=?")->execute([$id, $user['id']]);
        }
        jsonResponse(['sucesso' => true]);
    }

    if ($acao === 'marcar_todas') {
        $pdo->prepare("UPDATE notificacoes SET lida=1 WHERE usuario_id=?")->execute([$user['id']]);
        jsonResponse(['sucesso' => true]);
    }

    if ($acao === 'contar') {
        $total = contarNotificacoes($user['id']);
        jsonResponse(['total' => $total]);
    }

    jsonResponse(['erro' => 'Ação inválida.'], 400);
} catch (Exception $e) {
    jsonResponse(['erro' => 'Erro ao processar solicitação.'], 500);
}
