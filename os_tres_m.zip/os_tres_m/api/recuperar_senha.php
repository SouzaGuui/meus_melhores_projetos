<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';

$data = json_decode(file_get_contents('php://input'), true);
$email = sanitize($data['email'] ?? '');
$pdo = db();

if (!validarEmail($email)) {
    jsonResponse(['mensagem' => 'E-mail inválido.']);
}

$stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email=? AND status='ativo'");
$stmt->execute([$email]);
$usuario = $stmt->fetch();

// Sempre retornar mensagem genérica por segurança
if ($usuario) {
    $token = bin2hex(random_bytes(32));
    $expiracao = date('Y-m-d H:i:s', strtotime('+1 hour'));
    $pdo->prepare("UPDATE usuarios SET token_recuperacao=?, token_expiracao=? WHERE id=?")->execute([$token, $expiracao, $usuario['id']]);
    // Em produção: enviar e-mail com link de recuperação
    // mail($email, 'Recuperação de Senha', BASE_URL . 'redefinir_senha.php?token=' . $token);
    registrarLog('recuperar_senha', "Solicitação de recuperação para: $email");
}

jsonResponse(['mensagem' => 'Se o e-mail estiver cadastrado, você receberá as instruções em breve.']);
