<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!can('chat.use')) {
    jsonResponse(['mensagens' => []]);
}

$conversaId = (int)($_GET['conversa_id'] ?? 0);
$ultimaId = (int)($_GET['ultima_id'] ?? 0);
$user = currentUser();
$pdo = db();

if (!$conversaId) {
    jsonResponse(['mensagens' => []]);
}

$stmt = $pdo->prepare('SELECT id FROM conversas WHERE id = ? AND (usuario1_id = ? OR usuario2_id = ?)');
$stmt->execute([$conversaId, $user['id'], $user['id']]);
if (!$stmt->fetch()) {
    jsonResponse(['erro' => 'Acesso negado.'], 403);
}

$stmt = $pdo->prepare('
    SELECT m.id, m.mensagem, m.remetente_id, m.lida, m.criado_em, u.nome as remetente_nome
    FROM mensagens m
    JOIN usuarios u ON m.remetente_id = u.id
    WHERE m.conversa_id = ? AND m.id > ?
    ORDER BY m.criado_em ASC
');
$stmt->execute([$conversaId, $ultimaId]);
$msgs = $stmt->fetchAll();

if (!empty($msgs)) {
    $pdo->prepare('UPDATE mensagens SET lida = 1 WHERE conversa_id = ? AND remetente_id != ?')
        ->execute([$conversaId, $user['id']]);
}

$result = [];
foreach ($msgs as $m) {
    $result[] = [
        'id' => (int)$m['id'],
        'mensagem' => $m['mensagem'],
        'remetente_id' => (int)$m['remetente_id'],
        'remetente_nome' => $m['remetente_nome'],
        'lida' => (int)$m['lida'],
        'hora' => date('H:i', strtotime($m['criado_em'])),
        'status' => (int)$m['lida'] ? 'lida' : 'recebida',
    ];
}

// Atualizar status de leitura das mensagens enviadas pelo usuário atual
$statusLidas = [];
$stStatus = $pdo->prepare('
    SELECT id FROM mensagens
    WHERE conversa_id = ? AND remetente_id = ? AND lida = 1
');
$stStatus->execute([$conversaId, $user['id']]);
foreach ($stStatus->fetchAll() as $sl) {
    $statusLidas[] = ['id' => (int)$sl['id']];
}

jsonResponse(['mensagens' => $result, 'status_lidas' => $statusLidas]);
