<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

$conversaId = (int)($_GET['conversa_id'] ?? 0);
$ultimaId = (int)($_GET['ultima_id'] ?? 0);
$user = currentUser();
$pdo = db();

if (!$conversaId) jsonResponse(['mensagens' => []]);

// Verificar acesso
$stmt = $pdo->prepare("SELECT id FROM conversas WHERE id=? AND (usuario1_id=? OR usuario2_id=?)");
$stmt->execute([$conversaId, $user['id'], $user['id']]);
if (!$stmt->fetch()) jsonResponse(['mensagens' => []]);

// Buscar novas mensagens
$stmt = $pdo->prepare("
    SELECT m.id, m.mensagem, m.remetente_id, m.criado_em,
           u.nome as remetente_nome
    FROM mensagens m
    JOIN usuarios u ON m.remetente_id = u.id
    WHERE m.conversa_id = ? AND m.id > ? AND m.remetente_id != ?
    ORDER BY m.criado_em ASC
");
$stmt->execute([$conversaId, $ultimaId, $user['id']]);
$msgs = $stmt->fetchAll();

// Marcar como lidas
if (!empty($msgs)) {
    $pdo->prepare("UPDATE mensagens SET lida=1 WHERE conversa_id=? AND remetente_id!=?")->execute([$conversaId, $user['id']]);
}

$result = array_map(function($m) {
    return [
        'id' => $m['id'],
        'mensagem' => htmlspecialchars($m['mensagem']),
        'remetente_id' => $m['remetente_id'],
        'remetente_nome' => $m['remetente_nome'],
        'hora' => date('H:i', strtotime($m['criado_em']))
    ];
}, $msgs);

jsonResponse(['mensagens' => $result]);
