<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!can('chat.use')) {
    jsonResponse(['erro' => 'Sem permissão para usar o chat.'], 403);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    $data = $_POST;
}

$conversaId = (int)($data['conversa_id'] ?? 0);
$mensagem = trim($data['mensagem'] ?? '');
$user = currentUser();
$pdo = db();

if (!$conversaId || $mensagem === '') {
    jsonResponse(['erro' => 'Dados inválidos.'], 400);
}

if (mb_strlen($mensagem) > 5000) {
    jsonResponse(['erro' => 'Mensagem muito longa.'], 400);
}

$stmt = $pdo->prepare('SELECT * FROM conversas WHERE id = ? AND (usuario1_id = ? OR usuario2_id = ?)');
$stmt->execute([$conversaId, $user['id'], $user['id']]);
$conversa = $stmt->fetch();

if (!$conversa) {
    jsonResponse(['erro' => 'Conversa não encontrada ou acesso negado.'], 403);
}

try {
    $pdo->beginTransaction();

    $pdo->prepare('INSERT INTO mensagens (conversa_id, remetente_id, mensagem, lida) VALUES (?, ?, ?, 0)')
        ->execute([$conversaId, $user['id'], $mensagem]);
    $msgId = (int)$pdo->lastInsertId();

    $preview = mb_substr($mensagem, 0, 100);
    $pdo->prepare('UPDATE conversas SET ultima_mensagem = ?, ultima_mensagem_em = NOW() WHERE id = ?')
        ->execute([$preview, $conversaId]);

    $pdo->commit();
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    jsonResponse(['erro' => 'Erro ao salvar mensagem.'], 500);
}

$outroId = (int)($conversa['usuario1_id'] == $user['id'] ? $conversa['usuario2_id'] : $conversa['usuario1_id']);
criarNotificacao(
    $outroId,
    'Nova mensagem',
    $user['nome'] . ': ' . mb_substr($mensagem, 0, 50),
    'chat',
    'chat.php?conversa=' . $conversaId
);

jsonResponse([
    'sucesso' => true,
    'mensagem' => [
        'id' => $msgId,
        'mensagem' => $mensagem,
        'remetente_id' => (int)$user['id'],
        'lida' => 0,
        'hora' => date('H:i'),
        'status' => 'enviada',
    ],
]);
