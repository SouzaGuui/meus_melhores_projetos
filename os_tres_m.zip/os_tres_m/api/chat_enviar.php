<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

$data = json_decode(file_get_contents('php://input'), true);
$conversaId = (int)($data['conversa_id'] ?? 0);
$mensagem = trim($data['mensagem'] ?? '');
$user = currentUser();
$pdo = db();

if (!$conversaId || !$mensagem) {
    jsonResponse(['erro' => 'Dados inválidos.'], 400);
}

// Verificar acesso
$stmt = $pdo->prepare("SELECT * FROM conversas WHERE id=? AND (usuario1_id=? OR usuario2_id=?)");
$stmt->execute([$conversaId, $user['id'], $user['id']]);
$conversa = $stmt->fetch();

if (!$conversa) {
    jsonResponse(['erro' => 'Acesso negado.'], 403);
}

// Inserir mensagem
$pdo->prepare("INSERT INTO mensagens (conversa_id, remetente_id, mensagem) VALUES (?,?,?)")
    ->execute([$conversaId, $user['id'], $mensagem]);
$msgId = $pdo->lastInsertId();

// Atualizar última mensagem
$pdo->prepare("UPDATE conversas SET ultima_mensagem=?, ultima_mensagem_em=NOW() WHERE id=?")
    ->execute([substr($mensagem, 0, 100), $conversaId]);

// Notificar destinatário
$outroId = $conversa['usuario1_id'] == $user['id'] ? $conversa['usuario2_id'] : $conversa['usuario1_id'];
criarNotificacao($outroId, 'Nova mensagem', htmlspecialchars($user['nome']) . ': ' . substr($mensagem, 0, 50), 'chat', 'chat.php?conversa=' . $conversaId);

jsonResponse([
    'sucesso' => true,
    'mensagem' => [
        'id' => $msgId,
        'mensagem' => htmlspecialchars($mensagem),
        'remetente_id' => $user['id'],
        'hora' => date('H:i')
    ]
]);
