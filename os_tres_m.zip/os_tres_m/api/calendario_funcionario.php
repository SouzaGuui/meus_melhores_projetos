<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!can('calendario.view')) {
    jsonResponse(['erro' => 'Sem permissão.'], 403);
}

$user = currentUser();
$pdo = db();
$nivel = getNivelAcesso();
$setor = $user['setor'] ?? '';

$funcionarioId = (int)($_GET['usuario_id'] ?? 0);
$mes = (int)($_GET['mes'] ?? date('n'));
$ano = (int)($_GET['ano'] ?? date('Y'));

if ($funcionarioId <= 0) {
    jsonResponse(['erro' => 'Funcionário inválido.'], 400);
}

if ($nivel === 'funcionario' && $funcionarioId !== (int)$user['id']) {
    jsonResponse(['erro' => 'Você só pode ver seu próprio calendário.'], 403);
}

$stmt = $pdo->prepare('SELECT id, nome, cargo, setor, foto_perfil, nivel_acesso, online FROM usuarios WHERE id = ? AND status = ?');
$stmt->execute([$funcionarioId, 'ativo']);
$funcionario = $stmt->fetch();
if (!$funcionario) {
    jsonResponse(['erro' => 'Funcionário não encontrado.'], 404);
}

if (($funcionario['nivel_acesso'] ?? '') === 'admin' && $nivel !== 'admin' && !can('*')) {
    jsonResponse(['erro' => 'Acesso negado.'], 403);
}

if (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor && ($funcionario['setor'] ?? '') !== $setor) {
    jsonResponse(['erro' => 'Acesso negado a este funcionário.'], 403);
}

$inicio = sprintf('%04d-%02d-01', $ano, $mes);
$fim = date('Y-m-t', strtotime($inicio));

$st = $pdo->prepare('
    SELECT data, status, entrada, saida, atraso, horas_trabalhadas, horas_extras, observacao
    FROM ponto WHERE usuario_id = ? AND data BETWEEN ? AND ?
    ORDER BY data
');
$st->execute([$funcionarioId, $inicio, $fim]);
$pontos = $st->fetchAll(PDO::FETCH_ASSOC);

$st = $pdo->prepare("
    SELECT id, titulo, prazo, status, prioridade
    FROM tarefas
    WHERE atribuido_para = ? AND prazo IS NOT NULL
      AND prazo BETWEEN ? AND ? AND status != 'cancelada'
    ORDER BY prazo
");
$st->execute([$funcionarioId, $inicio, $fim]);
$tarefas = $st->fetchAll(PDO::FETCH_ASSOC);

$st = $pdo->prepare("
    SELECT id, titulo, tipo, data_inicio, data_fim, descricao, dia_inteiro
    FROM calendario_eventos
    WHERE (usuario_id = ? OR visibilidade = 'empresa')
      AND data_inicio <= ? AND (data_fim IS NULL OR data_fim >= ?)
    ORDER BY data_inicio
");
$st->execute([$funcionarioId, $fim . ' 23:59:59', $inicio . ' 00:00:00']);
$eventos = $st->fetchAll(PDO::FETCH_ASSOC);

$ausencias = [];
try {
    garantirTabelaPontoAusencias();
    $stA = $pdo->prepare("SELECT * FROM ponto_ausencias WHERE usuario_id = ? AND data_falta BETWEEN ? AND ?");
    $stA->execute([$funcionarioId, $inicio, $fim]);
    $ausencias = $stA->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { /* opcional */ }

$solicitacoesHe = [];
try {
    garantirTabelaHorasExtras();
    $stHe = $pdo->prepare("SELECT * FROM horas_extras_solicitacoes WHERE usuario_id = ? AND data_trabalhada BETWEEN ? AND ?");
    $stHe->execute([$funcionarioId, $inicio, $fim]);
    $solicitacoesHe = $stHe->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { /* opcional */ }

$resumo = [
    'presentes' => 0,
    'faltas' => 0,
    'atrasos' => 0,
    'ferias' => 0,
    'ausentes' => 0,
    'horas_extras' => 0,
    'horas_trabalhadas' => 0,
    'banco_horas' => 0,
    'tarefas_concluidas' => 0,
    'tarefas_total' => count($tarefas),
    'taxa_presenca' => 0,
];

foreach ($tarefas as $t) {
    if ($t['status'] === 'concluida') {
        $resumo['tarefas_concluidas']++;
    }
}

$dias = [];
foreach ($pontos as $p) {
    $cor = '#64748B';
    $tipoDia = 'ausente';
    if ($p['status'] === 'ferias') {
        $cor = '#3B82F6';
        $tipoDia = 'ferias';
        $resumo['ferias']++;
    } elseif ($p['status'] === 'falta') {
        $cor = '#EF4444';
        $tipoDia = 'falta';
        $resumo['faltas']++;
    } elseif ((float)$p['atraso'] > 0) {
        $cor = '#F59E0B';
        $tipoDia = 'atrasado';
        $resumo['atrasos']++;
        $resumo['presentes']++;
    } elseif ($p['status'] === 'presente') {
        $cor = '#10B981';
        $tipoDia = 'presente';
        $resumo['presentes']++;
    } else {
        $resumo['ausentes']++;
    }

    $heDia = (float)$p['horas_extras'];
    $resumo['horas_extras'] += $heDia;
    $resumo['horas_trabalhadas'] += (float)$p['horas_trabalhadas'];

    $dias[$p['data']] = [
        'data' => $p['data'],
        'status' => $p['status'],
        'tipo_dia' => $tipoDia,
        'cor' => $cor,
        'entrada' => $p['entrada'] ? substr($p['entrada'], 0, 5) : null,
        'saida' => $p['saida'] ? substr($p['saida'], 0, 5) : null,
        'atraso' => (float)$p['atraso'],
        'horas' => (float)$p['horas_trabalhadas'],
        'horas_extras' => $heDia,
        'observacao' => $p['observacao'],
        'eventos' => [],
    ];
}

foreach ($ausencias as $a) {
    $dia = $a['data_falta'];
    if (!isset($dias[$dia])) {
        $dias[$dia] = ['data' => $dia, 'tipo_dia' => 'falta', 'cor' => '#EF4444', 'eventos' => []];
    }
    $dias[$dia]['ausencia'] = $a;
    if (($a['status'] ?? '') === 'aprovada') {
        $dias[$dia]['cor'] = '#EF4444';
        $dias[$dia]['tipo_dia'] = 'falta';
    }
}

foreach ($solicitacoesHe as $h) {
    $dia = $h['data_trabalhada'];
    if (!isset($dias[$dia])) {
        $dias[$dia] = ['data' => $dia, 'eventos' => []];
    }
    $dias[$dia]['horas_extra_sol'] = $h;
    if (($h['status'] ?? '') === 'aprovada') {
        $dias[$dia]['cor'] = '#F97316';
        $dias[$dia]['tipo_dia'] = 'hora_extra';
    } elseif (($h['status'] ?? '') === 'pendente') {
        $dias[$dia]['cor'] = '#FB923C';
    }
}

foreach ($eventos as $e) {
    $dia = substr($e['data_inicio'], 0, 10);
    if (!isset($dias[$dia])) {
        $dias[$dia] = ['data' => $dia, 'eventos' => []];
    }
    $dias[$dia]['eventos'][] = $e;
    $tipoEv = $e['tipo'] ?? 'evento';
    if (in_array($tipoEv, ['reuniao', 'evento', 'comemorativo'], true)) {
        $dias[$dia]['cor'] = '#7C3AED';
        $dias[$dia]['tipo_dia'] = 'evento';
    } elseif ($tipoEv === 'ferias' || $tipoEv === 'folga') {
        $dias[$dia]['cor'] = '#3B82F6';
        $dias[$dia]['tipo_dia'] = 'ferias';
    } elseif ($tipoEv === 'escala') {
        $dias[$dia]['cor'] = '#06B6D4';
    }
}

foreach ($tarefas as $t) {
    $dia = substr($t['prazo'], 0, 10);
    if ($dia >= $inicio && $dia <= $fim) {
        if (!isset($dias[$dia])) {
            $dias[$dia] = ['data' => $dia, 'eventos' => []];
        }
        $dias[$dia]['tarefas'][] = $t;
        if (empty($dias[$dia]['cor']) || $dias[$dia]['cor'] === '#64748B') {
            $dias[$dia]['cor'] = '#7C3AED';
        }
    }
}

$totalDiasUteis = max(1, $resumo['presentes'] + $resumo['faltas'] + $resumo['atrasos'] + $resumo['ausentes']);
$resumo['taxa_presenca'] = round(($resumo['presentes'] / $totalDiasUteis) * 100);

foreach ($solicitacoesHe as $h) {
    if ($h['status'] === 'aprovada') {
        $resumo['banco_horas'] += (float)$h['horas_extras'];
    }
}
$resumo['banco_horas'] = round($resumo['banco_horas'] + $resumo['horas_extras'], 1);
$resumo['horas_extras'] = round($resumo['horas_extras'], 1);
$resumo['horas_trabalhadas'] = round($resumo['horas_trabalhadas'], 1);

// Resumo semanal (4-5 semanas do mês)
$semanal = [];
$semanaAtual = [];
$diaSemana = 0;
$ultimoDia = (int)date('t', strtotime($inicio));
for ($d = 1; $d <= $ultimoDia; $d++) {
    $dataStr = sprintf('%04d-%02d-%02d', $ano, $mes, $d);
    $info = $dias[$dataStr] ?? null;
    $semanaAtual[] = [
        'dia' => $d,
        'data' => $dataStr,
        'cor' => $info['cor'] ?? '',
        'tipo' => $info['tipo_dia'] ?? '',
    ];
    $dw = (int)date('w', strtotime($dataStr));
    if ($dw === 6 || $d === $ultimoDia) {
        $presentes = 0;
        $faltas = 0;
        foreach ($semanaAtual as $sd) {
            if (($sd['tipo'] ?? '') === 'presente' || ($sd['tipo'] ?? '') === 'atrasado') {
                $presentes++;
            }
            if (($sd['tipo'] ?? '') === 'falta') {
                $faltas++;
            }
        }
        $semanal[] = [
            'dias' => $semanaAtual,
            'presentes' => $presentes,
            'faltas' => $faltas,
        ];
        $semanaAtual = [];
    }
}

// Status atual (hoje)
$statusAtual = 'Ausente';
$hoje = date('Y-m-d');
$stHoje = $pdo->prepare('SELECT status, atraso FROM ponto WHERE usuario_id = ? AND data = ?');
$stHoje->execute([$funcionarioId, $hoje]);
$pHoje = $stHoje->fetch();
if ($pHoje) {
    if ($pHoje['status'] === 'presente' && (float)$pHoje['atraso'] > 0) {
        $statusAtual = 'Atrasado';
    } elseif ($pHoje['status'] === 'presente') {
        $statusAtual = 'Presente';
    } else {
        $statusAtual = ucfirst($pHoje['status']);
    }
}

$produtividade = $resumo['tarefas_total'] > 0
    ? round(($resumo['tarefas_concluidas'] / $resumo['tarefas_total']) * 100)
    : 0;

jsonResponse([
    'funcionario' => $funcionario,
    'mes' => $mes,
    'ano' => $ano,
    'resumo' => $resumo,
    'status_atual' => $statusAtual,
    'produtividade' => $produtividade,
    'dias' => array_values($dias),
    'tarefas' => $tarefas,
    'eventos' => $eventos,
    'ausencias' => $ausencias,
    'horas_extras_lista' => $solicitacoesHe,
    'semanal' => $semanal,
    'grafico_presenca' => [
        'labels' => ['Presentes', 'Faltas', 'Atrasos', 'Férias', 'Ausentes'],
        'valores' => [
            $resumo['presentes'],
            $resumo['faltas'],
            $resumo['atrasos'],
            $resumo['ferias'],
            $resumo['ausentes'],
        ],
        'cores' => ['#10B981', '#EF4444', '#F59E0B', '#3B82F6', '#64748B'],
    ],
]);
