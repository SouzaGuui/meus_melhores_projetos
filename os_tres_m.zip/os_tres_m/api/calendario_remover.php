<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!podeRemoverEventoCalendario()) {
    jsonResponse(['erro' => 'Sem permissão para remover eventos.'], 403);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true) ?: $_POST;
$eventId = (string)($data['id'] ?? '');

if ($eventId === '') {
    jsonResponse(['erro' => 'ID do evento obrigatório.'], 400);
}

$pdo = db();
$user = currentUser();

if (ctype_digit($eventId)) {
    $stmt = $pdo->prepare('SELECT * FROM calendario_eventos WHERE id = ?');
    $stmt->execute([(int)$eventId]);
    $ev = $stmt->fetch();
    if (!$ev) {
        jsonResponse(['erro' => 'Evento não encontrado.'], 404);
    }
    if (!podeEditarEventoCalendario($ev, $user)) {
        jsonResponse(['erro' => 'Acesso negado.'], 403);
    }
    $pdo->prepare('DELETE FROM calendario_eventos WHERE id = ?')->execute([(int)$eventId]);
    registrarLog('calendario_excluir', 'Evento manual #' . $eventId);
    jsonResponse(['sucesso' => true]);
}

if (str_starts_with($eventId, 'tarefa-')) {
    $id = (int)substr($eventId, 7);
    $t = $pdo->prepare('SELECT * FROM tarefas WHERE id = ?');
    $t->execute([$id]);
    $row = $t->fetch();
    if (!$row) {
        jsonResponse(['erro' => 'Tarefa não encontrada.'], 404);
    }
    if (!podeEditarTarefa($row) && !can('calendario.manage')) {
        jsonResponse(['erro' => 'Acesso negado.'], 403);
    }
    $pdo->prepare("UPDATE tarefas SET status = 'cancelada' WHERE id = ?")->execute([$id]);
    registrarLog('calendario_remover_tarefa', "Tarefa #{$id} cancelada via calendário");
    jsonResponse(['sucesso' => true]);
}

if (str_starts_with($eventId, 'ausencia-')) {
    garantirTabelaPontoAusencias();
    $id = (int)substr($eventId, 9);
    $pdo->prepare('DELETE FROM ponto_ausencias WHERE id = ?')->execute([$id]);
    registrarLog('calendario_remover_ausencia', "Ausência #{$id} removida");
    jsonResponse(['sucesso' => true]);
}

if (str_starts_with($eventId, 'he-')) {
    garantirTabelaHorasExtras();
    $id = (int)substr($eventId, 3);
    $pdo->prepare('DELETE FROM horas_extras_solicitacoes WHERE id = ?')->execute([$id]);
    registrarLog('calendario_remover_he', "HE #{$id} removida");
    jsonResponse(['sucesso' => true]);
}

if (str_starts_with($eventId, 'ponto-')) {
    if (preg_match('/^ponto-(\d+)-(\d{4}-\d{2}-\d{2})$/', $eventId, $m)) {
        $pdo->prepare('DELETE FROM ponto WHERE usuario_id = ? AND data = ?')->execute([(int)$m[1], $m[2]]);
        registrarLog('calendario_remover_ponto', "Ponto {$m[2]} usuário {$m[1]}");
        jsonResponse(['sucesso' => true]);
    }
}

jsonResponse(['erro' => 'Tipo de evento não suportado para remoção.'], 400);
