<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

garantirTabelaHorasExtras();
$pdo = db();
$user = currentUser();
$uid = (int)$user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $usuarioId = (int)($_GET['usuario_id'] ?? $uid);
    if ($usuarioId !== $uid && !podeVerHorasExtrasEquipe()) {
        jsonResponse(['erro' => 'Acesso negado.'], 403);
    }

    $sql = "SELECT h.*, u.nome as usuario_nome, ap.nome as aprovador_nome
            FROM horas_extras_solicitacoes h
            JOIN usuarios u ON h.usuario_id = u.id
            LEFT JOIN usuarios ap ON h.aprovado_por = ap.id
            WHERE h.usuario_id = ?";
    $params = [$usuarioId];

    if (!empty($_GET['mes']) && !empty($_GET['ano'])) {
        $sql .= ' AND MONTH(h.data_trabalhada) = ? AND YEAR(h.data_trabalhada) = ?';
        $params[] = (int)$_GET['mes'];
        $params[] = (int)$_GET['ano'];
    }

    $sql .= ' ORDER BY h.data_trabalhada DESC, h.criado_em DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    jsonResponse(['solicitacoes' => $stmt->fetchAll()]);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data) || empty($data)) {
    $data = $_POST;
}
$acao = $data['acao'] ?? 'criar';

if ($acao === 'criar') {
    if (!podeRegistrarHorasExtras()) {
        jsonResponse(['erro' => 'Sem permissão.'], 403);
    }

    $dataTrab = sanitize($data['data_trabalhada'] ?? '');
    $horaEntrada = sanitize($data['hora_entrada'] ?? '');
    $horaSaida = sanitize($data['hora_saida'] ?? '');
    $setor = sanitize($data['setor'] ?? ($user['setor'] ?? ''));
    $motivo = trim($data['motivo'] ?? '');
    $observacoes = sanitize($data['observacoes'] ?? '');
    $alvoId = $uid;

    if (!$dataTrab || !$horaEntrada || !$horaSaida || !$motivo) {
        jsonResponse(['erro' => 'Preencha data, horários e motivo.'], 400);
    }

    // Funcionário não informa quantidade — sempre cálculo automático
    $calc = calcularHoras($horaEntrada, $horaSaida);
    $cfgHd = $pdo->query("SELECT valor FROM configuracoes WHERE chave='horas_diarias' LIMIT 1")->fetchColumn();
    $horasDiarias = $cfgHd ? (float)$cfgHd : 8;
    $horasExtras = max(0, round($calc - $horasDiarias, 2));

    if ($horasExtras <= 0) {
        jsonResponse(['erro' => 'Não há horas extras para este período (jornada dentro do limite diário).'], 400);
    }

    $pdo->prepare('INSERT INTO horas_extras_solicitacoes
        (usuario_id, data_trabalhada, hora_entrada, hora_saida, horas_extras, setor, motivo, observacoes, status)
        VALUES (?,?,?,?,?,?,?,?,\'pendente\')')
        ->execute([$alvoId, $dataTrab, $horaEntrada, $horaSaida, $horasExtras, $setor ?: null, $motivo, $observacoes ?: null]);

    $gestores = $pdo->query("SELECT id FROM usuarios WHERE status='ativo' AND nivel_acesso IN ('rh','gerente','coordenacao','admin')")->fetchAll();
    foreach ($gestores as $g) {
        criarNotificacao((int)$g['id'], 'Horas extras pendentes',
            $user['nome'] . ' solicitou ' . number_format($horasExtras, 1) . 'h extras em ' . formatarData($dataTrab),
            'ponto', 'ponto.php');
    }

    registrarLog('horas_extras_solicitar', "HE {$horasExtras}h em {$dataTrab} — usuário {$uid}");
    jsonResponse(['sucesso' => true, 'id' => (int)$pdo->lastInsertId()]);
}

if (in_array($acao, ['aprovar', 'recusar'], true)) {
    if (!podeAprovarHorasExtras()) {
        jsonResponse(['erro' => 'Sem permissão.'], 403);
    }

    $id = (int)($data['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT h.*, u.nome, u.setor as setor_usuario FROM horas_extras_solicitacoes h JOIN usuarios u ON h.usuario_id = u.id WHERE h.id = ?');
    $stmt->execute([$id]);
    $row = $stmt->fetch();
    if (!$row) {
        jsonResponse(['erro' => 'Solicitação não encontrada.'], 404);
    }
    if ($row['status'] !== 'pendente') {
        jsonResponse(['erro' => 'Solicitação já processada.'], 400);
    }

    if (in_array(getNivelAcesso(), ['gerente', 'coordenacao'], true) && !empty($user['setor'])) {
        if (($row['setor_usuario'] ?? '') !== $user['setor']) {
            jsonResponse(['erro' => 'Fora do seu setor.'], 403);
        }
    }

    $novoStatus = $acao === 'aprovar' ? 'aprovada' : 'recusada';
    $motivoRecusa = sanitize($data['motivo_recusa'] ?? '');
    $pdo->prepare('UPDATE horas_extras_solicitacoes SET status = ?, aprovado_por = ?, motivo_recusa = ?, atualizado_em = NOW() WHERE id = ?')
        ->execute([$novoStatus, $uid, $motivoRecusa ?: null, $id]);

    if ($novoStatus === 'aprovada') {
        $stP = $pdo->prepare('SELECT id FROM ponto WHERE usuario_id = ? AND data = ?');
        $stP->execute([(int)$row['usuario_id'], $row['data_trabalhada']]);
        $pontoId = $stP->fetchColumn();
        if ($pontoId) {
            $pdo->prepare('UPDATE ponto SET horas_extras = horas_extras + ? WHERE id = ?')
                ->execute([(float)$row['horas_extras'], $pontoId]);
        } else {
            $pdo->prepare("INSERT INTO ponto (usuario_id, data, entrada, saida, horas_trabalhadas, horas_extras, status)
                VALUES (?,?,?,?,?,?,'presente')")
                ->execute([
                    (int)$row['usuario_id'],
                    $row['data_trabalhada'],
                    $row['hora_entrada'],
                    $row['hora_saida'],
                    calcularHoras($row['hora_entrada'], $row['hora_saida']),
                    (float)$row['horas_extras'],
                ]);
        }

        try {
            $pdo->query('SELECT 1 FROM calendario_eventos LIMIT 1');
            $titulo = '⏱ Horas extras — ' . explode(' ', $row['nome'])[0];
            $pdo->prepare('INSERT INTO calendario_eventos (titulo, descricao, tipo, data_inicio, data_fim, dia_inteiro, cor, usuario_id, setor, visibilidade, criado_por)
                VALUES (?,?,?,?,?,1,?,?,?,\'setor\',?)')
                ->execute([
                    $titulo,
                    $row['motivo'],
                    'outro',
                    $row['data_trabalhada'] . ' ' . $row['hora_entrada'],
                    $row['data_trabalhada'] . ' ' . $row['hora_saida'],
                    '#F97316',
                    (int)$row['usuario_id'],
                    $row['setor'] ?: $row['setor_usuario'],
                    $uid,
                ]);
        } catch (Exception $e) { /* opcional */ }

        criarNotificacao((int)$row['usuario_id'], 'Horas extras aprovadas',
            'Sua solicitação de ' . number_format((float)$row['horas_extras'], 1) . 'h foi aprovada.',
            'ponto', 'ponto.php');
    } else {
        criarNotificacao((int)$row['usuario_id'], 'Horas extras recusadas',
            'Sua solicitação foi recusada.' . ($motivoRecusa ? ' Motivo: ' . $motivoRecusa : ''),
            'ponto', 'ponto.php');
    }

    registrarLog('horas_extras_' . $acao, "Solicitação #{$id} — {$novoStatus}");
    jsonResponse(['sucesso' => true]);
}

jsonResponse(['erro' => 'Ação inválida.'], 400);
