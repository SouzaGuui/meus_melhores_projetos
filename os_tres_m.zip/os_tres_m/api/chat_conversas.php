<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

$user = currentUser();
$pdo = db();
$uid = (int)$user['id'];

$stmt = $pdo->prepare("
    SELECT c.id, c.ultima_mensagem, c.ultima_mensagem_em,
           CASE WHEN c.usuario1_id = ? THEN u2.id ELSE u1.id END as outro_id,
           CASE WHEN c.usuario1_id = ? THEN u2.nome ELSE u1.nome END as outro_nome,
           CASE WHEN c.usuario1_id = ? THEN u2.foto_perfil ELSE u1.foto_perfil END as outro_foto,
           CASE WHEN c.usuario1_id = ? THEN u2.online ELSE u1.online END as outro_online,
           (SELECT COUNT(*) FROM mensagens m WHERE m.conversa_id = c.id AND m.lida = 0 AND m.remetente_id != ?) as nao_lidas
    FROM conversas c
    JOIN usuarios u1 ON c.usuario1_id = u1.id
    JOIN usuarios u2 ON c.usuario2_id = u2.id
    WHERE c.usuario1_id = ? OR c.usuario2_id = ?
    ORDER BY c.ultima_mensagem_em DESC
");
$stmt->execute([$uid, $uid, $uid, $uid, $uid, $uid, $uid]);
$lista = [];

foreach ($stmt->fetchAll() as $c) {
    if (getNivelAcesso() !== 'admin' && !can('*')) {
        $chk = $pdo->prepare("SELECT nivel_acesso FROM usuarios WHERE id = ?");
        $chk->execute([(int)$c['outro_id']]);
        if ($chk->fetchColumn() === 'admin') {
            continue;
        }
    }
    $lista[] = [
        'id' => (int)$c['id'],
        'outro_id' => (int)$c['outro_id'],
        'outro_nome' => $c['outro_nome'],
        'outro_foto' => $c['outro_foto'] ? BASE_URL . 'uploads/' . $c['outro_foto'] : null,
        'outro_online' => (bool)$c['outro_online'],
        'ultima_mensagem' => $c['ultima_mensagem'] ?? '',
        'hora' => $c['ultima_mensagem_em'] ? date('H:i', strtotime($c['ultima_mensagem_em'])) : '',
        'nao_lidas' => (int)$c['nao_lidas'],
    ];
}

jsonResponse(['conversas' => $lista]);
