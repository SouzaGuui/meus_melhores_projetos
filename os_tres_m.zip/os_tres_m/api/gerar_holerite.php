<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['rh', 'admin', 'gerente']);

$id  = (int)($_GET['id'] ?? 0);
$pdo = db();

if (!$id) {
    die('ID inválido.');
}

$stmt = $pdo->prepare("
    SELECT fp.*, u.nome, u.cpf, u.cargo, u.setor, u.email, u.data_contratacao
    FROM folha_pagamento fp
    JOIN usuarios u ON fp.usuario_id = u.id
    WHERE fp.id = ?
");
$stmt->execute([$id]);
$folha = $stmt->fetch();

if (!$folha) {
    die('Folha não encontrada.');
}

$empresa = [];
$cfgStmt = $pdo->query("SELECT chave, valor FROM configuracoes");
while ($row = $cfgStmt->fetch()) {
    $empresa[$row['chave']] = $row['valor'];
}

$periodo = date('F/Y', mktime(0, 0, 0, $folha['mes'], 1, $folha['ano']));

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Holerite — <?= htmlspecialchars($folha['nome']) ?></title>
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, sans-serif; font-size: 12px; color: #1a1a1a; background: #fff; padding: 20px; }
  .holerite { max-width: 700px; margin: 0 auto; border: 2px solid #1E3A8A; border-radius: 8px; overflow: hidden; }
  .header { background: #1E3A8A; color: white; padding: 16px 20px; display: flex; justify-content: space-between; align-items: center; }
  .header h1 { font-size: 20px; font-weight: 800; letter-spacing: -0.5px; }
  .header .sub { font-size: 11px; opacity: 0.8; margin-top: 2px; }
  .header .periodo { text-align: right; }
  .header .periodo strong { font-size: 16px; display: block; }
  .section { padding: 14px 20px; border-bottom: 1px solid #e5e7eb; }
  .section-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; color: #6b7280; margin-bottom: 10px; }
  .info-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
  .info-item label { display: block; font-size: 10px; color: #9ca3af; margin-bottom: 2px; }
  .info-item span { font-size: 13px; font-weight: 600; color: #111827; }
  .valores-table { width: 100%; border-collapse: collapse; }
  .valores-table th { background: #f3f4f6; padding: 8px 12px; text-align: left; font-size: 11px; color: #6b7280; font-weight: 700; text-transform: uppercase; }
  .valores-table td { padding: 8px 12px; border-bottom: 1px solid #f3f4f6; font-size: 12px; }
  .valores-table tr:last-child td { border-bottom: none; }
  .valor-positivo { color: #059669; font-weight: 600; }
  .valor-negativo { color: #dc2626; font-weight: 600; }
  .total-row { background: #1E3A8A; color: white; }
  .total-row td { padding: 12px; font-weight: 800; font-size: 14px; }
  .footer { padding: 14px 20px; background: #f9fafb; display: flex; justify-content: space-between; align-items: center; }
  .assinatura { text-align: center; }
  .assinatura .linha { border-top: 1px solid #374151; width: 180px; margin: 0 auto 4px; }
  .assinatura span { font-size: 11px; color: #6b7280; }
  .badge { display: inline-block; padding: 3px 10px; border-radius: 20px; font-size: 10px; font-weight: 700; }
  .badge-pago { background: #d1fae5; color: #065f46; }
  .badge-pendente { background: #fef3c7; color: #92400e; }
  .badge-processado { background: #dbeafe; color: #1e40af; }
  @media print {
    body { padding: 0; }
    .no-print { display: none; }
  }
</style>
</head>
<body>

<div class="no-print" style="text-align:center;margin-bottom:16px">
    <button onclick="window.print()"
            style="background:#1E3A8A;color:white;border:none;padding:10px 24px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer">
        🖨️ Imprimir / Salvar PDF
    </button>
    <button onclick="window.close()"
            style="background:#6b7280;color:white;border:none;padding:10px 24px;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;margin-left:8px">
        Fechar
    </button>
</div>

<div class="holerite">
    <!-- Cabeçalho -->
    <div class="header">
        <div>
            <h1><?= htmlspecialchars($empresa['empresa_nome'] ?? 'Os Três M') ?></h1>
            <div class="sub">CNPJ: <?= htmlspecialchars($empresa['empresa_cnpj'] ?? '00.000.000/0001-00') ?></div>
            <div class="sub">Demonstrativo de Pagamento</div>
        </div>
        <div class="periodo">
            <strong><?= $periodo ?></strong>
            <div style="font-size:11px;opacity:0.8">Competência</div>
            <span class="badge badge-<?= $folha['status'] ?>" style="margin-top:6px">
                <?= ucfirst($folha['status']) ?>
            </span>
        </div>
    </div>

    <!-- Dados do Funcionário -->
    <div class="section">
        <div class="section-title">Dados do Funcionário</div>
        <div class="info-grid">
            <div class="info-item">
                <label>Nome Completo</label>
                <span><?= htmlspecialchars($folha['nome']) ?></span>
            </div>
            <div class="info-item">
                <label>CPF</label>
                <span><?= htmlspecialchars($folha['cpf']) ?></span>
            </div>
            <div class="info-item">
                <label>Cargo</label>
                <span><?= htmlspecialchars($folha['cargo'] ?: '-') ?></span>
            </div>
            <div class="info-item">
                <label>Setor</label>
                <span><?= htmlspecialchars($folha['setor'] ?: '-') ?></span>
            </div>
            <div class="info-item">
                <label>Data de Admissão</label>
                <span><?= formatarData($folha['data_contratacao']) ?></span>
            </div>
            <div class="info-item">
                <label>E-mail</label>
                <span><?= htmlspecialchars($folha['email']) ?></span>
            </div>
        </div>
    </div>

    <!-- Valores -->
    <div class="section" style="padding:0">
        <table class="valores-table">
            <thead>
                <tr>
                    <th>Descrição</th>
                    <th style="text-align:right">Tipo</th>
                    <th style="text-align:right">Valor</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Salário Base</td>
                    <td style="text-align:right"><span class="badge" style="background:#dbeafe;color:#1e40af">Provento</span></td>
                    <td style="text-align:right" class="valor-positivo"><?= formatarMoeda($folha['salario_base']) ?></td>
                </tr>
                <?php if ($folha['horas_extras_valor'] > 0): ?>
                <tr>
                    <td>Horas Extras</td>
                    <td style="text-align:right"><span class="badge" style="background:#d1fae5;color:#065f46">Provento</span></td>
                    <td style="text-align:right" class="valor-positivo"><?= formatarMoeda($folha['horas_extras_valor']) ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($folha['beneficios'] > 0): ?>
                <tr>
                    <td>Benefícios</td>
                    <td style="text-align:right"><span class="badge" style="background:#d1fae5;color:#065f46">Provento</span></td>
                    <td style="text-align:right" class="valor-positivo"><?= formatarMoeda($folha['beneficios']) ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($folha['descontos'] > 0): ?>
                <tr>
                    <td>Descontos</td>
                    <td style="text-align:right"><span class="badge" style="background:#fee2e2;color:#991b1b">Desconto</span></td>
                    <td style="text-align:right" class="valor-negativo">- <?= formatarMoeda($folha['descontos']) ?></td>
                </tr>
                <?php endif; ?>
                <?php if ($folha['multas'] > 0): ?>
                <tr>
                    <td>Multas / Penalidades</td>
                    <td style="text-align:right"><span class="badge" style="background:#fee2e2;color:#991b1b">Desconto</span></td>
                    <td style="text-align:right" class="valor-negativo">- <?= formatarMoeda($folha['multas']) ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr class="total-row">
                    <td colspan="2">VALOR LÍQUIDO A RECEBER</td>
                    <td style="text-align:right;font-size:16px"><?= formatarMoeda($folha['valor_final']) ?></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <?php if ($folha['observacao']): ?>
    <div class="section">
        <div class="section-title">Observações</div>
        <p style="font-size:12px;color:#374151"><?= htmlspecialchars($folha['observacao']) ?></p>
    </div>
    <?php endif; ?>

    <!-- Rodapé / Assinaturas -->
    <div class="footer">
        <div class="assinatura">
            <div class="linha"></div>
            <span>Assinatura do Funcionário</span>
        </div>
        <div style="text-align:center;font-size:11px;color:#9ca3af">
            <div>Gerado em <?= date('d/m/Y H:i') ?></div>
            <div><?= htmlspecialchars($empresa['empresa_nome'] ?? 'Os Três M') ?></div>
        </div>
        <div class="assinatura">
            <div class="linha"></div>
            <span>Responsável RH / Empresa</span>
        </div>
    </div>
</div>

</body>
</html>
