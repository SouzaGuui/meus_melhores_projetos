<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

garantirTabelaPontoAusencias();
$pdo = db();
$user = currentUser();
$uid = (int)$user['id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!can('ponto.view_own') && !can('ponto.view_team')) {
        jsonResponse(['erro' => 'Sem permissão.'], 403);
    }

    $usuarioId = (int)($_GET['usuario_id'] ?? $uid);
    if ($usuarioId !== $uid && !podeVerPontoDeOutros()) {
        jsonResponse(['erro' => 'Acesso negado.'], 403);
    }

    $sql = "SELECT a.*, u.nome as usuario_nome, ap.nome as aprovador_nome
            FROM ponto_ausencias a
            JOIN usuarios u ON a.usuario_id = u.id
            LEFT JOIN usuarios ap ON a.aprovado_por = ap.id
            WHERE a.usuario_id = ?";
    $params = [$usuarioId];

    if (!empty($_GET['mes']) && !empty($_GET['ano'])) {
        $sql .= ' AND MONTH(a.data_falta) = ? AND YEAR(a.data_falta) = ?';
        $params[] = (int)$_GET['mes'];
        $params[] = (int)$_GET['ano'];
    }

    $sql .= ' ORDER BY a.data_falta DESC, a.criado_em DESC';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    jsonResponse(['solicitacoes' => $stmt->fetchAll()]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    if (!is_array($data) || empty($data)) {
        $data = $_POST;
    }
    $acao = $data['acao'] ?? 'criar';

    if ($acao === 'criar') {
        if (!podeInformarFalta()) {
            jsonResponse(['erro' => 'Sem permissão.'], 403);
        }

        $dataFalta = sanitize($data['data_falta'] ?? '');
        $tipoPeriodo = sanitize($data['tipo_periodo'] ?? 'dia_inteiro');
        $justificativa = trim($data['justificativa'] ?? '');
        $observacoes = sanitize($data['observacoes'] ?? '');
        $horaInicio = sanitize($data['hora_inicio'] ?? '');
        $horaFim = sanitize($data['hora_fim'] ?? '');
        $alvoId = podeVerPontoDeOutros() && !empty($data['usuario_id'])
            ? (int)$data['usuario_id']
            : $uid;

        if (!$dataFalta || !$justificativa) {
            jsonResponse(['erro' => 'Data e justificativa são obrigatórias.'], 400);
        }

        if (!in_array($tipoPeriodo, ['dia_inteiro', 'meio_periodo', 'horario_especifico'], true)) {
            jsonResponse(['erro' => 'Tipo de período inválido.'], 400);
        }

        if ($alvoId !== $uid && !podeVerPontoDeOutros()) {
            jsonResponse(['erro' => 'Não pode registrar falta para outro usuário.'], 403);
        }

        $comprovante = null;
        if (!empty($_FILES['comprovante']['name'])) {
            $up = uploadFoto($_FILES['comprovante'], 'comprovantes');
            if (!empty($up['erro'])) {
                jsonResponse(['erro' => $up['erro']], 400);
            }
            $comprovante = $up['arquivo'] ?? null;
        }

        $pdo->prepare('INSERT INTO ponto_ausencias (usuario_id, data_falta, tipo_periodo, hora_inicio, hora_fim, justificativa, observacoes, comprovante, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([
                $alvoId,
                $dataFalta,
                $tipoPeriodo,
                $horaInicio ?: null,
                $horaFim ?: null,
                $justificativa,
                $observacoes ?: null,
                $comprovante,
                'pendente',
            ]);

        $id = (int)$pdo->lastInsertId();
        registrarLog('ponto_ausencia_criar', "Solicitação #$id para $dataFalta");

        $gestores = $pdo->query("SELECT id FROM usuarios WHERE status='ativo' AND nivel_acesso IN ('rh','gerente','coordenacao','admin')")->fetchAll();
        foreach ($gestores as $g) {
            if ((int)$g['id'] === $uid) {
                continue;
            }
            criarNotificacao(
                (int)$g['id'],
                'Nova solicitação de falta',
                $user['nome'] . ' informou falta em ' . formatarData($dataFalta),
                'ponto',
                'ponto.php'
            );
        }

        jsonResponse(['sucesso' => true, 'id' => $id]);
    }

    if ($acao === 'aprovar' || $acao === 'recusar') {
        if (!podeAprovarFalta()) {
            jsonResponse(['erro' => 'Sem permissão para aprovar/recusar.'], 403);
        }

        $id = (int)($data['id'] ?? 0);
        $stmt = $pdo->prepare('SELECT * FROM ponto_ausencias WHERE id = ?');
        $stmt->execute([$id]);
        $sol = $stmt->fetch();
        if (!$sol) {
            jsonResponse(['erro' => 'Solicitação não encontrada.'], 404);
        }

        $novoStatus = $acao === 'aprovar' ? 'aprovada' : 'recusada';
        $motivo = sanitize($data['motivo_recusa'] ?? '');

        $pdo->prepare('UPDATE ponto_ausencias SET status = ?, aprovado_por = ?, motivo_recusa = ?, atualizado_em = NOW() WHERE id = ?')
            ->execute([$novoStatus, $uid, $acao === 'recusar' ? $motivo : null, $id]);

        if ($novoStatus === 'aprovada') {
            $stmtP = $pdo->prepare('SELECT id FROM ponto WHERE usuario_id = ? AND data = ?');
            $stmtP->execute([$sol['usuario_id'], $sol['data_falta']]);
            $pontoEx = $stmtP->fetch();
            if ($pontoEx) {
                $pdo->prepare("UPDATE ponto SET status = 'falta', observacao = CONCAT(COALESCE(observacao,''), '\n[Falta informada] ', ?) WHERE id = ?")
                    ->execute([mb_substr($sol['justificativa'], 0, 200), $pontoEx['id']]);
            } else {
                $pdo->prepare("INSERT INTO ponto (usuario_id, data, status, observacao) VALUES (?, ?, 'falta', ?)")
                    ->execute([$sol['usuario_id'], $sol['data_falta'], 'Falta aprovada: ' . mb_substr($sol['justificativa'], 0, 200)]);
            }

            try {
                $pdo->query('SELECT 1 FROM calendario_eventos LIMIT 1');
            } catch (Exception $e) {
                $calSql = @file_get_contents(__DIR__ . '/../database/calendario.sql');
                if ($calSql) {
                    $pdo->exec(preg_replace('/USE os_tres_m;\s*/', '', $calSql));
                }
            }
            $pdo->prepare("INSERT INTO calendario_eventos (titulo, descricao, tipo, data_inicio, data_fim, dia_inteiro, cor, usuario_id, visibilidade, criado_por)
                VALUES (?, ?, 'outro', ?, ?, 1, '#EF4444', ?, 'setor', ?)")
                ->execute([
                    'Falta — ' . explode(' ', getUsuario($sol['usuario_id'])['nome'] ?? 'Funcionário')[0],
                    $sol['justificativa'],
                    $sol['data_falta'] . ' 00:00:00',
                    $sol['data_falta'] . ' 23:59:59',
                    $sol['usuario_id'],
                    $uid,
                ]);
        }

        criarNotificacao(
            (int)$sol['usuario_id'],
            $novoStatus === 'aprovada' ? 'Falta aprovada' : 'Falta recusada',
            'Sua solicitação de ' . formatarData($sol['data_falta']) . ' foi ' . $novoStatus . '.',
            'ponto',
            'ponto.php'
        );

        jsonResponse(['sucesso' => true]);
    }

    jsonResponse(['erro' => 'Ação inválida.'], 400);
}

jsonResponse(['erro' => 'Método não permitido.'], 405);
