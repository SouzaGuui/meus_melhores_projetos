<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!can('calendario.view')) {
    jsonResponse(['erro' => 'Sem permissão.'], 403);
}

$user = currentUser();
$pdo = db();
$nivel = getNivelAcesso();
$setor = $user['setor'] ?? '';
$hoje = date('Y-m-d');

$scopeSql = '';
$scopeParams = [];
if ($nivel === 'funcionario') {
    $scopeSql = ' AND p.usuario_id = ?';
    $scopeParams[] = (int)$user['id'];
} elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
    $scopeSql = ' AND u.setor = ?';
    $scopeParams[] = $setor;
}

$baseJoin = 'FROM ponto p JOIN usuarios u ON p.usuario_id = u.id WHERE p.data = ?' . $scopeSql;
$paramsHoje = array_merge([$hoje], $scopeParams);

$st = $pdo->prepare("SELECT COUNT(*) $baseJoin AND p.status = 'presente' AND (p.atraso IS NULL OR p.atraso <= 0)");
$st->execute($paramsHoje);
$presentes = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) $baseJoin AND p.atraso > 0");
$st->execute($paramsHoje);
$atrasados = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) $baseJoin AND p.status = 'falta'");
$st->execute($paramsHoje);
$faltas = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) $baseJoin AND p.status = 'ferias'");
$st->execute($paramsHoje);
$feriasHoje = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(*) FROM usuarios u WHERE u.status = 'ativo'" .
    (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor ? ' AND u.setor = ?' : ''));
if (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
    $st->execute([$setor]);
} else {
    $st->execute();
}
$totalAtivos = (int)$st->fetchColumn();

$st = $pdo->prepare("SELECT COUNT(DISTINCT p.usuario_id) $baseJoin");
$st->execute($paramsHoje);
$registrados = (int)$st->fetchColumn();
$ausentes = max(0, $totalAtivos - $registrados - $feriasHoje);

$taxaPresenca = $totalAtivos > 0
    ? round((($presentes + $atrasados) / $totalAtivos) * 100, 1)
    : 0;

// Próximas férias (eventos manuais)
$feriasSql = "SELECT e.titulo, e.data_inicio, u.nome
    FROM calendario_eventos e
    LEFT JOIN usuarios u ON e.usuario_id = u.id
    WHERE e.tipo = 'ferias' AND e.data_inicio >= ?";
$feriasParams = [$hoje . ' 00:00:00'];
if ($nivel === 'funcionario') {
    $feriasSql .= ' AND e.usuario_id = ?';
    $feriasParams[] = (int)$user['id'];
} elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
    $feriasSql .= ' AND e.setor = ?';
    $feriasParams[] = $setor;
}
$feriasSql .= ' ORDER BY e.data_inicio ASC LIMIT 5';
$st = $pdo->prepare($feriasSql);
$st->execute($feriasParams);
$proximasFerias = $st->fetchAll(PDO::FETCH_ASSOC);

// Eventos / reuniões próximos (7 dias)
$evSql = "SELECT e.id, e.titulo, e.tipo, e.data_inicio, e.data_fim, u.nome as usuario_nome
    FROM calendario_eventos e
    LEFT JOIN usuarios u ON e.usuario_id = u.id
    WHERE e.data_inicio BETWEEN ? AND ?";
$evParams = [$hoje . ' 00:00:00', date('Y-m-d', strtotime('+7 days')) . ' 23:59:59'];
if ($nivel === 'funcionario') {
    $evSql .= " AND (e.visibilidade = 'empresa' OR (e.visibilidade = 'setor' AND e.setor = ?) OR (e.visibilidade = 'pessoal' AND e.usuario_id = ?))";
    $evParams[] = $setor;
    $evParams[] = (int)$user['id'];
} elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
    $evSql .= " AND (e.visibilidade = 'empresa' OR e.setor = ? OR e.usuario_id = ? OR e.criado_por = ?)";
    $evParams[] = $setor;
    $evParams[] = (int)$user['id'];
    $evParams[] = (int)$user['id'];
}
$evSql .= " ORDER BY e.data_inicio ASC LIMIT 8";
$st = $pdo->prepare($evSql);
$st->execute($evParams);
$proximosEventos = $st->fetchAll(PDO::FETCH_ASSOC);

$reunioesHoje = array_filter($proximosEventos, function ($e) use ($hoje) {
    return ($e['tipo'] ?? '') === 'reuniao' && strpos($e['data_inicio'], $hoje) === 0;
});

// Presença mensal (últimos 30 dias)
$mesSql = "SELECT DATE_FORMAT(p.data, '%d/%m') as dia,
    SUM(CASE WHEN p.status = 'presente' AND (p.atraso IS NULL OR p.atraso <= 0) THEN 1 ELSE 0 END) as presentes,
    SUM(CASE WHEN p.atraso > 0 THEN 1 ELSE 0 END) as atrasos,
    SUM(CASE WHEN p.status = 'falta' THEN 1 ELSE 0 END) as faltas
    FROM ponto p JOIN usuarios u ON p.usuario_id = u.id
    WHERE p.data >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)" . $scopeSql . '
    GROUP BY p.data ORDER BY p.data';
$st = $pdo->prepare($mesSql);
$st->execute($scopeParams);
$presencaMensal = $st->fetchAll(PDO::FETCH_ASSOC);

jsonResponse([
    'presentes_hoje' => $presentes,
    'atrasados_hoje' => $atrasados,
    'faltas_hoje' => $faltas,
    'ausentes_hoje' => $ausentes,
    'ferias_hoje' => $feriasHoje,
    'taxa_presenca' => $taxaPresenca,
    'proximas_ferias' => $proximasFerias,
    'proximos_eventos' => $proximosEventos,
    'reunioes_hoje' => array_values($reunioesHoje),
    'presenca_mensal' => $presencaMensal,
]);
