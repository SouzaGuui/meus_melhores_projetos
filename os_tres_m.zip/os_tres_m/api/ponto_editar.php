<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['rh','admin']);

$id = (int)($_POST['id'] ?? 0);
$entrada = sanitize($_POST['entrada'] ?? '');
$saida = sanitize($_POST['saida'] ?? '');
$status = sanitize($_POST['status'] ?? 'presente');
$obs = sanitize($_POST['observacao'] ?? '');
$pdo = db();

if (!$id) {
    header('Location: ../ponto.php?msg=ID+inválido&tipo=danger');
    exit;
}

$horas = ($entrada && $saida) ? calcularHoras($entrada, $saida) : 0;
$extras = max(0, $horas - 8);

$pdo->prepare("UPDATE ponto SET entrada=?, saida=?, status=?, observacao=?, horas_trabalhadas=?, horas_extras=? WHERE id=?")
    ->execute([$entrada ?: null, $saida ?: null, $status, $obs, $horas, $extras, $id]);

registrarLog('editar_ponto', "Ponto ID $id editado");
header('Location: ../ponto.php?msg=Ponto+atualizado&tipo=success');
exit;
