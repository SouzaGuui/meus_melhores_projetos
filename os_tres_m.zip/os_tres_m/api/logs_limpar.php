<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['admin']);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['erro' => 'Método não permitido.'], 405);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    $data = $_POST;
}

$modo = sanitize($data['modo'] ?? 'filtrados');
$pdo = db();

if ($modo === 'todos_antigos') {
    $dias = max(7, (int)($data['dias'] ?? 30));
    $stmt = $pdo->prepare('DELETE FROM logs_sistema WHERE criado_em < DATE_SUB(NOW(), INTERVAL ? DAY)');
    $stmt->execute([$dias]);
    $qtd = (int)$stmt->rowCount();
    registrarLog('logs_limpar', "Removidos {$qtd} logs com mais de {$dias} dias");
    jsonResponse(['sucesso' => true, 'removidos' => $qtd, 'mensagem' => "{$qtd} registro(s) antigo(s) removido(s)."]);
}

$dataInicio = sanitize($data['data_inicio'] ?? date('Y-m-01'));
$dataFim = sanitize($data['data_fim'] ?? date('Y-m-d'));
$busca = sanitize($data['busca'] ?? '');
$filtroUser = (int)($data['usuario_id'] ?? 0);
$filtroTipo = sanitize($data['tipo'] ?? '');

$where = 'WHERE criado_em BETWEEN ? AND ?';
$params = [$dataInicio . ' 00:00:00', $dataFim . ' 23:59:59'];

if ($busca) {
    $where .= ' AND (acao LIKE ? OR descricao LIKE ? OR ip LIKE ?)';
    $params[] = "%$busca%";
    $params[] = "%$busca%";
    $params[] = "%$busca%";
}
if ($filtroUser) {
    $where .= ' AND usuario_id = ?';
    $params[] = $filtroUser;
}
if ($filtroTipo) {
    $where .= ' AND acao LIKE ?';
    $params[] = '%' . $filtroTipo . '%';
}

$stmt = $pdo->prepare("DELETE FROM logs_sistema $where");
$stmt->execute($params);
$qtd = $stmt->rowCount();
registrarLog('logs_limpar', "Removidos {$qtd} logs (filtro {$dataInicio} a {$dataFim})");
jsonResponse(['sucesso' => true, 'removidos' => $qtd, 'mensagem' => "{$qtd} registro(s) removido(s)."]);
