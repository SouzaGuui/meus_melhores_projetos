<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['admin']);

$data = json_decode(file_get_contents('php://input'), true);
$acao = sanitize($data['acao'] ?? '');
$pdo  = db();

if ($acao === 'reset_online') {
    $pdo->query("UPDATE usuarios SET online = 0");
    registrarLog('admin_reset_online', 'Status online resetado');
    jsonResponse(['sucesso' => true, 'mensagem' => 'Status online resetado com sucesso!']);
}

if ($acao === 'limpar_logs') {
    $stmt = $pdo->prepare("DELETE FROM logs_sistema WHERE criado_em < DATE_SUB(NOW(), INTERVAL 30 DAY)");
    $stmt->execute();
    $removidos = $stmt->rowCount();
    registrarLog('admin_limpar_logs', "Logs antigos removidos: $removidos registros");
    jsonResponse(['sucesso' => true, 'mensagem' => "$removidos log(s) removido(s) com sucesso!"]);
}

jsonResponse(['erro' => 'Ação inválida.'], 400);
