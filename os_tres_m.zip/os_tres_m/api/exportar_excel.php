<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
if (!podeExportar()) {
    header('Location: ' . BASE_URL . 'acesso_negado.php');
    exit;
}
requireAnyPermission(['relatorios.basic', 'relatorios.full']);

$tipo = sanitize($_GET['tipo'] ?? 'funcionarios');
if (!in_array($tipo, relatoriosPermitidos(), true)) {
    header('Location: ' . BASE_URL . 'acesso_negado.php');
    exit;
}
$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$pdo = db();

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="relatorio_' . $tipo . '_' . date('Y-m-d') . '.csv"');
header('Pragma: no-cache');

$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8

switch ($tipo) {
    case 'funcionarios':
        fputcsv($out, ['Nome','E-mail','CPF','Cargo','Setor','Contratação','Status'], ';');
        $dados = $pdo->query("SELECT nome,email,cpf,cargo,setor,data_contratacao,status FROM usuarios WHERE 1=1" . sqlOcultarAdmin() . " ORDER BY nome")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [$d['nome'],$d['email'],$d['cpf'],$d['cargo'],$d['setor'],formatarData($d['data_contratacao']),$d['status']], ';');
        }
        break;
    case 'ponto':
        fputcsv($out, ['Funcionário','Data','Entrada','Saída','Horas','Extras','Status'], ';');
        $dados = $pdo->query("SELECT p.*,u.nome FROM ponto p JOIN usuarios u ON p.usuario_id=u.id WHERE MONTH(p.data)=$mes AND YEAR(p.data)=$ano" . sqlOcultarAdmin('u') . " ORDER BY u.nome,p.data")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [$d['nome'],formatarData($d['data']),formatarHora($d['entrada']),formatarHora($d['saida']),number_format($d['horas_trabalhadas'],1),number_format($d['horas_extras'],1),$d['status']], ';');
        }
        break;
    case 'ausencias':
        garantirTabelaPontoAusencias();
        fputcsv($out, ['Funcionário','Data','Período','Início','Fim','Justificativa','Status','Aprovador'], ';');
        $dados = $pdo->query("SELECT a.*, u.nome as funcionario_nome, g.nome as aprovador_nome
            FROM ponto_ausencias a JOIN usuarios u ON a.usuario_id=u.id
            LEFT JOIN usuarios g ON a.aprovado_por=g.id
            WHERE MONTH(a.data_falta)=$mes AND YEAR(a.data_falta)=$ano" . sqlOcultarAdmin('u') . "
            ORDER BY a.data_falta DESC")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [
                $d['funcionario_nome'],
                formatarData($d['data_falta']),
                $d['tipo_periodo'],
                formatarHora($d['hora_inicio']),
                formatarHora($d['hora_fim']),
                $d['justificativa'],
                $d['status'],
                $d['aprovador_nome'] ?? '',
            ], ';');
        }
        break;
    case 'horas_extras':
        if (!podeVerRelatorioHorasExtras()) {
            header('Location: ' . BASE_URL . 'acesso_negado.php');
            exit;
        }
        garantirTabelaHorasExtras();
        fputcsv($out, ['Funcionário','Data','Entrada','Saída','Horas HE','Setor','Motivo','Status'], ';');
        $dados = $pdo->query("SELECT h.*, u.nome as funcionario_nome FROM horas_extras_solicitacoes h
            JOIN usuarios u ON h.usuario_id=u.id
            WHERE MONTH(h.data_trabalhada)=$mes AND YEAR(h.data_trabalhada)=$ano" . sqlOcultarAdmin('u') . "
            ORDER BY h.data_trabalhada DESC")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [
                $d['funcionario_nome'],
                formatarData($d['data_trabalhada']),
                formatarHora($d['hora_entrada']),
                formatarHora($d['hora_saida']),
                number_format((float)$d['horas_extras'], 1),
                $d['setor'],
                $d['motivo'],
                $d['status'],
            ], ';');
        }
        break;
    case 'pagamento':
        fputcsv($out, ['Funcionário','Salário Base','H.Extras','Benefícios','Descontos','Multas','Valor Final','Status'], ';');
        $dados = $pdo->query("SELECT fp.*,u.nome FROM folha_pagamento fp JOIN usuarios u ON fp.usuario_id=u.id WHERE fp.mes=$mes AND fp.ano=$ano ORDER BY u.nome")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [$d['nome'],number_format($d['salario_base'],2,',','.'),number_format($d['horas_extras_valor'],2,',','.'),number_format($d['beneficios'],2,',','.'),number_format($d['descontos'],2,',','.'),number_format($d['multas'],2,',','.'),number_format($d['valor_final'],2,',','.'),$d['status']], ';');
        }
        break;
    case 'logs':
        $dataInicio = sanitize($_GET['data_inicio'] ?? date('Y-m-01'));
        $dataFim    = sanitize($_GET['data_fim']    ?? date('Y-m-d'));
        fputcsv($out, ['#','Ação','Usuário','Descrição','IP','Data/Hora'], ';');
        $dados = $pdo->prepare("SELECT l.*,u.nome FROM logs_sistema l LEFT JOIN usuarios u ON l.usuario_id=u.id WHERE l.criado_em BETWEEN ? AND ? ORDER BY l.criado_em DESC");
        $dados->execute([$dataInicio.' 00:00:00', $dataFim.' 23:59:59']);
        $i = 1;
        foreach ($dados->fetchAll() as $d) {
            fputcsv($out, [$i++, $d['acao'], $d['nome'] ?? 'Sistema', $d['descricao'], $d['ip'], $d['criado_em']], ';');
        }
        break;
}

fclose($out);
exit;
