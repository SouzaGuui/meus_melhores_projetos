<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['rh','admin','gerente','coordenacao']);

$tipo = sanitize($_GET['tipo'] ?? 'funcionarios');
$mes = (int)($_GET['mes'] ?? date('m'));
$ano = (int)($_GET['ano'] ?? date('Y'));
$pdo = db();

header('Content-Type: text/csv; charset=UTF-8');
header('Content-Disposition: attachment; filename="relatorio_' . $tipo . '_' . date('Y-m-d') . '.csv"');
header('Pragma: no-cache');

$out = fopen('php://output', 'w');
fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF)); // BOM UTF-8

switch ($tipo) {
    case 'funcionarios':
        fputcsv($out, ['Nome','E-mail','CPF','Cargo','Setor','Contratação','Status'], ';');
        $dados = $pdo->query("SELECT nome,email,cpf,cargo,setor,data_contratacao,status FROM usuarios ORDER BY nome")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [$d['nome'],$d['email'],$d['cpf'],$d['cargo'],$d['setor'],formatarData($d['data_contratacao']),$d['status']], ';');
        }
        break;
    case 'ponto':
        fputcsv($out, ['Funcionário','Data','Entrada','Saída','Horas','Extras','Status'], ';');
        $dados = $pdo->query("SELECT p.*,u.nome FROM ponto p JOIN usuarios u ON p.usuario_id=u.id WHERE MONTH(p.data)=$mes AND YEAR(p.data)=$ano ORDER BY u.nome,p.data")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [$d['nome'],formatarData($d['data']),formatarHora($d['entrada']),formatarHora($d['saida']),number_format($d['horas_trabalhadas'],1),number_format($d['horas_extras'],1),$d['status']], ';');
        }
        break;
    case 'pagamento':
        fputcsv($out, ['Funcionário','Salário Base','H.Extras','Benefícios','Descontos','Multas','Valor Final','Status'], ';');
        $dados = $pdo->query("SELECT fp.*,u.nome FROM folha_pagamento fp JOIN usuarios u ON fp.usuario_id=u.id WHERE fp.mes=$mes AND fp.ano=$ano ORDER BY u.nome")->fetchAll();
        foreach ($dados as $d) {
            fputcsv($out, [$d['nome'],number_format($d['salario_base'],2,',','.'),number_format($d['horas_extras_valor'],2,',','.'),number_format($d['beneficios'],2,',','.'),number_format($d['descontos'],2,',','.'),number_format($d['multas'],2,',','.'),number_format($d['valor_final'],2,',','.'),$d['status']], ';');
        }
        break;
    case 'logs':
        $dataInicio = sanitize($_GET['data_inicio'] ?? date('Y-m-01'));
        $dataFim    = sanitize($_GET['data_fim']    ?? date('Y-m-d'));
        fputcsv($out, ['#','Ação','Usuário','Descrição','IP','Data/Hora'], ';');
        $dados = $pdo->prepare("SELECT l.*,u.nome FROM logs_sistema l LEFT JOIN usuarios u ON l.usuario_id=u.id WHERE l.criado_em BETWEEN ? AND ? ORDER BY l.criado_em DESC");
        $dados->execute([$dataInicio.' 00:00:00', $dataFim.' 23:59:59']);
        $i = 1;
        foreach ($dados->fetchAll() as $d) {
            fputcsv($out, [$i++, $d['acao'], $d['nome'] ?? 'Sistema', $d['descricao'], $d['ip'], $d['criado_em']], ';');
        }
        break;
}

fclose($out);
exit;
