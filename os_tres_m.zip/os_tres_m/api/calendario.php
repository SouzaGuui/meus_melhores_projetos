<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!can('calendario.view')) {
    jsonResponse(['erro' => 'Sem permissão.'], 403);
}

$user = currentUser();
$pdo = db();
$uid = (int)$user['id'];
$setor = $user['setor'] ?? '';
$nivel = getNivelAcesso();

$coresTipo = [
    'feriado' => '#EF4444', 'ferias' => '#3B82F6', 'folga' => '#64748B',
    'reuniao' => '#7C3AED', 'tarefa' => '#7C3AED', 'evento' => '#7C3AED',
    'presenca' => '#10B981', 'comemorativo' => '#EC4899', 'escala' => '#06B6D4', 'outro' => '#94A3B8',
];

function corPontoCalendario(array $p): string {
    if (($p['status'] ?? '') === 'ferias') return '#3B82F6';
    if (($p['status'] ?? '') === 'falta') return '#EF4444';
    if ((float)($p['atraso'] ?? 0) > 0) return '#F59E0B';
    if (($p['status'] ?? '') === 'presente') return '#10B981';
    return '#64748B';
}

function tituloPontoCalendario(array $p): string {
    $nome = explode(' ', $p['nome'])[0];
    if ((float)($p['atraso'] ?? 0) > 0) return '⚠ Atraso — ' . $nome;
    if ($p['status'] === 'ferias') return '🏖 Férias — ' . $nome;
    if ($p['status'] === 'falta') return '✕ Falta — ' . $nome;
    if ($p['status'] === 'presente') return '✓ Presente — ' . $nome;
    return '⏱ ' . ucfirst($p['status']) . ' — ' . $nome;
}

function formatarEventoFc(array $e, array $cores): array {
    return [
        'id' => (string)$e['id'],
        'title' => $e['titulo'],
        'start' => $e['data_inicio'],
        'end' => $e['data_fim'] ?: null,
        'allDay' => (bool)$e['dia_inteiro'],
        'backgroundColor' => $e['cor'] ?: ($cores[$e['tipo']] ?? '#2563EB'),
        'borderColor' => $e['cor'] ?: ($cores[$e['tipo']] ?? '#2563EB'),
        'extendedProps' => [
            'tipo' => $e['tipo'],
            'descricao' => $e['descricao'],
            'visibilidade' => $e['visibilidade'],
            'usuario_id' => $e['usuario_id'],
            'usuario_nome' => $e['usuario_nome'] ?? '',
            'setor' => $e['setor'],
            'integrado' => false,
        ],
    ];
}


if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $start = sanitize($_GET['start'] ?? date('Y-m-01'));
    $end = sanitize($_GET['end'] ?? date('Y-m-t'));
    $filtroSetor = sanitize($_GET['setor'] ?? '');
    $filtroUser = (int)($_GET['usuario_id'] ?? 0);
    $busca = sanitize($_GET['busca'] ?? '');

    $eventos = [];

    // Eventos manuais
    $sql = "SELECT e.*, u.nome as usuario_nome FROM calendario_eventos e
            LEFT JOIN usuarios u ON e.usuario_id = u.id
            WHERE e.data_inicio <= ? AND (e.data_fim IS NULL OR e.data_fim >= ?)";
    $params = [$end . ' 23:59:59', $start . ' 00:00:00'];

    if ($nivel === 'funcionario') {
        $sql .= " AND (e.visibilidade = 'empresa' OR (e.visibilidade = 'setor' AND e.setor = ?) OR (e.visibilidade = 'pessoal' AND e.usuario_id = ?))";
        $params[] = $setor;
        $params[] = $uid;
    } elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
        $sql .= " AND (e.visibilidade = 'empresa' OR e.setor = ? OR e.usuario_id = ? OR e.criado_por = ?)";
        $params[] = $setor;
        $params[] = $uid;
        $params[] = $uid;
    }

    if ($filtroSetor && can('calendario.filter_team')) {
        $sql .= " AND e.setor = ?";
        $params[] = $filtroSetor;
    }
    if ($filtroUser > 0 && can('calendario.filter_team')) {
        $sql .= ' AND e.usuario_id = ?';
        $params[] = $filtroUser;
    }
    if ($busca !== '') {
        $sql .= ' AND e.titulo LIKE ?';
        $params[] = '%' . $busca . '%';
    }

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    foreach ($stmt->fetchAll() as $e) {
        $eventos[] = formatarEventoFc($e, $coresTipo);
    }

    // Tarefas com prazo (integração)
    $sqlT = "SELECT t.id, t.titulo, t.prazo, t.status, t.atribuido_para, u.nome, u.setor
             FROM tarefas t JOIN usuarios u ON t.atribuido_para = u.id
             WHERE t.prazo IS NOT NULL AND t.prazo BETWEEN ? AND ? AND t.status != 'cancelada'" . sqlOcultarAdmin('u');
    $pT = [$start, $end];
    if ($nivel === 'funcionario') {
        $sqlT .= " AND t.atribuido_para = ?";
        $pT[] = $uid;
    } elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
        $sqlT .= ' AND u.setor = ?';
        $pT[] = $setor;
    }
    if ($filtroSetor && can('calendario.filter_team')) {
        $sqlT .= ' AND u.setor = ?';
        $pT[] = $filtroSetor;
    }
    if ($filtroUser > 0 && can('calendario.filter_team')) {
        $sqlT .= ' AND t.atribuido_para = ?';
        $pT[] = $filtroUser;
    }
    $st = $pdo->prepare($sqlT);
    $st->execute($pT);
    foreach ($st->fetchAll() as $t) {
        $eventos[] = [
            'id' => 'tarefa-' . $t['id'],
            'title' => '📋 ' . $t['titulo'],
            'start' => $t['prazo'],
            'allDay' => true,
            'backgroundColor' => $coresTipo['tarefa'],
            'borderColor' => $coresTipo['tarefa'],
            'extendedProps' => [
                'tipo' => 'tarefa',
                'integrado' => true,
                'status' => $t['status'],
                'descricao' => 'Prazo: ' . $t['prazo'] . ' | Status: ' . $t['status'],
                'usuario_nome' => $t['nome'],
                'usuario_id' => (int)$t['atribuido_para'],
                'pode_remover' => podeRemoverEventoCalendario(),
            ],
        ];
    }

    // Ponto / presença
    $sqlP = "SELECT p.data, p.status, p.entrada, p.saida, p.atraso, p.horas_trabalhadas,
             u.nome, u.id as uid, u.setor FROM ponto p
             JOIN usuarios u ON p.usuario_id = u.id
             WHERE p.data BETWEEN ? AND ?" . sqlOcultarAdmin('u');
    $pP = [$start, $end];
    if ($nivel === 'funcionario') {
        $sqlP .= ' AND p.usuario_id = ?';
        $pP[] = $uid;
    } elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
        $sqlP .= ' AND u.setor = ?';
        $pP[] = $setor;
    }
    if ($filtroUser > 0 && can('calendario.filter_team')) {
        $sqlP .= ' AND p.usuario_id = ?';
        $pP[] = $filtroUser;
    }
    $sp = $pdo->prepare($sqlP);
    $sp->execute($pP);
    foreach ($sp->fetchAll() as $p) {
        $cor = corPontoCalendario($p);
        $eventos[] = [
            'id' => 'ponto-' . $p['uid'] . '-' . $p['data'],
            'title' => tituloPontoCalendario($p),
            'start' => $p['data'],
            'allDay' => true,
            'backgroundColor' => $cor,
            'borderColor' => $cor,
            'extendedProps' => [
                'tipo' => 'presenca',
                'integrado' => true,
                'status' => $p['status'],
                'entrada' => $p['entrada'],
                'saida' => $p['saida'],
                'atraso' => $p['atraso'],
                'usuario_nome' => $p['nome'],
                'usuario_id' => (int)$p['uid'],
                'descricao' => 'Entrada: ' . ($p['entrada'] ?: '—') . ' | Saída: ' . ($p['saida'] ?: '—'),
                'pode_remover' => podeRemoverEventoCalendario(),
            ],
        ];
    }

    // Solicitações de falta/ausência
    try {
        garantirTabelaPontoAusencias();
        $sqlA = "SELECT a.*, u.nome FROM ponto_ausencias a JOIN usuarios u ON a.usuario_id = u.id
                 WHERE a.data_falta BETWEEN ? AND ? AND a.status IN ('pendente','aprovada')" . sqlOcultarAdmin('u');
        $pA = [$start, $end];
        if ($nivel === 'funcionario') {
            $sqlA .= ' AND a.usuario_id = ?';
            $pA[] = $uid;
        } elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
            $sqlA .= ' AND u.setor = ?';
            $pA[] = $setor;
        }
        if ($filtroUser > 0 && can('calendario.filter_team')) {
            $sqlA .= ' AND a.usuario_id = ?';
            $pA[] = $filtroUser;
        }
        $stA = $pdo->prepare($sqlA);
        $stA->execute($pA);
        foreach ($stA->fetchAll() as $a) {
            $cor = $a['status'] === 'pendente' ? '#F59E0B' : '#EF4444';
            $eventos[] = [
                'id' => 'ausencia-' . $a['id'],
                'title' => '✕ Falta informada — ' . explode(' ', $a['nome'])[0],
                'start' => $a['data_falta'],
                'allDay' => true,
                'backgroundColor' => $cor,
                'borderColor' => $cor,
                'extendedProps' => [
                    'tipo' => 'falta',
                    'integrado' => true,
                    'status' => $a['status'],
                    'descricao' => $a['justificativa'],
                    'usuario_nome' => $a['nome'],
                    'usuario_id' => (int)$a['usuario_id'],
                    'pode_remover' => podeRemoverEventoCalendario(),
                ],
            ];
        }
    } catch (Exception $e) { /* tabela opcional */ }

    try {
        garantirTabelaHorasExtras();
        $sqlHe = "SELECT h.*, u.nome FROM horas_extras_solicitacoes h
                  JOIN usuarios u ON h.usuario_id = u.id
                  WHERE h.data_trabalhada BETWEEN ? AND ? AND h.status IN ('pendente','aprovada')" . sqlOcultarAdmin('u');
        $pHe = [$start, $end];
        if ($nivel === 'funcionario') {
            $sqlHe .= ' AND h.usuario_id = ?';
            $pHe[] = $uid;
        } elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
            $sqlHe .= ' AND u.setor = ?';
            $pHe[] = $setor;
        }
        if ($filtroUser > 0 && can('calendario.filter_team')) {
            $sqlHe .= ' AND h.usuario_id = ?';
            $pHe[] = $filtroUser;
        }
        $stHe = $pdo->prepare($sqlHe);
        $stHe->execute($pHe);
        foreach ($stHe->fetchAll() as $h) {
            $cor = $h['status'] === 'pendente' ? '#FB923C' : '#F97316';
            $eventos[] = [
                'id' => 'he-' . $h['id'],
                'title' => '⏱ HE ' . number_format((float)$h['horas_extras'], 1) . 'h — ' . explode(' ', $h['nome'])[0],
                'start' => $h['data_trabalhada'] . ' ' . $h['hora_entrada'],
                'end' => $h['data_trabalhada'] . ' ' . $h['hora_saida'],
                'allDay' => false,
                'backgroundColor' => $cor,
                'borderColor' => $cor,
                'extendedProps' => [
                    'tipo' => 'horas_extras',
                    'integrado' => true,
                    'status' => $h['status'],
                    'descricao' => $h['motivo'],
                    'usuario_nome' => $h['nome'],
                    'usuario_id' => (int)$h['usuario_id'],
                    'entrada' => substr($h['hora_entrada'], 0, 5),
                    'saida' => substr($h['hora_saida'], 0, 5),
                    'pode_remover' => podeRemoverEventoCalendario(),
                ],
            ];
        }
    } catch (Exception $e) { /* opcional */ }

    jsonResponse(['eventos' => $eventos]);
}

$raw = file_get_contents('php://input');
$data = json_decode($raw, true) ?: $_POST;
$acao = $data['acao'] ?? 'salvar';

if ($acao === 'excluir') {
    if (!can('calendario.manage') && !can('calendario.edit_own')) {
        jsonResponse(['erro' => 'Sem permissão.'], 403);
    }
    $id = (int)($data['id'] ?? 0);
    $stmt = $pdo->prepare('SELECT * FROM calendario_eventos WHERE id = ?');
    $stmt->execute([$id]);
    $ev = $stmt->fetch();
    if (!$ev) jsonResponse(['erro' => 'Evento não encontrado.'], 404);
    if (!podeEditarEventoCalendario($ev, $user)) {
        jsonResponse(['erro' => 'Acesso negado.'], 403);
    }
    $pdo->prepare('DELETE FROM calendario_eventos WHERE id = ?')->execute([$id]);
    registrarLog('calendario_excluir', 'Evento #' . $id);
    jsonResponse(['sucesso' => true]);
}

if (!can('calendario.manage') && !can('calendario.edit_own')) {
    jsonResponse(['erro' => 'Sem permissão para criar eventos.'], 403);
}

$titulo = sanitize($data['titulo'] ?? '');
$tipo = sanitize($data['tipo'] ?? 'evento');
$descricao = sanitize($data['descricao'] ?? '');
$dataInicio = sanitize($data['data_inicio'] ?? '');
$dataFim = sanitize($data['data_fim'] ?? '');
$diaInteiro = !empty($data['dia_inteiro']) ? 1 : 0;
$visibilidade = sanitize($data['visibilidade'] ?? 'empresa');
$usuarioEv = (int)($data['usuario_id'] ?? 0) ?: null;
$setorEv = sanitize($data['setor'] ?? '');
$cor = sanitize($data['cor'] ?? ($coresTipo[$tipo] ?? '#2563EB'));
$id = (int)($data['id'] ?? 0);

if (!$titulo || !$dataInicio) {
    jsonResponse(['erro' => 'Título e data de início são obrigatórios.'], 400);
}

if ($nivel === 'funcionario') {
    $visibilidade = 'pessoal';
    $usuarioEv = $uid;
    $setorEv = $setor;
}

if ($id > 0) {
    $stmt = $pdo->prepare('SELECT * FROM calendario_eventos WHERE id = ?');
    $stmt->execute([$id]);
    $ev = $stmt->fetch();
    if (!$ev || !podeEditarEventoCalendario($ev, $user)) {
        jsonResponse(['erro' => 'Acesso negado.'], 403);
    }
    $pdo->prepare('UPDATE calendario_eventos SET titulo=?,descricao=?,tipo=?,data_inicio=?,data_fim=?,dia_inteiro=?,cor=?,usuario_id=?,setor=?,visibilidade=? WHERE id=?')
        ->execute([$titulo, $descricao, $tipo, $dataInicio, $dataFim ?: null, $diaInteiro, $cor, $usuarioEv, $setorEv ?: null, $visibilidade, $id]);
    jsonResponse(['sucesso' => true, 'id' => $id]);
}

$pdo->prepare('INSERT INTO calendario_eventos (titulo,descricao,tipo,data_inicio,data_fim,dia_inteiro,cor,usuario_id,setor,visibilidade,criado_por) VALUES (?,?,?,?,?,?,?,?,?,?,?)')
    ->execute([$titulo, $descricao, $tipo, $dataInicio, $dataFim ?: null, $diaInteiro, $cor, $usuarioEv, $setorEv ?: null, $visibilidade, $uid]);
$novoId = (int)$pdo->lastInsertId();
registrarLog('calendario_criar', $titulo);
jsonResponse(['sucesso' => true, 'id' => $novoId]);
