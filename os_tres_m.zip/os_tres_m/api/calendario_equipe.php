<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();

if (!can('calendario.view')) {
    jsonResponse(['erro' => 'Sem permissão.'], 403);
}

$pdo = db();
$user = currentUser();
$uid = (int)$user['id'];
$nivel = getNivelAcesso();
$setor = $user['setor'] ?? '';
$busca = sanitize($_GET['busca'] ?? '');
$hoje = date('Y-m-d');

$sql = "SELECT u.id, u.nome, u.email, u.cargo, u.setor, u.foto_perfil, u.online, u.status, u.nivel_acesso,
        CONCAT('FUNC', LPAD(u.id, 3, '0')) as codigo
        FROM usuarios u
        WHERE u.status = 'ativo'" . sqlOcultarAdmin('u');
$params = [];

if ($nivel === 'funcionario') {
    $sql .= ' AND u.id = ?';
    $params[] = $uid;
} elseif (in_array($nivel, ['gerente', 'coordenacao'], true) && $setor) {
    $sql .= ' AND u.setor = ?';
    $params[] = $setor;
}

if ($busca !== '') {
    $sql .= ' AND (u.nome LIKE ? OR u.email LIKE ? OR u.cargo LIKE ? OR u.setor LIKE ?)';
    $like = '%' . $busca . '%';
    $params = array_merge($params, [$like, $like, $like, $like]);
}

$sql .= ' ORDER BY u.nome ASC LIMIT 120';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$membros = $stmt->fetchAll();

$lista = [];
foreach ($membros as $m) {
    $id = (int)$m['id'];

    $stP = $pdo->prepare("SELECT status, atraso, horas_trabalhadas FROM ponto WHERE usuario_id = ? AND data = ?");
    $stP->execute([$id, $hoje]);
    $ponto = $stP->fetch();

    $presentes = 0;
    $irreg = 0;
    $faltas = 0;
    $horas = 0.0;

    if ($ponto) {
        if ($ponto['status'] === 'presente') {
            $presentes = 1;
            if ((float)$ponto['atraso'] > 0) {
                $irreg = 1;
            }
        } elseif ($ponto['status'] === 'falta') {
            $faltas = 1;
        } else {
            $irreg = 1;
        }
        $horas = (float)$ponto['horas_trabalhadas'];
    } else {
        $irreg = 1;
    }

    $stM = $pdo->prepare("SELECT
        COUNT(CASE WHEN status='presente' THEN 1 END) as pres,
        COUNT(CASE WHEN status='falta' THEN 1 END) as fal,
        COUNT(CASE WHEN atraso > 0 THEN 1 END) as atr,
        SUM(horas_trabalhadas) as hrs
        FROM ponto WHERE usuario_id = ? AND data >= DATE_SUB(CURDATE(), INTERVAL 29 DAY)");
    $stM->execute([$id]);
    $mes = $stM->fetch() ?: [];

    $dias = max(1, (int)($mes['pres'] ?? 0) + (int)($mes['fal'] ?? 0) + (int)($mes['atr'] ?? 0));
    $freq = $dias > 0 ? round(((int)($mes['pres'] ?? 0) / $dias) * 100) : 0;

    $stT = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para = ? AND status IN ('pendente','em_andamento')");
    $stT->execute([$id]);
    $tarefasAtivas = (int)$stT->fetchColumn();

    $statusAtual = 'Ausente';
    if ($ponto) {
        if ($ponto['status'] === 'presente' && (float)$ponto['atraso'] > 0) {
            $statusAtual = 'Atrasado';
        } elseif ($ponto['status'] === 'presente') {
            $statusAtual = 'Presente';
        } elseif ($ponto['status'] === 'falta') {
            $statusAtual = 'Falta';
        } else {
            $statusAtual = ucfirst($ponto['status']);
        }
    }

    $lista[] = [
        'id' => $id,
        'nome' => $m['nome'],
        'cargo' => $m['cargo'] ?: '—',
        'setor' => $m['setor'] ?: '—',
        'codigo' => $m['codigo'],
        'foto' => $m['foto_perfil'] ? BASE_URL . 'uploads/' . $m['foto_perfil'] : null,
        'inicial' => strtoupper(mb_substr($m['nome'], 0, 1)),
        'online' => (bool)$m['online'],
        'status_atual' => $statusAtual,
        'stats_hoje' => [
            'corretos' => $presentes,
            'irregulares' => $irreg,
            'faltas' => $faltas,
            'horas' => round($horas, 1),
        ],
        'stats_mes' => [
            'presentes' => (int)($mes['pres'] ?? 0),
            'faltas' => (int)($mes['fal'] ?? 0),
            'atrasos' => (int)($mes['atr'] ?? 0),
            'horas' => round((float)($mes['hrs'] ?? 0), 1),
        ],
        'frequencia' => $freq,
        'tarefas_ativas' => $tarefasAtivas,
        'nivel' => $m['nivel_acesso'] ?? '',
    ];
}

jsonResponse(['membros' => $lista]);
