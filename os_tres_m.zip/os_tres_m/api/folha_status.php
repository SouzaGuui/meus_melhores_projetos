<?php
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../config/functions.php';
requireLogin();
requireLevel(['rh','admin','gerente']);

$data = json_decode(file_get_contents('php://input'), true);
$id = (int)($data['id'] ?? 0);
$status = sanitize($data['status'] ?? '');
$pdo = db();

$validos = ['pendente','processado','pago'];
if (!$id || !in_array($status, $validos)) {
    jsonResponse(['erro' => 'Dados inválidos.'], 400);
}

$pdo->prepare("UPDATE folha_pagamento SET status=? WHERE id=?")->execute([$status, $id]);
registrarLog('folha_status', "Folha ID $id status: $status");
jsonResponse(['sucesso' => true]);
