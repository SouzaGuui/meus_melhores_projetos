<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Dashboard';
$breadcrumb = 'Dashboard';
$user = currentUser();
$stats = getDashboardStats();

// Dados para gráficos
try {
    $pdo = db();

    // Ponto últimos 7 dias
    $pontoSemana = $pdo->query("
        SELECT DATE_FORMAT(data,'%d/%m') as dia,
               COUNT(*) as total,
               SUM(CASE WHEN status='presente' THEN 1 ELSE 0 END) as presentes,
               SUM(CASE WHEN status='falta' THEN 1 ELSE 0 END) as faltas
        FROM ponto
        WHERE data >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
        GROUP BY data ORDER BY data
    ")->fetchAll();

    // Tarefas por status
    $tarefasStatus = $pdo->query("
        SELECT status, COUNT(*) as total FROM tarefas GROUP BY status
    ")->fetchAll();

    // Funcionários por setor
    $funcSetor = $pdo->query("
        SELECT setor, COUNT(*) as total FROM usuarios WHERE status='ativo' AND setor != '' GROUP BY setor ORDER BY total DESC LIMIT 6
    ")->fetchAll();

    // Folha últimos 6 meses
    $folhaMeses = $pdo->query("
        SELECT CONCAT(mes,'/',ano) as periodo, SUM(valor_final) as total
        FROM folha_pagamento
        WHERE (ano = YEAR(NOW()) AND mes <= MONTH(NOW()))
           OR (ano = YEAR(NOW())-1 AND mes > MONTH(NOW()))
        GROUP BY ano, mes ORDER BY ano, mes DESC LIMIT 6
    ")->fetchAll();

    // Últimas tarefas
    $ultimasTarefas = $pdo->query("
        SELECT t.*, u.nome as funcionario_nome
        FROM tarefas t
        JOIN usuarios u ON t.atribuido_para = u.id
        ORDER BY t.criado_em DESC LIMIT 5
    ")->fetchAll();

    // Últimos pontos
    $ultimosPontos = $pdo->query("
        SELECT p.*, u.nome as funcionario_nome
        FROM ponto p
        JOIN usuarios u ON p.usuario_id = u.id
        ORDER BY p.criado_em DESC LIMIT 5
    ")->fetchAll();
} catch (Exception $e) {
    // Em caso de erro, definir arrays vazios para evitar erros de renderização
    $pontoSemana = [];
    $tarefasStatus = [];
    $funcSetor = [];
    $folhaMeses = [];
    $ultimasTarefas = [];
    $ultimosPontos = [];
}

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <!-- Boas-vindas -->
            <div class="welcome-banner fade-in mb-4">
                <div class="d-flex align-items-center justify-content-between flex-wrap gap-3">
                    <div>
                        <h2 class="mb-1" style="font-size:22px;font-weight:800;color:var(--text-primary)">
                            Olá, <?= htmlspecialchars(explode(' ', $user['nome'])[0]) ?>! 👋
                        </h2>
                        <p style="color:var(--text-muted);font-size:14px;margin:0">
                            <?= date('l, d \d\e F \d\e Y') ?> — Bem-vindo ao painel de controle
                        </p>
                    </div>
                    <div class="d-flex gap-2">
                        <?php if (hasPermission(['rh','admin'])): ?>
                        <a href="funcionarios.php?acao=novo" class="btn btn-primary btn-sm">
                            <i class="bi bi-person-plus"></i> Novo Funcionário
                        </a>
                        <?php endif; ?>
                        <?php if (hasPermission(['gerente','coordenacao','admin'])): ?>
                        <a href="tarefas.php?acao=nova" class="btn btn-purple btn-sm">
                            <i class="bi bi-plus-circle"></i> Nova Tarefa
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- STAT CARDS -->
            <div class="row g-3 mb-4">
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="stat-card blue">
                        <div class="stat-icon blue"><i class="bi bi-people-fill"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $stats['total_funcionarios'] ?></div>
                            <div class="stat-label">Funcionários</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="stat-card green">
                        <div class="stat-icon green"><i class="bi bi-circle-fill"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $stats['funcionarios_online'] ?></div>
                            <div class="stat-label">Online Agora</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="stat-card yellow">
                        <div class="stat-icon yellow"><i class="bi bi-hourglass-split"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $stats['tarefas_pendentes'] ?></div>
                            <div class="stat-label">Tarefas Pend.</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="stat-card blue">
                        <div class="stat-icon blue"><i class="bi bi-arrow-repeat"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $stats['tarefas_andamento'] ?></div>
                            <div class="stat-label">Em Andamento</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="stat-card purple">
                        <div class="stat-icon purple"><i class="bi bi-cash-stack"></i></div>
                        <div class="stat-info">
                            <div class="stat-value" style="font-size:16px"><?= formatarMoeda($stats['folha_mensal']) ?></div>
                            <div class="stat-label">Folha Mensal</div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-md-4 col-xl-2">
                    <div class="stat-card red">
                        <div class="stat-icon red"><i class="bi bi-clock-history"></i></div>
                        <div class="stat-info">
                            <div class="stat-value"><?= $stats['atrasos_hoje'] ?></div>
                            <div class="stat-label">Atrasos Hoje</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- GRÁFICOS ROW 1 -->
            <div class="row g-3 mb-4">
                <!-- Ponto Semanal -->
                <div class="col-12 col-lg-8">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-clock me-2" style="color:var(--azul-claro)"></i>Controle de Ponto — Últimos 7 Dias</h5>
                            <span style="font-size:12px;color:var(--text-muted)">Presença diária</span>
                        </div>
                        <div class="card-body">
                            <div class="chart-container" style="height:220px">
                                <canvas id="chartPonto"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Tarefas por Status -->
                <div class="col-12 col-lg-4">
                    <div class="card h-100">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-pie-chart me-2" style="color:var(--roxo-claro)"></i>Tarefas por Status</h5>
                        </div>
                        <div class="card-body d-flex flex-column align-items-center justify-content-center">
                            <div class="chart-container" style="height:200px;width:200px">
                                <canvas id="chartTarefas"></canvas>
                            </div>
                            <div class="d-flex gap-3 mt-3 flex-wrap justify-content-center">
                                <span style="font-size:12px;color:var(--amarelo)">● Pendente</span>
                                <span style="font-size:12px;color:var(--azul-claro)">● Andamento</span>
                                <span style="font-size:12px;color:var(--verde)">● Concluída</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- GRÁFICOS ROW 2 -->
            <div class="row g-3 mb-4">
                <!-- Folha Mensal -->
                <div class="col-12 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-graph-up me-2" style="color:var(--verde)"></i>Folha Salarial — Últimos Meses</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container" style="height:200px">
                                <canvas id="chartFolha"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Funcionários por Setor -->
                <div class="col-12 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-bar-chart me-2" style="color:var(--amarelo)"></i>Funcionários por Setor</h5>
                        </div>
                        <div class="card-body">
                            <div class="chart-container" style="height:200px">
                                <canvas id="chartSetores"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TABELAS -->
            <div class="row g-3">
                <!-- Últimas Tarefas -->
                <div class="col-12 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-check2-square me-2" style="color:var(--azul-claro)"></i>Últimas Tarefas</h5>
                            <a href="tarefas.php" class="btn btn-outline btn-sm">Ver todas</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tarefa</th>
                                        <th>Funcionário</th>
                                        <th>Status</th>
                                        <th>Prazo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($ultimasTarefas)): ?>
                                    <tr><td colspan="4" class="text-center" style="color:var(--text-muted);padding:24px">Nenhuma tarefa cadastrada</td></tr>
                                    <?php else: ?>
                                    <?php foreach ($ultimasTarefas as $t): ?>
                                    <tr>
                                        <td>
                                            <span style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars(substr($t['titulo'],0,30)) ?></span>
                                            <br><span class="badge-status prioridade-<?= $t['prioridade'] ?>"><?= ucfirst($t['prioridade']) ?></span>
                                        </td>
                                        <td><?= htmlspecialchars(explode(' ',$t['funcionario_nome'])[0]) ?></td>
                                        <td><span class="badge-status status-<?= $t['status'] ?>"><?= str_replace('_',' ',ucfirst($t['status'])) ?></span></td>
                                        <td style="font-size:12px"><?= $t['prazo'] ? formatarData($t['prazo']) : '-' ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Últimos Pontos -->
                <div class="col-12 col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-clock me-2" style="color:var(--verde)"></i>Registros de Ponto Recentes</h5>
                            <a href="ponto.php" class="btn btn-outline btn-sm">Ver todos</a>
                        </div>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Funcionário</th>
                                        <th>Data</th>
                                        <th>Entrada</th>
                                        <th>Saída</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($ultimosPontos)): ?>
                                    <tr><td colspan="5" class="text-center" style="color:var(--text-muted);padding:24px">Nenhum registro de ponto</td></tr>
                                    <?php else: ?>
                                    <?php foreach ($ultimosPontos as $p): ?>
                                    <tr>
                                        <td style="font-weight:600;color:var(--text-primary)"><?= htmlspecialchars(explode(' ',$p['funcionario_nome'])[0]) ?></td>
                                        <td style="font-size:12px"><?= formatarData($p['data']) ?></td>
                                        <td><?= formatarHora($p['entrada']) ?></td>
                                        <td><?= formatarHora($p['saida']) ?></td>
                                        <td><span class="badge-status status-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div><!-- /page-content -->
    </div><!-- /main-content -->
</div>

<?php
// Preparar dados para JS
$pontoDias = array_column($pontoSemana, 'dia');
$pontoPresentes = array_column($pontoSemana, 'presentes');
$pontoFaltas = array_column($pontoSemana, 'faltas');

$tarefasLabels = [];
$tarefasData = [];
$tarefasColors = [];
$colorMap = ['pendente'=>'#F59E0B','em_andamento'=>'#3B82F6','concluida'=>'#10B981','cancelada'=>'#EF4444'];
foreach ($tarefasStatus as $ts) {
    $tarefasLabels[] = str_replace('_',' ',ucfirst($ts['status']));
    $tarefasData[] = (int)$ts['total'];
    $tarefasColors[] = $colorMap[$ts['status']] ?? '#64748B';
}

$folhaLabels = array_reverse(array_column($folhaMeses, 'periodo'));
$folhaData = array_reverse(array_column($folhaMeses, 'total'));

$setorLabels = array_column($funcSetor, 'setor');
$setorData = array_column($funcSetor, 'total');

$extraJS = '<script>
const chartDefaults = {
    color: "#94A3B8",
    borderColor: "rgba(255,255,255,0.08)",
    font: { family: "Inter" }
};
Chart.defaults.color = chartDefaults.color;
Chart.defaults.font.family = "Inter";

// Ponto Semanal
new Chart(document.getElementById("chartPonto"), {
    type: "bar",
    data: {
        labels: ' . json_encode($pontoDias ?: ['Seg','Ter','Qua','Qui','Sex','Sab','Dom']) . ',
        datasets: [{
            label: "Presentes",
            data: ' . json_encode($pontoPresentes ?: [0,0,0,0,0,0,0]) . ',
            backgroundColor: "rgba(37,99,235,0.7)",
            borderRadius: 6,
            borderSkipped: false
        },{
            label: "Faltas",
            data: ' . json_encode($pontoFaltas ?: [0,0,0,0,0,0,0]) . ',
            backgroundColor: "rgba(239,68,68,0.6)",
            borderRadius: 6,
            borderSkipped: false
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { labels: { color: "#94A3B8", font: { size: 12 } } } },
        scales: {
            x: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#64748B" } },
            y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#64748B", stepSize: 1 } }
        }
    }
});

// Tarefas Doughnut
new Chart(document.getElementById("chartTarefas"), {
    type: "doughnut",
    data: {
        labels: ' . json_encode($tarefasLabels ?: ['Pendente','Em Andamento','Concluída']) . ',
        datasets: [{
            data: ' . json_encode($tarefasData ?: [1,1,1]) . ',
            backgroundColor: ' . json_encode($tarefasColors ?: ['#F59E0B','#3B82F6','#10B981']) . ',
            borderWidth: 0,
            hoverOffset: 8
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        cutout: "70%",
        plugins: { legend: { display: false } }
    }
});

// Folha Mensal
new Chart(document.getElementById("chartFolha"), {
    type: "line",
    data: {
        labels: ' . json_encode($folhaLabels ?: ['Jan','Fev','Mar','Abr','Mai','Jun']) . ',
        datasets: [{
            label: "Folha (R$)",
            data: ' . json_encode($folhaData ?: [0,0,0,0,0,0]) . ',
            borderColor: "#10B981",
            backgroundColor: "rgba(16,185,129,0.1)",
            fill: true,
            tension: 0.4,
            pointBackgroundColor: "#10B981",
            pointRadius: 4
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#64748B" } },
            y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#64748B" } }
        }
    }
});

// Setores
new Chart(document.getElementById("chartSetores"), {
    type: "bar",
    data: {
        labels: ' . json_encode($setorLabels ?: ['Sem dados']) . ',
        datasets: [{
            label: "Funcionários",
            data: ' . json_encode($setorData ?: [0]) . ',
            backgroundColor: ["#2563EB","#7C3AED","#10B981","#F59E0B","#EF4444","#3B82F6"],
            borderRadius: 6,
            borderSkipped: false
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#64748B" } },
            y: { grid: { color: "rgba(255,255,255,0.05)" }, ticks: { color: "#64748B", stepSize: 1 } }
        }
    }
});
</script>';
?>

<?php include 'includes/footer.php'; ?>
