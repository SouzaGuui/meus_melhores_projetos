# Os Três M — Sistema Empresarial

Sistema web completo para gestão empresarial: funcionários, ponto, pagamento, tarefas, chat e relatórios.

---

## ⚙️ Instalação (XAMPP)

### 1. Copiar o projeto
Coloque a pasta `os_tres_m` dentro de:
```
C:\xampp\htdocs\os_tres_m\
```

### 2. Criar o banco de dados
1. Abra o **XAMPP Control Panel** e inicie **Apache** e **MySQL**
2. Acesse `http://localhost/phpmyadmin`
3. Clique em **Importar**
4. Selecione o arquivo `database/os_tres_m.sql`
5. Clique em **Executar**

### 3. Configurar conexão (se necessário)
Edite `config/database.php` se suas credenciais forem diferentes:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');       // senha do MySQL (padrão XAMPP: vazio)
define('DB_NAME', 'os_tres_m');
```

### 4. Acessar o sistema
```
http://localhost/os_tres_m/
```

---

## 🔑 Credenciais Padrão

| Usuário | E-mail | Senha | Nível |
|---------|--------|-------|-------|
| Administrador | admin@ostresm.com | Admin@123 | Admin |
| RH | rh@ostresm.com | Rh@123456 | RH |

> ⚠️ **Troque as senhas após o primeiro acesso!**

---

## 📁 Estrutura do Projeto

```
os_tres_m/
├── api/                  → Endpoints AJAX e ações do servidor
│   ├── chat_enviar.php
│   ├── chat_novas.php
│   ├── exportar_excel.php
│   ├── exportar_pdf.php
│   ├── folha_status.php
│   ├── gerar_holerite.php
│   ├── logout.php
│   ├── notificacoes.php
│   ├── online.php
│   ├── ponto_editar.php
│   ├── recuperar_senha.php
│   └── admin_tools.php
├── assets/
│   ├── css/main.css      → CSS principal do sistema
│   ├── js/main.js        → JavaScript principal
│   └── img/logo.svg      → Logo da empresa
├── config/
│   ├── database.php      → Conexão PDO com MySQL
│   ├── session.php       → Gerenciamento de sessão
│   └── functions.php     → Funções auxiliares globais
├── database/
│   └── os_tres_m.sql     → Script de criação do banco
├── includes/
│   ├── header.php        → HTML head + abertura do body
│   ├── footer.php        → Scripts JS + fechamento
│   ├── sidebar.php       → Menu lateral
│   └── topbar.php        → Barra superior
├── uploads/perfil/       → Fotos de perfil dos usuários
├── .htaccess             → Segurança Apache
├── index.php             → Redirect para login/dashboard
├── login.php             → Tela de autenticação
├── redefinir_senha.php   → Redefinição de senha por token
├── dashboard.php         → Painel principal com gráficos
├── funcionarios.php      → Gestão de funcionários
├── ponto.php             → Folha de ponto
├── pagamento.php         → Folha de pagamento / holerite
├── tarefas.php           → Gestão de tarefas (lista + kanban)
├── chat.php              → Chat interno em tempo real
├── relatorios.php        → Relatórios + exportação
├── notificacoes.php      → Central de notificações
├── perfil.php            → Perfil do usuário
├── configuracoes.php     → Configurações do sistema
└── logs.php              → Logs de auditoria (admin)
```

---

## 👥 Níveis de Acesso

| Nível | Permissões |
|-------|-----------|
| **Funcionário** | Ponto, tarefas próprias, chat, perfil |
| **Coordenação** | + Visualizar equipe, relatórios básicos |
| **RH** | + Cadastrar/editar funcionários, folha salarial, relatórios completos |
| **Gerente** | + Criar tarefas, acompanhar produtividade |
| **Admin** | Acesso total, configurações, logs |

---

## 🛠️ Tecnologias

- **PHP 7.4+** com PDO
- **MySQL 5.7+**
- **Bootstrap 5.3**
- **Chart.js 4.4**
- **Bootstrap Icons 1.11**
- **jQuery 3.7**
- **AJAX** para chat e ponto em tempo real

---

## 🔒 Segurança

- Senhas com `password_hash()` (bcrypt, custo 12)
- Proteção contra SQL Injection via PDO prepared statements
- Sanitização de todos os inputs
- Controle de sessão com `httponly` e `samesite`
- CSRF token disponível via `csrfToken()`
- Headers de segurança via `.htaccess`
- Logs de auditoria de todas as ações

---

## 📊 Funcionalidades

- ✅ Login seguro com recuperação de senha
- ✅ Dashboard com gráficos interativos (Chart.js)
- ✅ Cadastro completo de funcionários com foto
- ✅ Folha de ponto com registro em tempo real
- ✅ Folha de pagamento com geração de holerite PDF
- ✅ Gestão de tarefas (lista e kanban)
- ✅ Chat interno com polling em tempo real
- ✅ Sistema de notificações internas
- ✅ Relatórios com exportação CSV/PDF
- ✅ Modo escuro / claro
- ✅ Design responsivo (mobile-first)
- ✅ Logs de auditoria completos
- ✅ Configurações administrativas

---

*© 2025 Os Três M — Sistema Empresarial*
