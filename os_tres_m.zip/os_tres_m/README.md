# Os Três M — Sistema Empresarial

Sistema web completo para gestão empresarial: funcionários, ponto, pagamento, tarefas, chat e relatórios, com **controle de permissões por perfil (RBAC)**.

---

## ⚙️ Instalação (XAMPP)

### 1. Copiar o projeto
Coloque a pasta `os_tres_m` dentro de:
```
C:\xampp\htdocs\os_tres_m\
```

### 2. Criar o banco de dados
1. Abra o **XAMPP Control Panel** e inicie **Apache** e **MySQL**
2. Acesse `http://localhost/phpmyadmin`
3. Clique em **Importar**
4. Selecione o arquivo `database/os_tres_m.sql`
5. Clique em **Executar**

### 3. Configurar conexão (se necessário)
Edite `config/database.php` se suas credenciais forem diferentes:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');       // senha do MySQL (padrão XAMPP: vazio)
define('DB_NAME', 'os_tres_m');
```

### 4. Configuração inicial (recomendado)
Após importar o SQL, acesse uma vez:
```
http://localhost/os_tres_m/setup.php
```
Isso cria a pasta `uploads/perfil`, garante as senhas padrão, cria os **5 usuários de demonstração** (todos os perfis) e valida a conexão com o banco.

> Apague ou renomeie `setup.php` após usar — não deve existir em produção.

### 5. Acessar o sistema
```
http://localhost/os_tres_m/
```

Faça **logout e login** após rodar o setup para carregar as permissões corretas na sessão.

---

## 🔑 Credenciais Padrão

Use uma das contas abaixo para testar o sistema (também exibidas na tela de login):

| Usuário | E-mail | Senha | Perfil |
|---------|--------|-------|--------|
| Administrador | admin@ostresm.com | Admin@123 | Admin |
| RH | rh@ostresm.com | Rh@123456 | RH |
| Gerente | gerente@ostresm.com | Gerente@123 | Gerente |
| Coordenação | coordenacao@ostresm.com | Coord@123456 | Coordenação |
| Funcionário | funcionario@ostresm.com | Funcionario@123 | Funcionário |

> ⚠️ **Troque as senhas após o primeiro acesso!**

Se o login falhar após importar o SQL, acesse `http://localhost/os_tres_m/setup.php` para recriar ou atualizar todos os usuários acima.

---

## 👥 Perfis e Permissões (RBAC)

O sistema usa **controle de acesso baseado em perfil**. Menus, dashboards e páginas mudam conforme o usuário logado. O backend valida todas as permissões — acesso manual por URL é bloqueado e redireciona para **Acesso Negado**.

### Funcionário
**Pode:** registrar ponto, **informar faltas/ausências** (com justificativa e comprovante opcional), ver e atualizar **apenas o status** das próprias tarefas (Pendente / Em andamento / Concluída), chat interno, editar o próprio perfil.

**Não pode:** exportar relatórios (PDF/Excel/CSV), ver outros funcionários, relatórios gerais, salários, painel administrativo, criar ou editar tarefas de terceiros, alterar configurações.

### Coordenação
**Pode:** visualizar equipe (mesmo setor), acompanhar produtividade e tarefas, relatórios básicos (sem pagamento), chat, perfil próprio.

**Não pode:** ver salários, cadastrar funcionários, editar painel administrativo, alterar permissões, desativar usuários, configurações internas.

### Gerente
**Pode:** criar e editar tarefas criadas por ele, acompanhar produtividade da equipe, relatórios básicos, visualizar membros da equipe, chat, perfil, **cadastrar novos funcionários** (perfis: Funcionário, Coordenação, Gerente — sem salário visível).

**Não pode:** ver salários, folha salarial, configurações, criar administradores/RH, desativar usuários.

### RH
**Pode:** cadastrar e editar funcionários, redefinir senhas, gerenciar cargos/setores, folha salarial, relatórios completos, produtividade, chat, visualizar perfis.

**Não pode:** editar configurações do sistema, logs, excluir administradores, desativar o sistema, alterar permissões do admin principal.

### Administrador
**Pode:** acesso total — configurações, logs, todos os relatórios, folha salarial, gestão completa de usuários (incluindo desativar, exceto outros admins).

---

## ➕ Cadastro de Funcionários

Botão **"+ Novo Funcionário"** disponível para: **Administrador**, **RH** e **Gerente**.

O formulário inclui:
- Nome completo, e-mail, senha (definida manualmente)
- Cargo/função, **perfil de acesso**, telefone, CPF, data de nascimento
- Setor/departamento, foto de perfil (opcional), status (Ativo/Inativo)

**Perfis disponíveis no cadastro** (conforme quem cadastra):

| Quem cadastra | Perfis que pode atribuir |
|---------------|--------------------------|
| Admin | Funcionário, Coordenação, Gerente, RH, Admin |
| RH | Funcionário, Coordenação, Gerente, RH |
| Gerente | Funcionário, Coordenação, Gerente |
| Coordenação | — (somente visualização da equipe) |

**Regras:** validação de e-mail duplicado, senhas criptografadas (`bcrypt`), menus ocultos automaticamente, bloqueio de URL indevida.

---

## 📋 Folha de Ponto — Faltas e Ausências

Na página **Ponto**, qualquer perfil autorizado pode usar **Informar Falta**:

- Data da falta, tipo (dia inteiro, meio período ou horário específico)
- Justificativa, observações e upload opcional de comprovante
- Status: **Pendente** → **Aprovada** ou **Recusada** (Coordenação, Gerente, RH e Admin)

Ao aprovar, o sistema atualiza o registro de ponto, exibe no **calendário corporativo** e entra no relatório **Faltas/Ausências**.

> Instalações antigas: a tabela é criada automaticamente na primeira utilização (`database/ponto_ausencias.sql` ou via `setup.php`).

---

## 📤 Exportação de dados

Botões e APIs de exportação (PDF, Excel, CSV) ficam visíveis apenas para **Administrador**, **RH**, **Gerente** e **Coordenação**. Funcionários não veem essas opções.

---

## 🔒 Perfil Administrador (visibilidade)

O usuário **Administrador** não aparece em listas, dashboards, rankings, chat e relatórios comuns para os demais perfis. Apenas outro administrador enxerga esse perfil nas telas administrativas.

---

## 📅 Calendário corporativo

Quando um dia possui mais de 3 eventos, aparece **Ver mais** com modal completo (busca, filtros, rolagem interna e ordenação por horário).

---

## 🎨 Tema claro/escuro

O arquivo `assets/css/theme-fixes.css` garante contraste legível em textos, inputs, tabelas e cards nos dois temas.

---

## 📁 Estrutura do Projeto

```
os_tres_m/
├── api/                  → Endpoints AJAX e ações do servidor
│   ├── chat_enviar.php
│   ├── chat_novas.php
│   ├── exportar_excel.php
│   ├── exportar_pdf.php
│   ├── folha_status.php
│   ├── gerar_holerite.php
│   ├── logout.php
│   ├── notificacoes.php
│   ├── online.php
│   ├── ponto_editar.php
│   ├── recuperar_senha.php
│   └── admin_tools.php
├── assets/
│   ├── css/main.css      → CSS principal do sistema
│   ├── js/main.js        → JavaScript principal
│   └── img/logo.svg      → Logo da empresa
├── config/
│   ├── database.php      → Conexão PDO com MySQL
│   ├── session.php       → Gerenciamento de sessão
│   ├── permissions.php   → RBAC — matriz de permissões por perfil
│   └── functions.php     → Funções auxiliares globais
├── database/
│   ├── os_tres_m.sql     → Script de criação do banco (inclui todos os perfis)
│   └── adicionar_gerente_coordenacao.sql → Migração se o banco já existir
├── includes/
│   ├── header.php        → HTML head + abertura do body
│   ├── footer.php        → Scripts JS + fechamento
│   ├── sidebar.php       → Menu lateral dinâmico (por perfil)
│   └── topbar.php        → Barra superior
├── uploads/perfil/       → Fotos de perfil dos usuários
├── setup.php             → Configuração inicial (apagar após uso)
├── criar_perfis.php      → Cria/atualiza Gerente e Coordenação (apagar após uso)
├── acesso_negado.php     → Página de bloqueio por permissão
├── .htaccess             → Segurança Apache
├── index.php             → Redirect para login/dashboard
├── login.php             → Tela de autenticação
├── redefinir_senha.php   → Redefinição de senha por token
├── dashboard.php         → Painel personalizado por perfil
├── funcionarios.php      → Gestão de funcionários
├── ponto.php             → Folha de ponto
├── pagamento.php         → Folha de pagamento / holerite
├── tarefas.php           → Gestão de tarefas (lista + kanban)
├── chat.php              → Chat interno em tempo real
├── relatorios.php        → Relatórios + exportação
├── notificacoes.php      → Central de notificações
├── perfil.php            → Perfil do usuário
├── configuracoes.php     → Configurações do sistema (admin)
└── logs.php              → Logs de auditoria (admin)
```

---

## 🔒 Segurança e Controle de Acesso

- **RBAC** centralizado em `config/permissions.php`
- Funções: `can()`, `requirePermission()`, `menuCan()`, `requireLevel()`
- Proteção contra acesso manual por URL → `acesso_negado.php`
- Menu lateral oculta itens não autorizados
- APIs validam permissão antes de executar ações
- Senhas com `password_hash()` (bcrypt, custo 12)
- Proteção contra SQL Injection via PDO prepared statements
- Sanitização de inputs
- Sessão com `httponly` e `samesite`
- CSRF token via `csrfToken()`
- Headers de segurança via `.htaccess`
- Bloqueio de execução de PHP em `uploads/`
- Logs de auditoria (tentativas de acesso negado incluídas)

**Restrições globais** (perfis abaixo de Admin):
- Não editam configurações críticas do sistema
- Não excluem administradores
- Não alteram permissões do administrador principal
- Não desativam o sistema

---

## 🎨 Identidade visual

- **Favicon** laranja com logo **M³** em todas as páginas (`includes/favicon.php`)
- Título das abas: `Página | Os Três M`
- Compatível com Chrome, Edge, Firefox, Safari e navegadores mobile
- Modo claro/escuro com `theme-color` adaptável

---

## 📱 Responsividade

O layout é fluido e adaptado para desktop, tablet e celular:

- Sidebar recolhível (desktop) e menu drawer (mobile)
- Tabelas com rolagem horizontal e modo cards em telas pequenas
- Chat, calendário e dashboard otimizados para mobile
- CSS principal + `assets/css/responsive.css`

---

## 🛠️ Tecnologias

- **PHP 7.4+** com PDO
- **MySQL 5.7+**
- **Bootstrap 5.3**
- **Chart.js 4.4**
- **Bootstrap Icons 1.11**
- **jQuery 3.7**
- **AJAX** para chat e ponto em tempo real

---

## 📊 Funcionalidades

- ✅ Login seguro com recuperação de senha
- ✅ **RBAC** — permissões por perfil (5 níveis)
- ✅ **Dashboard personalizada** por perfil (funcionário, equipe, admin)
- ✅ **Menu lateral dinâmico** conforme cargo
- ✅ Cadastro de funcionários com modal **"+ Novo Funcionário"**
- ✅ Folha de ponto com registro em tempo real
- ✅ Folha de pagamento com geração de holerite (RH/Admin)
- ✅ Gestão de tarefas (lista e kanban)
- ✅ Chat interno com polling em tempo real
- ✅ Sistema de notificações internas
- ✅ Relatórios básicos (Gerente/Coordenação) e completos (RH/Admin)
- ✅ Exportação CSV/PDF com validação de permissão
- ✅ Página de **Acesso Negado** para URLs bloqueadas
- ✅ Modo escuro / claro
- ✅ Design responsivo (mobile-first)
- ✅ Logs de auditoria (admin)
- ✅ Configurações administrativas (somente admin)

---

## 🧪 Testar os perfis

1. Importe o banco e execute `setup.php`
2. Na tela de login, use a tabela de credenciais (ou clique no e-mail para preencher automaticamente)
3. Teste cada perfil: Admin, RH, Gerente, Coordenação e Funcionário
4. Confira se o menu e o dashboard mudam conforme o perfil
5. Com Gerente, Coordenação ou Funcionário, tente `configuracoes.php` — deve ir para **Acesso Negado**

---

*© 2025 Os Três M — Sistema Empresarial*
