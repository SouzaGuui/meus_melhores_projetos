<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . 'dashboard.php');
    exit;
}

$token  = sanitize($_GET['token'] ?? '');
$erro   = '';
$sucesso = '';
$valido = false;
$pdo    = db();

if ($token) {
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE token_recuperacao = ? AND token_expiracao > NOW() AND status = 'ativo'");
    $stmt->execute([$token]);
    $usuario = $stmt->fetch();
    $valido  = (bool)$usuario;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $valido) {
    $nova     = $_POST['nova_senha'] ?? '';
    $confirma = $_POST['confirmar_senha'] ?? '';

    if (strlen($nova) < 6) {
        $erro = 'A senha deve ter pelo menos 6 caracteres.';
    } elseif ($nova !== $confirma) {
        $erro = 'As senhas não coincidem.';
    } else {
        $pdo->prepare("UPDATE usuarios SET senha = ?, token_recuperacao = NULL, token_expiracao = NULL WHERE id = ?")
            ->execute([hashSenha($nova), $usuario['id']]);
        $sucesso = 'Senha redefinida com sucesso! Você já pode fazer login.';
        $valido  = false;
        registrarLog('redefinir_senha', 'Senha redefinida via token', $usuario['id']);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha | Os Três M</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root { --azul: #2563EB; --roxo: #7C3AED; --bg: #0F1117; --card: #1E2130; --border: rgba(255,255,255,0.08); --text: #F1F5F9; --muted: #64748B; --verde: #10B981; --vermelho: #EF4444; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:'Inter',sans-serif; background:var(--bg); min-height:100vh; display:flex; align-items:center; justify-content:center; }
        .card-box { background:var(--card); border:1px solid var(--border); border-radius:20px; padding:40px; width:100%; max-width:420px; box-shadow:0 25px 60px rgba(0,0,0,0.5); }
        .logo { width:56px; height:56px; background:linear-gradient(135deg,var(--azul),var(--roxo)); border-radius:14px; display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:800; color:white; margin:0 auto 20px; }
        h2 { font-size:22px; font-weight:800; color:var(--text); text-align:center; margin-bottom:6px; }
        p.sub { font-size:13px; color:var(--muted); text-align:center; margin-bottom:24px; }
        label { display:block; font-size:13px; font-weight:600; color:#94A3B8; margin-bottom:6px; }
        input { width:100%; background:rgba(255,255,255,0.05); border:1px solid var(--border); border-radius:10px; color:var(--text); font-size:14px; padding:11px 14px; font-family:'Inter',sans-serif; outline:none; transition:all .3s; margin-bottom:16px; }
        input:focus { border-color:var(--azul); box-shadow:0 0 0 3px rgba(37,99,235,.15); }
        .btn-submit { width:100%; background:linear-gradient(135deg,var(--azul),var(--roxo)); border:none; border-radius:10px; color:white; font-size:15px; font-weight:700; padding:13px; cursor:pointer; font-family:'Inter',sans-serif; margin-top:4px; }
        .btn-submit:hover { opacity:.9; }
        .alert { padding:12px 16px; border-radius:10px; font-size:13.5px; margin-bottom:18px; display:flex; align-items:center; gap:8px; }
        .alert-danger { background:rgba(239,68,68,.15); color:#FCA5A5; border:1px solid rgba(239,68,68,.2); }
        .alert-success { background:rgba(16,185,129,.15); color:#6EE7B7; border:1px solid rgba(16,185,129,.2); }
        a.back { display:block; text-align:center; margin-top:16px; font-size:13px; color:var(--azul); text-decoration:none; }
    </style>
</head>
<body>
<div class="card-box">
    <div class="logo">M³</div>
    <h2>Redefinir Senha</h2>
    <p class="sub">Os Três M — Sistema Empresarial</p>

    <?php if ($erro): ?>
    <div class="alert alert-danger"><i class="bi bi-exclamation-circle-fill"></i><?= htmlspecialchars($erro) ?></div>
    <?php endif; ?>

    <?php if ($sucesso): ?>
    <div class="alert alert-success"><i class="bi bi-check-circle-fill"></i><?= htmlspecialchars($sucesso) ?></div>
    <a href="login.php" class="btn-submit" style="display:block;text-align:center;text-decoration:none;padding:13px">
        Ir para o Login
    </a>
    <?php elseif (!$token || !$valido): ?>
    <div class="alert alert-danger">
        <i class="bi bi-exclamation-triangle-fill"></i>
        Link inválido ou expirado. Solicite uma nova recuperação de senha.
    </div>
    <a href="login.php" class="btn-submit" style="display:block;text-align:center;text-decoration:none;padding:13px">
        Voltar ao Login
    </a>
    <?php else: ?>
    <form method="POST">
        <label>Nova Senha</label>
        <input type="password" name="nova_senha" placeholder="Mínimo 6 caracteres" required minlength="6">
        <label>Confirmar Nova Senha</label>
        <input type="password" name="confirmar_senha" placeholder="Repita a senha" required>
        <button type="submit" class="btn-submit">
            <i class="bi bi-lock-fill"></i> Redefinir Senha
        </button>
    </form>
    <?php endif; ?>

    <a href="login.php" class="back">← Voltar ao login</a>
</div>
</body>
</html>
