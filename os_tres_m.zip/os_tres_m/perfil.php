<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();

$pageTitle = 'Meu Perfil';
$breadcrumb = 'Perfil';
$user = currentUser();
$pdo = db();
$userData = getUsuario($user['id']);

$mensagem = '';
$tipoMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'atualizar') {
        $nome = sanitize($_POST['nome'] ?? '');
        $telefone = sanitize($_POST['telefone'] ?? '');
        $cep = sanitize($_POST['cep'] ?? '');

        $foto = null;
        if (!empty($_FILES['foto_perfil']['name'])) {
            $upload = uploadFoto($_FILES['foto_perfil'], 'perfil');
            if (isset($upload['erro'])) {
                $mensagem = $upload['erro'];
                $tipoMsg = 'danger';
            } else {
                $foto = $upload['arquivo'];
            }
        }

        if (!$mensagem) {
            $fotoSql = $foto ? ", foto_perfil = ?" : "";
            $params = [$nome, $telefone, $cep];
            if ($foto) $params[] = $foto;
            $params[] = $user['id'];
            $pdo->prepare("UPDATE usuarios SET nome=?, telefone=?, cep=? $fotoSql WHERE id=?")->execute($params);

            // Atualizar sessão
            $_SESSION['nome'] = $nome;
            if ($foto) $_SESSION['foto_perfil'] = $foto;

            $mensagem = 'Perfil atualizado com sucesso!';
            $tipoMsg = 'success';
            $userData = getUsuario($user['id']);
            registrarLog('atualizar_perfil', 'Perfil atualizado');
        }
    }

    if ($acao === 'senha') {
        $senhaAtual = $_POST['senha_atual'] ?? '';
        $novaSenha = $_POST['nova_senha'] ?? '';
        $confirmar = $_POST['confirmar_senha'] ?? '';

        if (!verificarSenha($senhaAtual, $userData['senha'])) {
            $mensagem = 'Senha atual incorreta.';
            $tipoMsg = 'danger';
        } elseif (strlen($novaSenha) < 6) {
            $mensagem = 'A nova senha deve ter pelo menos 6 caracteres.';
            $tipoMsg = 'danger';
        } elseif ($novaSenha !== $confirmar) {
            $mensagem = 'As senhas não coincidem.';
            $tipoMsg = 'danger';
        } else {
            $pdo->prepare("UPDATE usuarios SET senha=? WHERE id=?")->execute([hashSenha($novaSenha), $user['id']]);
            $mensagem = 'Senha alterada com sucesso!';
            $tipoMsg = 'success';
            registrarLog('alterar_senha', 'Senha alterada');
        }
    }
}

// Estatísticas do usuário
$totalTarefas = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para=?");
$totalTarefas->execute([$user['id']]);
$statTarefas = $totalTarefas->fetchColumn();

$tarefasConcluidas = $pdo->prepare("SELECT COUNT(*) FROM tarefas WHERE atribuido_para=? AND status='concluida'");
$tarefasConcluidas->execute([$user['id']]);
$statConcluidas = $tarefasConcluidas->fetchColumn();

$horasMes = $pdo->prepare("SELECT SUM(horas_trabalhadas) FROM ponto WHERE usuario_id=? AND MONTH(data)=MONTH(NOW()) AND YEAR(data)=YEAR(NOW())");
$horasMes->execute([$user['id']]);
$statHoras = (float)$horasMes->fetchColumn();

$presencaMes = $pdo->prepare("SELECT COUNT(*) FROM ponto WHERE usuario_id=? AND status='presente' AND MONTH(data)=MONTH(NOW()) AND YEAR(data)=YEAR(NOW())");
$presencaMes->execute([$user['id']]);
$statPresenca = $presencaMes->fetchColumn();

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">

            <?php if ($mensagem): ?>
            <div class="alert alert-<?= $tipoMsg ?> fade-in mb-3">
                <i class="bi bi-<?= $tipoMsg==='success'?'check-circle':'exclamation-circle' ?>-fill"></i>
                <?= htmlspecialchars($mensagem) ?>
            </div>
            <?php endif; ?>

            <div class="row g-4">
                <!-- Coluna Esquerda -->
                <div class="col-12 col-lg-4">
                    <!-- Card Perfil -->
                    <div class="card mb-4">
                        <div class="card-body text-center" style="padding:32px">
                            <div style="position:relative;display:inline-block;margin-bottom:16px">
                                <div class="user-avatar" style="width:96px;height:96px;font-size:32px;margin:0 auto">
                                    <?php if ($userData['foto_perfil']): ?>
                                        <img src="<?= BASE_URL ?>uploads/<?= htmlspecialchars($userData['foto_perfil']) ?>" alt="">
                                    <?php else: ?>
                                        <?= strtoupper(substr($userData['nome'],0,2)) ?>
                                    <?php endif; ?>
                                </div>
                                <span style="position:absolute;bottom:4px;right:4px;width:14px;height:14px;border-radius:50%;background:var(--verde);border:3px solid var(--bg-card)"></span>
                            </div>
                            <h4 style="font-weight:800;color:var(--text-primary);margin-bottom:4px"><?= htmlspecialchars($userData['nome']) ?></h4>
                            <p style="color:var(--azul-claro);font-size:13px;margin-bottom:4px"><?= htmlspecialchars($userData['cargo'] ?: 'Sem cargo') ?></p>
                            <p style="color:var(--text-muted);font-size:12px;margin-bottom:16px"><?= htmlspecialchars($userData['setor'] ?: 'Sem setor') ?></p>
                            <span class="badge-status status-ativo" style="margin-bottom:16px;display:inline-flex"><?= nivelLabel($userData['nivel_acesso']) ?></span>

                            <div style="border-top:1px solid var(--border-color);padding-top:16px;text-align:left">
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <i class="bi bi-envelope" style="color:var(--text-muted);width:16px"></i>
                                    <span style="font-size:13px;color:var(--text-secondary)"><?= htmlspecialchars($userData['email']) ?></span>
                                </div>
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <i class="bi bi-phone" style="color:var(--text-muted);width:16px"></i>
                                    <span style="font-size:13px;color:var(--text-secondary)"><?= htmlspecialchars($userData['telefone'] ?: 'Não informado') ?></span>
                                </div>
                                <div class="d-flex align-items-center gap-2 mb-2">
                                    <i class="bi bi-calendar3" style="color:var(--text-muted);width:16px"></i>
                                    <span style="font-size:13px;color:var(--text-secondary)">Desde <?= formatarData($userData['data_contratacao']) ?></span>
                                </div>
                                <div class="d-flex align-items-center gap-2">
                                    <i class="bi bi-geo-alt" style="color:var(--text-muted);width:16px"></i>
                                    <span style="font-size:13px;color:var(--text-secondary)"><?= htmlspecialchars($userData['cep'] ?: 'CEP não informado') ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Stats -->
                    <div class="card">
                        <div class="card-header"><h5 class="card-title">Estatísticas do Mês</h5></div>
                        <div class="card-body">
                            <div class="row g-3">
                                <div class="col-6">
                                    <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:10px">
                                        <div style="font-size:24px;font-weight:800;color:var(--azul-claro)"><?= $statPresenca ?></div>
                                        <div style="font-size:11px;color:var(--text-muted)">Presenças</div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:10px">
                                        <div style="font-size:24px;font-weight:800;color:var(--verde)"><?= number_format($statHoras,0) ?>h</div>
                                        <div style="font-size:11px;color:var(--text-muted)">Horas</div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:10px">
                                        <div style="font-size:24px;font-weight:800;color:var(--amarelo)"><?= $statTarefas ?></div>
                                        <div style="font-size:11px;color:var(--text-muted)">Tarefas</div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div style="text-align:center;padding:16px;background:var(--bg-secondary);border-radius:10px">
                                        <div style="font-size:24px;font-weight:800;color:var(--roxo-claro)"><?= $statConcluidas ?></div>
                                        <div style="font-size:11px;color:var(--text-muted)">Concluídas</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Coluna Direita -->
                <div class="col-12 col-lg-8">
                    <!-- Editar Perfil -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-person-gear me-2"></i>Editar Perfil</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="acao" value="atualizar">
                                <div class="row g-3">
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Nome Completo</label>
                                        <input type="text" name="nome" class="form-control" value="<?= htmlspecialchars($userData['nome']) ?>" required>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">E-mail</label>
                                        <input type="email" class="form-control" value="<?= htmlspecialchars($userData['email']) ?>" disabled style="opacity:0.6">
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Telefone</label>
                                        <input type="text" name="telefone" class="form-control" value="<?= htmlspecialchars($userData['telefone'] ?? '') ?>">
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">CEP</label>
                                        <input type="text" name="cep" class="form-control" value="<?= htmlspecialchars($userData['cep'] ?? '') ?>">
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label">Foto de Perfil</label>
                                        <input type="file" name="foto_perfil" class="form-control" accept="image/*">
                                        <div class="form-text" style="color:var(--text-muted);font-size:12px">JPG, PNG ou GIF. Máximo 5MB.</div>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="bi bi-check-lg"></i> Salvar Alterações
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Alterar Senha -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title"><i class="bi bi-shield-lock me-2"></i>Alterar Senha</h5>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="acao" value="senha">
                                <div class="row g-3">
                                    <div class="col-12">
                                        <label class="form-label">Senha Atual</label>
                                        <input type="password" name="senha_atual" class="form-control" required>
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Nova Senha</label>
                                        <input type="password" name="nova_senha" class="form-control" required minlength="6">
                                    </div>
                                    <div class="col-12 col-md-6">
                                        <label class="form-label">Confirmar Nova Senha</label>
                                        <input type="password" name="confirmar_senha" class="form-control" required>
                                    </div>
                                    <div class="col-12">
                                        <button type="submit" class="btn btn-purple">
                                            <i class="bi bi-lock-fill"></i> Alterar Senha
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
