<?php
require_once 'config/database.php';
require_once 'config/session.php';
require_once 'config/functions.php';
requireLogin();
requirePermission('calendario.view');

$pageTitle = 'Calendário Corporativo';
$breadcrumb = 'Calendário';
$user = currentUser();
$pdo = db();

// Garantir tabela
try {
    $pdo->query('SELECT 1 FROM calendario_eventos LIMIT 1');
} catch (Exception $e) {
    $sql = file_get_contents(__DIR__ . '/database/calendario.sql');
    $pdo->exec(preg_replace('/USE os_tres_m;\s*/', '', $sql));
}

$podeGerenciar = can('calendario.manage') || can('calendario.edit_own');
$usuarios = [];
$setores = [];
if (can('calendario.filter_team')) {
    $usuarios = getUsuarios('ativo');
    $setores = $pdo->query("SELECT DISTINCT setor FROM usuarios WHERE setor != '' ORDER BY setor")->fetchAll(PDO::FETCH_COLUMN);
}

$extraCSS = '
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.css" rel="stylesheet">
<link href="' . BASE_URL . 'assets/css/calendario.css" rel="stylesheet">';

include 'includes/header.php';
?>
<div class="app-wrapper">
    <?php include 'includes/sidebar.php'; ?>
    <div class="main-content">
        <?php include 'includes/topbar.php'; ?>
        <div class="page-content">
            <div class="d-flex align-items-center justify-content-between mb-3 flex-wrap gap-3">
                <div>
                    <h2 style="font-size:20px;font-weight:800;margin:0">Calendário Corporativo</h2>
                    <p style="color:var(--text-muted);font-size:13px;margin:0">Presença, equipe e eventos em tempo real</p>
                </div>
                <?php if ($podeGerenciar): ?>
                <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalEvento" onclick="novoEvento()">
                    <i class="bi bi-plus-lg"></i> Novo Evento
                </button>
                <?php endif; ?>
            </div>

            <div class="cal-hero card mb-4">
                <div class="card-body">
                    <div class="row g-3 align-items-stretch">
                        <div class="col-lg-9">
                            <div class="row g-2" id="calStatsRow">
                                <div class="col-6 col-md-4 col-xl">
                                    <div class="cal-stat-card green cal-stat-animate">
                                        <i class="bi bi-person-check cal-stat-icon"></i>
                                        <div><span class="cal-stat-val" data-stat="presentes_hoje">—</span><span class="cal-stat-lbl">Presentes Hoje</span></div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-xl">
                                    <div class="cal-stat-card yellow cal-stat-animate">
                                        <i class="bi bi-alarm cal-stat-icon"></i>
                                        <div><span class="cal-stat-val" data-stat="atrasados_hoje">—</span><span class="cal-stat-lbl">Atrasos</span></div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-xl">
                                    <div class="cal-stat-card red cal-stat-animate">
                                        <i class="bi bi-calendar-x cal-stat-icon"></i>
                                        <div><span class="cal-stat-val" data-stat="faltas_hoje">—</span><span class="cal-stat-lbl">Faltas</span></div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-xl">
                                    <div class="cal-stat-card blue cal-stat-animate">
                                        <i class="bi bi-person-dash cal-stat-icon"></i>
                                        <div><span class="cal-stat-val" data-stat="ausentes_hoje">—</span><span class="cal-stat-lbl">Ausentes</span></div>
                                    </div>
                                </div>
                                <div class="col-6 col-md-4 col-xl">
                                    <div class="cal-stat-card purple cal-stat-animate">
                                        <i class="bi bi-graph-up cal-stat-icon"></i>
                                        <div><span class="cal-stat-val" data-stat="taxa_presenca">—</span><span class="cal-stat-lbl">Taxa Presença</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 d-flex flex-column justify-content-center gap-2">
                            <div class="cal-view-switch btn-group w-100" role="group">
                                <button type="button" class="btn btn-outline active" data-cal-panel="equipe"><i class="bi bi-people"></i> Equipe</button>
                                <button type="button" class="btn btn-outline" data-cal-panel="calendario"><i class="bi bi-calendar3"></i> Calendário</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="painelEquipe">
                <div class="card mb-3">
                    <div class="card-body">
                        <div class="row g-3 align-items-end">
                            <div class="col-12 col-md-6">
                                <label class="form-label">Buscar na equipe</label>
                                <input type="text" id="equipeBusca" class="form-control" placeholder="Nome, cargo ou setor...">
                            </div>
                            <div class="col-12 col-md-6 text-md-end">
                                <span class="text-muted small" id="equipeContador">Carregando equipe...</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row g-3" id="equipeGrid">
                    <div class="col-12 text-center text-muted py-5">Carregando...</div>
                </div>
            </div>

            <div id="painelCalendario" class="d-none">
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row g-3 align-items-end">
                        <?php if (can('calendario.filter_team') && !empty($setores)): ?>
                        <div class="col-md-3">
                            <label class="form-label">Setor</label>
                            <select id="filtroSetor" class="form-select">
                                <option value="">Todos</option>
                                <?php foreach ($setores as $s): ?>
                                <option value="<?= htmlspecialchars($s) ?>"><?= htmlspecialchars($s) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Funcionário</label>
                            <select id="filtroUsuario" class="form-select">
                                <option value="">Todos</option>
                                <?php foreach ($usuarios as $u): ?>
                                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Pesquisar</label>
                            <input type="text" id="filtroBusca" class="form-control" placeholder="Título do evento...">
                        </div>
                        <?php endif; ?>
                        <div class="col-md-<?= can('calendario.filter_team') ? '12' : '6' ?>">
                            <div class="cal-legend d-flex flex-wrap gap-2">
                                <span class="legend-item" style="border-left-color:#10B981">Presente</span>
                                <span class="legend-item" style="border-left-color:#EF4444">Falta</span>
                                <span class="legend-item" style="border-left-color:#F59E0B">Atrasado</span>
                                <span class="legend-item" style="border-left-color:#3B82F6">Férias</span>
                                <span class="legend-item" style="border-left-color:#7C3AED">Evento/Reunião</span>
                                <span class="legend-item" style="border-left-color:#7C3AED">Tarefa</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row g-3">
                <div class="col-lg-9">
                    <div class="card">
                        <div class="card-body">
                            <div id="calendario"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0"><i class="bi bi-bell me-2"></i>Próximos eventos</h5>
                        </div>
                        <div class="card-body" id="calProximosEventos">
                            <p class="text-muted small mb-0">Carregando...</p>
                        </div>
                    </div>
                </div>
            </div>
            </div><!-- /painelCalendario -->
        </div>
    </div>
</div>

<?php if ($podeGerenciar): ?>
<div class="modal fade" id="modalEvento" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalEventoTitulo">Novo Evento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="formEvento">
                <div class="modal-body">
                    <input type="hidden" name="id" id="evId" value="0">
                    <div class="mb-3">
                        <label class="form-label">Título *</label>
                        <input type="text" name="titulo" id="evTitulo" class="form-control" required>
                    </div>
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label">Tipo</label>
                            <select name="tipo" id="evTipo" class="form-select">
                                <option value="evento">Evento</option>
                                <option value="feriado">Feriado</option>
                                <option value="ferias">Férias</option>
                                <option value="folga">Folga</option>
                                <option value="reuniao">Reunião</option>
                                <option value="comemorativo">Comemorativo</option>
                                <option value="escala">Escala</option>
                                <option value="outro">Outro</option>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Visibilidade</label>
                            <select name="visibilidade" id="evVisibilidade" class="form-select">
                                <option value="empresa">Empresa</option>
                                <option value="setor">Setor</option>
                                <option value="pessoal">Pessoal</option>
                            </select>
                        </div>
                    </div>
                    <div class="row g-2 mt-1">
                        <div class="col-6">
                            <label class="form-label">Início *</label>
                            <input type="datetime-local" name="data_inicio" id="evInicio" class="form-control" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Fim</label>
                            <input type="datetime-local" name="data_fim" id="evFim" class="form-control">
                        </div>
                    </div>
                    <?php if (can('calendario.filter_team')): ?>
                    <div class="row g-2 mt-1">
                        <div class="col-6">
                            <label class="form-label">Funcionário</label>
                            <select name="usuario_id" id="evUsuario" class="form-select">
                                <option value="">—</option>
                                <?php foreach ($usuarios as $u): ?>
                                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <label class="form-label">Setor</label>
                            <input type="text" name="setor" id="evSetor" class="form-control" list="listaSetores" value="<?= htmlspecialchars($user['setor'] ?? '') ?>">
                            <datalist id="listaSetores">
                                <?php foreach ($setores as $s): ?><option value="<?= htmlspecialchars($s) ?>"><?php endforeach; ?>
                            </datalist>
                        </div>
                    </div>
                    <?php endif; ?>
                    <div class="form-check mt-2">
                        <input type="checkbox" name="dia_inteiro" id="evDiaInteiro" class="form-check-input" value="1" checked>
                        <label class="form-check-label" for="evDiaInteiro">Dia inteiro</label>
                    </div>
                    <div class="mt-2">
                        <label class="form-label">Descrição</label>
                        <textarea name="descricao" id="evDescricao" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger me-auto d-none" id="btnExcluirEv">Excluir</button>
                    <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<div class="modal fade" id="modalVerMais" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="verMaisTitulo">Eventos do dia</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <input type="text" id="verMaisBusca" class="form-control" placeholder="Buscar evento...">
                </div>
                <div class="d-flex flex-wrap gap-2 mb-3" id="verMaisFiltros">
                    <button type="button" class="btn btn-outline btn-sm active" data-filtro="todos">Todos</button>
                    <button type="button" class="btn btn-outline btn-sm" data-filtro="tarefa">Tarefas</button>
                    <button type="button" class="btn btn-outline btn-sm" data-filtro="presenca">Presença</button>
                    <button type="button" class="btn btn-outline btn-sm" data-filtro="reuniao">Reuniões</button>
                    <button type="button" class="btn btn-outline btn-sm" data-filtro="falta">Faltas</button>
                    <button type="button" class="btn btn-outline btn-sm" data-filtro="horas_extras">H. Extras</button>
                </div>
                <div id="verMaisLista" class="cal-ver-mais-list"></div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalDetalhe" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detalheTitulo">Detalhe</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="detalheCorpo"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger me-auto d-none" id="btnRemoverEventoDetalhe"><i class="bi bi-trash"></i> Remover</button>
                <button type="button" class="btn btn-outline" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<?php
$extraJS = '<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/index.global.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.10/locales/pt-br.global.min.js"></script>
<script>window.CAL_CONFIG=' . json_encode([
    'baseUrl' => BASE_URL,
    'podeGerenciar' => $podeGerenciar,
    'podeRemover' => podeRemoverEventoCalendario(),
    'userId' => (int)$user['id'],
    'chatUrl' => BASE_URL . 'chat.php',
], JSON_UNESCAPED_UNICODE) . ';</script>
<script src="' . BASE_URL . 'assets/js/calendario.js"></script>';
include 'includes/footer.php';
?>
